/* Cindy identity and palette only. No agent or platform policy lives here. */
(() => {
  const colors = {"#051214":["#000000","#ffffff"],"#071a1c":["#0b0b0e","#faf8ff"],"#e8fffa":["#f8f5f7","#231b31"],"#dcfff6":["#f8f5f7","#231b31"],"#b4d8d1":["#c9bec5","#5f526f"],"#8ab8b0":["#9a8d97","#776885"],"#78ffe2":["#ff0000","#8000ff"],"#a8ffed":["#ff9aaa","#5b21b6"],"#5ce6c9":["#e74760","#6d28d9"],"#032722":["#22070e","#ffffff"],"#1d4a48":["#39212a","#e4d8f5"],"#2f7c74":["#75404c","#b49bdb"],"#4fbfa9":["#c45168","#8b5cf6"],"#0a2a28":["#251017","#f0e8fc"],"#061719":["#050506","#ffffff"],"#0d2e2e":["#2e151d","#ece1fa"],"#0b2224":["#141016","#f4effb"],"#0e3a36":["#431827","#e5d6fb"],"#12302e":["#2b1821","#e5dcf1"],"#1e3f3d":["#36202b","#d9cce9"],"#14302f":["#241820","#e8dff1"],"#2fae9b":["#b33b53","#9469cf"],"#1c3634":["#261b22","#e6dced"],"#7f9f9a":["#8f7b87","#8d7e9d"],"#28c4b8":["#d1344a","#9b76d5"],"#0e5c60":["#681a26","#d8c8f4"],"#e6fffa":["#ffeef2","#4c1d95"],"#0d2a2a":["#27141c","#efe6fb"],"#030c0d":["#000000","#f5f0fb"],"#3f8f88":["#986071","#9876bd"],"#ffb4a8":["#ff8e9c","#a52c53"],"#ffcbc2":["#ffc4d0","#8c1c42"],"#ff8a78":["#ff7a8e","#b3234e"],"#e9a196":["#dfa2b1","#a43b68"],"#04191b":["#100507","#f5f2fa"],"#08201f":["#140608","#f2eef8"],"#0b1f21":["#15070a","#f1ecf8"],"#0b2526":["#19070a","#f0eaf7"],"#0c2a2c":["#1c080c","#ede7f6"],"#0f2725":["#190a0d","#eee8f6"],"#12393a":["#260c10","#e7def2"],"#164446":["#2e0e14","#e2d7f0"],"#1f5f58":["#3e141c","#d7c8ea"],"#1fb5a0":["#b51f3a","#b489eb"],"#24675f":["#672430","#d3c3e8"],"#28aa96":["#aa283f","#b691e5"],"#2b4a48":["#301c20","#dbd3e5"],"#2f6d66":["#6d2f3a","#cebee3"],"#50d2be":["#d25067","#9a69d8"],"#5fe0c6":["#e05f76","#8f51dd"],"#6fd6ff":["#f47a90","#7d2fe1"],"#7ff3ff":["#f5899c","#7826e0"],"#8ff5e0":["#f58fa1","#7622df"],"#a6ffeb":["#f8adba","#6c1ecf"],"#d6fff6":["#fcd9df","#5d1ab4"],"#e9fbff":["#fdebee","#5818a9"]};
  const listeners = new Set(), led = Array.from({length:5},()=>[0,0,0]);
  const canvas = {};
  let theme = 'dark', accent = null;
  const DEFAULT_ACCENT = { dark: '#ff0000', light: '#8000ff' };
  const skins = {
    dark: { ACC:'#ff0000', HOT:'#ffeef2', MID:'#d1344a', DEEP:'#681a26', EDGE:'rgba(39,3,12,.6)', GLASS:'rgba(7,7,9,.97)', TEXT:'#f8f5f7', DIM:'#aa949f', CORAL:'#ff7a8e', NOTE:'#dfa2b1', INKDARK:'#22070e', led:[[6,6,8],[104,26,38],[209,52,74],[255,93,112],[255,238,242]] },
    light: { ACC:'#8000ff', HOT:'#4c1d95', MID:'#9b76d5', DEEP:'#d8c8f4', EDGE:'rgba(101,55,171,.23)', GLASS:'rgba(255,255,255,.98)', TEXT:'#231b31', DIM:'#776885', CORAL:'#b3234e', NOTE:'#a43b68', INKDARK:'#ffffff', led:[[32,17,56],[77,29,149],[124,58,237],[180,143,255],[249,245,255]] }
  };
  const validHex = (v) => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v);
  const rgb = (v) => [1, 3, 5].map((i) => parseInt(v.slice(i, i + 2), 16));
  const hex = (v) => '#' + v.map((n) => Math.round(Math.max(0, Math.min(255, n))).toString(16).padStart(2, '0')).join('');
  const toHsl = ([r, g, b]) => {
    r /= 255; g /= 255; b /= 255;
    const hi = Math.max(r, g, b), lo = Math.min(r, g, b), d = hi - lo, l = (hi + lo) / 2;
    if (!d) return [0, 0, l];
    const s = d / (1 - Math.abs(2 * l - 1));
    const h = hi === r ? ((g - b) / d) % 6 : hi === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return [((h * 60) + 360) % 360, s, l];
  };
  const fromHsl = ([h, s, l]) => {
    const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
    const p = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
    return p.map((n) => (n + m) * 255);
  };
  const deltaHue = (a, b) => ((a - b + 540) % 360) - 180;
  const effective = () => accent ?? DEFAULT_ACCENT[theme];
  // Move every coloured token onto the chosen hue while retaining its original lightness hierarchy. Near-neutrals
  // stay neutral, which keeps the dark and light surfaces clean instead of washing the whole app in colour.
  const shift = (value) => {
    if (!validHex(value)) return value;
    if (value.toLowerCase() === DEFAULT_ACCENT[theme]) return effective();
    const source = toHsl(rgb(value)), base = toHsl(rgb(DEFAULT_ACCENT[theme])), pick = toHsl(rgb(effective()));
    if (source[1] < 0.075) return value.toLowerCase();
    const hue = (pick[0] + deltaHue(source[0], base[0]) * 0.14 + 360) % 360;
    const sat = Math.max(0.08, Math.min(1, source[1] * (0.72 + pick[1] / Math.max(0.2, base[1]) * 0.28)));
    const weight = Math.min(1, source[1] * 1.35), light = Math.max(0.025, Math.min(0.975, source[2] + (pick[2] - base[2]) * weight * 0.42));
    return hex(fromHsl([hue, sat, light]));
  };
  const mapped = (value) => colors[value?.toLowerCase?.()]?.[theme === 'light' ? 1 : 0] || value;
  const applyCss = () => {
    const root = document.documentElement;
    if (!root.style?.setProperty) return;
    for (const [source, pair] of Object.entries(colors)) {
      const value = shift(pair[theme === 'light' ? 1 : 0]), slug = source.slice(1).toLowerCase(), channels = rgb(value);
      root.style.setProperty(`--cindy-${slug}`, value);
      root.style.setProperty(`--cindy-rgb${slug}`, channels.join(','));
    }
    root.style.setProperty('--cindy-accent', effective());
    root.style.setProperty('--cindy-accent-rgb', rgb(effective()).join(','));
  };
  const storageKey = 'cindy.palette';
  function render(next, nextAccent) {
    const mode = next === 'light' ? 'light' : 'dark';
    const pick = validHex(nextAccent) ? nextAccent.toLowerCase() : nextAccent === undefined && mode === theme ? accent : null;
    if (canvas.ACC && theme === mode && accent === pick) return;
    theme = mode;
    accent = pick;
    const skin = skins[theme], a = rgb(effective());
    Object.assign(canvas, skin, {
      ACC: effective(), HOT: shift(skin.HOT), MID: shift(skin.MID), DEEP: shift(skin.DEEP),
      EDGE: `rgba(${a.join(',')},${theme === 'light' ? .22 : .34})`, CORAL: shift(skin.CORAL), NOTE: shift(skin.NOTE),
    });
    skin.led.forEach((row,i)=>rgb(shift(hex(row))).forEach((v,j)=>led[i][j]=v));
    document.documentElement.dataset.cindyTheme=theme;
    applyCss();
    listeners.forEach(fn=>fn(theme,canvas,effective()));
    window.Roamie?.wake?.();
  }
  function set(next, nextAccent) {
    render(next, nextAccent);
    try { localStorage.setItem(storageKey, JSON.stringify({theme, accent})); } catch {}
  }
  const color = value => shift(mapped(value));
  const subscribe = fn => { listeners.add(fn); fn(theme,canvas,effective()); return()=>listeners.delete(fn); };
  window.CindyTheme={set,color,subscribe,canvas,led,get name(){return theme;},get accent(){return effective();}};
  function readPalette() {
    try {
      const raw = localStorage.getItem(storageKey);
      return raw ? JSON.parse(raw) : {theme:localStorage.getItem('cindy.theme'), accent:null};
    } catch { return null; }
  }
  const saved = readPalette();
  const query = new URLSearchParams(location.search);
  const initial = query.get('theme') || saved?.theme || 'dark';
  render(initial, query.get('accent') || (initial === saved?.theme ? saved.accent : null));
  addEventListener('storage',event=>{
    if (event.key !== storageKey) return;
    const current = readPalette();
    if (current) render(current.theme, current.accent);
  });
})();
