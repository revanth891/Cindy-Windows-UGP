// The chosen sidekick: the LED matrix dither blob, without the drips, with the agent layer on top.
Roamie.register(Roamie.ditherKit({
  id: 'sidekick', label: 'Cindy', matrix: false, pixel: 0.55, glow: 0.46, speed: 80,
  pal: CindyTheme.led,
  plugin: (kit) => Roamie.agentPlugin?.(kit) ?? null,
}));
