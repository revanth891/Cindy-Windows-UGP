// Cindy's original digital-sand avatar family. Fine grains continuously
// assemble into four abstract signal formations and disperse into flow lines.
(() => {
  const R = window.Roamie;
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const fract = (v) => v - Math.floor(v);
  const hash = (n) => fract(Math.sin(n * 127.1 + 311.7) * 43758.5453123);
  const ir = Math.round;

  const FONT = {
    C: ['111', '100', '100', '100', '111'],
    P: ['110', '101', '110', '100', '100'],
    X: ['101', '101', '010', '101', '101'],
    '0': ['111', '101', '101', '101', '111'],
    '1': ['010', '110', '010', '010', '111'],
    '3': ['110', '001', '110', '001', '110'],
  };
  const glyph = (put, text, x, y, level, gap = 1, scale = 1) => {
    let ox = ir(x);
    for (const ch of text) {
      const rows = FONT[ch];
      if (!rows) { ox += (3 + gap) * scale; continue; }
      rows.forEach((row, yy) => [...row].forEach((bit, xx) => {
        if (bit !== '1') return;
        for (let sy = 0; sy < scale; sy++) for (let sx = 0; sx < scale; sx++)
          put(ox + xx * scale + sx, ir(y) + yy * scale + sy, level);
      }));
      ox += (3 + gap) * scale;
    }
  };
  const grain = (put, x, y, level, bright = false) => {
    const gx = ir(x), gy = ir(y);
    const dx = x - gx, dy = y - gy;
    // A slightly wider grain shares its nearest edge cell as its centre crosses the grid.
    // Only one edge is lit, so the four pointed tips and the spaces between grains stay sharp.
    const edge = Math.max(1, level - 1);
    if (Math.max(Math.abs(dx), Math.abs(dy)) > 0.42) {
      if (Math.abs(dx) >= Math.abs(dy)) put(gx + Math.sign(dx), gy, edge);
      else put(gx, gy + Math.sign(dy), edge);
    }
    put(gx, gy, level);
    if (bright) put(gx + 1, gy, edge);
  };
  const lineGrains = (put, x0, y0, x1, y1, count, level, seed, t, jitter = 0.25) => {
    const dx = x1 - x0, dy = y1 - y0, n = Math.hypot(dx, dy) || 1;
    for (let i = 0; i < count; i++) {
      const u = (i + hash(i + seed) * 0.7) / count;
      const dust = (hash(i * 4.7 + seed) - 0.5) * jitter + Math.sin(t * 0.8 + i) * jitter * 0.12;
      grain(put, x0 + dx * u - dy / n * dust, y0 + dy * u + dx / n * dust, i % 13 === 0 ? Math.min(4, level + 1) : level);
    }
  };
  const energy = (st) => {
    const voice = st.mode === 'talk' ? (st.voice == null ? 0.55 + Math.sin(st.t * 13) * 0.35 : st.voice) : 0;
    return clamp(0.35 + voice * 1.2 + (st.mode === 'listen' ? 0.32 : 0) + (st.mode === 'think' ? 0.2 : 0), 0.25, 1.6);
  };

  // One live product accent drives every formation. The renderer deliberately keeps this shared array reference so
  // dragging the colour picker repaints an already-running avatar without reconstructing its animation state.
  R.cindyPalette = () => CindyTheme.led;

  // Three coherent streams pass through the formation. The grains share a
  // spline and phase, so the motion reads as flowing sand rather than debris.
  const streams = (put, cx, cy, r, st, L, seed) => {
    const e = energy(st), t = st.t;
    for (let lane = -1; lane <= 1; lane++) {
      for (let i = 0; i < 18; i++) {
        const u = fract(i / 18 + t * (.055 + lane * .003) * (.82 + e * .16) + seed * .07);
        const ease = Math.sin(u * Math.PI);
        const x = cx + (u * 2 - 1) * r * 1.08;
        const y = cy + lane * r * .18 + Math.sin(u * TAU + t * .18 + lane * 1.1 + seed) * r * .105 * ease;
        const edge = Math.abs(u - .5) * 2;
        const lvl = edge < .46 ? (i % 7 === 0 ? 3 : 2) : 1;
        grain(put, x, y, lvl, e > 1.15 && i === 9 && lane === 0);
      }
    }
  };

  const cloud = (put, cx, cy, r, st, L, seed, shape) => {
    const e = energy(st), t = st.t, talk = st.mode === 'talk';
    for (let i = 0; i < 110; i++) {
      const h1 = hash(i * 1.71 + seed), h2 = hash(i * 3.19 + seed * 2.1);
      let a = h1 * TAU + t * (0.055 + h2 * 0.085) * (i % 2 ? 1 : -1);
      const rr = Math.sqrt(h2) * r;
      let x, y;
      if (shape === 'vortex') {
        a += rr / r * 2.2 + Math.sin(t * 0.45 + i) * 0.03;
        x = Math.cos(a) * rr; y = Math.sin(a) * rr * 0.78;
      } else if (shape === 'orbit') {
        const band = r * (0.58 + h2 * 0.36);
        x = Math.cos(a) * band;
        y = Math.sin(a) * band * 0.47 + Math.sin(a * 2 + t * 0.7) * r * 0.12;
      } else if (shape === 'ribbon') {
        const u = h1 * 2 - 1;
        x = u * r * 0.9 + Math.sin(t * 0.35 + h2 * 6) * r * 0.08;
        y = (h2 * 2 - 1) * r * 0.95 + Math.sin(u * 4.5 + t * 0.8) * r * 0.18;
      } else {
        const u = h1 * 2 - 1, v = h2 * 2 - 1, k = Math.max(1, Math.abs(u) + Math.abs(v));
        x = (u / k) * rr; y = (v / k) * rr * 1.03;
        const ca = Math.cos(t * 0.08), sa = Math.sin(t * 0.08);
        [x, y] = [x * ca - y * sa, x * sa + y * ca];
      }
      const wave = Math.sin(t * (talk ? 5.6 : 1.2) + i * 0.83);
      const breathe = 1 + wave * (talk ? 0.055 * e : 0.018);
      x *= breathe; y *= breathe;
      const edge = rr / r;
      let lvl = edge < 0.22 ? 3 : edge > 0.78 ? 2 : 1;
      if (i % 19 === 0 || (e > 1 && i % 13 === 0)) lvl = L;
      grain(put, cx + x, cy + y, lvl, e > 1.2 && i % 29 === 0);
    }
  };

  // Cindy's primary formation: an original angular machine mask built from
  // streaming grains. Narrow optics and a segmented jaw give it a cinematic
  // synthetic-intelligence presence without reproducing a film asset.
  const sentinel = (put, cx, cy, r, st, L, seed) => {
    const t = st.t, e = energy(st), voice = st.mode === 'talk' ? e : 0;
    const S = (x, y) => [cx + x * r, cy + y * r];
    const segments = [
      [-.72,-.48,-.34,-.92,2],[-.34,-.92,0,-1.02,2],[0,-1.02,.34,-.92,2],[.34,-.92,.72,-.48,2],
      [-.72,-.48,-.78,.18,2],[-.78,.18,-.48,.66,2],[-.48,.66,-.18,.96,2],[-.18,.96,0,1.02,3],
      [0,1.02,.18,.96,3],[.18,.96,.48,.66,2],[.48,.66,.78,.18,2],[.78,.18,.72,-.48,2],
      [-.52,-.55,-.12,-.30,2],[.52,-.55,.12,-.30,2],[-.12,-.30,0,-.64,1],[.12,-.30,0,-.64,1],
      [-.57,-.18,-.16,-.10,L],[-.16,-.10,-.05,-.19,L],[.57,-.18,.16,-.10,L],[.16,-.10,.05,-.19,L],
      [-.44,.18,-.20,.36,2],[-.20,.36,0,.26,2],[0,.26,.20,.36,2],[.20,.36,.44,.18,2],
      [-.37,.57,-.12,.69,3],[-.12,.69,.12,.69,3],[.12,.69,.37,.57,3],
      [0,-.78,0,.60,1],[-.68,.03,-.28,.10,1],[.68,.03,.28,.10,1],
    ];
    segments.forEach((s, i) => {
      let [x0,y0,x1,y1,lvl] = s;
      // The jaw separates fractionally with speech and pulls back together.
      const jaw = i >= 24 && i <= 26 ? voice * (0.035 + 0.025 * Math.sin(t * 12)) : 0;
      y0 += jaw; y1 += jaw;
      const a = S(x0,y0), b = S(x1,y1);
      lineGrains(put, a[0], a[1], b[0], b[1], i >= 16 && i <= 19 ? 13 : 8, lvl, seed + i * 7.1, t, r * (i % 6 === 0 ? .035 : .02));
    });
    // Loose grains keep the mask porous rather than turning into line art.
    for (let i = 0; i < 76; i++) {
      const a = hash(i + seed) * TAU, d = Math.sqrt(hash(i * 2.7 + seed)) * r * .88;
      const x = Math.cos(a) * d, y = Math.sin(a) * d * .88;
      if (Math.abs(x) < r * .08 && y < -r * .25) continue;
      grain(put, cx + x + Math.sin(t * .4 + i) * .16, cy + y, i % 17 === 0 ? 3 : 1, e > 1.15 && i % 31 === 0);
    }
  };

  // Layered holographic intelligence core. Several independent coordinate
  // systems rotate at different rates, so it is always alive even at rest.
  const hologram = (put, cx, cy, r, st, L, seed) => {
    const t = st.t, e = energy(st), speed = .18 + e * .09;
    // Spherical dust shell with depth-aware brightness.
    const count = 190, golden = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < count; i++) {
      const y0 = 1 - ((i + .5) / count) * 2;
      const rr = Math.sqrt(Math.max(0, 1 - y0 * y0));
      const a = i * golden + t * speed * (i % 3 === 0 ? -1 : 1);
      let x = Math.cos(a) * rr, y = y0, z = Math.sin(a) * rr;
      const tilt = .32 + Math.sin(t * .11) * .05;
      [y, z] = [y * Math.cos(tilt) - z * Math.sin(tilt), y * Math.sin(tilt) + z * Math.cos(tilt)];
      const perspective = .86 + z * .16;
      const lvl = z > .45 ? (i % 13 === 0 ? L : 3) : z > -.2 ? 2 : 1;
      grain(put, cx + x * r * perspective, cy + y * r * perspective, lvl, z > .68 && i % 31 === 0);
    }
    // Broken latitude rings and counter-rotating orbital bands.
    for (let band = 0; band < 6; band++) {
      const ry = r * (.16 + band * .115), rx = Math.sqrt(Math.max(.08, r * r - ry * ry)) * (.92 + band * .015);
      for (let i = 0; i < 58; i++) {
        if ((i + band * 7 + Math.floor(t * (2 + band * .2))) % 17 < 4) continue;
        const a = i / 58 * TAU + t * (.09 + band * .013) * (band % 2 ? -1 : 1);
        const y = cy + (band - 2.5) * r * .18 + Math.sin(a) * ry * .28;
        const depth = Math.sin(a);
        grain(put, cx + Math.cos(a) * rx, y, depth > .2 ? 3 : depth > -.45 ? 2 : 1, i % 29 === 0 && depth > .3);
      }
    }
    // Three large gyroscope arcs, deliberately incomplete like streamed data.
    for (let ring = 0; ring < 3; ring++) {
      for (let i = 0; i < 78; i++) {
        if ((i + ring * 11) % 23 < 6) continue;
        const a = i / 78 * TAU + t * (.12 + ring * .045) * (ring === 1 ? -1 : 1);
        const ca = Math.cos(a), sa = Math.sin(a), lean = ring * .72 + t * .025;
        let x = ca * r * (1.03 + ring * .08), y = sa * r * .82;
        const z = sa * Math.sin(lean);
        [x, y] = [x * Math.cos(lean) - y * Math.sin(lean) * .28, y * Math.cos(lean) + x * Math.sin(lean) * .24];
        grain(put, cx + x, cy + y, z > 0 ? (i % 19 === 0 ? L : 3) : 1);
      }
    }
    // Dense rotating core and a few radial data conduits.
    for (let i = 0; i < 52; i++) {
      const a = i * 2.399 + t * (.7 + e * .22), d = Math.sqrt(hash(i + seed)) * r * .34;
      grain(put, cx + Math.cos(a) * d, cy + Math.sin(a) * d * .72, i % 13 === 0 ? L : i % 3 ? 3 : 2, i % 37 === 0);
    }
    for (let i = 0; i < 8; i++) {
      const a = i / 8 * TAU + t * .08;
      const inner = r * (.26 + (i % 3) * .03), outer = r * (.68 + hash(i + seed) * .28);
      lineGrains(put, cx + Math.cos(a) * inner, cy + Math.sin(a) * inner * .76, cx + Math.cos(a) * outer, cy + Math.sin(a) * outer * .76, 8, i % 4 === 0 ? 3 : 2, seed + i * 9, t, .28);
    }
    // Symbols drift around the shell as transient telemetry.
    const marks = [['C',-.82,-.34],['1',.64,-.58],['0',.78,.22],['3',-.55,.60]];
    marks.forEach(([text,x,y], i) => {
      const phase = fract(t * (.055 + i * .006) + i * .23);
      if (phase > .15 && phase < .72) glyph(put, text, cx + x * r + Math.sin(t * .17 + i) * 2, cy + y * r, phase < .24 || phase > .62 ? 1 : 2, 0, r > 32 ? 2 : 1);
    });
  };

  const torus = (put, cx, cy, r, st, L, seed) => {
    const t=st.t, e=energy(st);
    for(let band=0;band<4;band++) for(let i=0;i<86;i++) {
      if((i+band*9)%29<4) continue;
      const a=i/86*TAU+t*(.12+band*.035)*(band%2?-1:1);
      const tube=Math.sin(a*3+t*.37+band)*r*(.055+band*.012);
      const rx=r*(.98-band*.07)+tube, ry=r*(.34+band*.055);
      const lean=(band-1.5)*.16;
      const x=Math.cos(a)*rx, y=Math.sin(a)*ry+Math.cos(a)*lean*r;
      grain(put,cx+x,cy+y,Math.sin(a)>.15?(i%23===0?L:3):2,i%43===0&&Math.sin(a)>.3);
    }
    for(let i=0;i<70;i++) {
      const a=i*2.399-t*(.48+e*.12), d=Math.sqrt(hash(i+seed))*r*.30;
      grain(put,cx+Math.cos(a)*d,cy+Math.sin(a)*d*.70,i%11===0?L:3,i%37===0);
    }
    for(let i=0;i<10;i++) {
      const a=i/10*TAU+t*.1, inner=r*.31, outer=r*(.70+hash(i+seed)*.18);
      lineGrains(put,cx+Math.cos(a)*inner,cy+Math.sin(a)*inner*.36,cx+Math.cos(a)*outer,cy+Math.sin(a)*outer*.36,9,i%3===0?3:2,seed+i*8,t,.18);
    }
  };

  // A circular particulate blob: one exact breathing membrane with a dense,
  // slowly circulating interior. No lopsided deformation at small sizes.
  const blob = (put, cx, cy, r, st, L, seed) => {
    const t=st.t,e=energy(st), active=st.mode==='listen'||st.mode==='think'||st.mode==='talk';
    const breathe=1+.014*Math.sin(t*1.35)+(st.mode==='talk' ? .022*Math.sin(t*8)*e : 0), edge=r*.82*breathe;
    for(let i=0;i<220;i++) {
      const a=i/220*TAU+t*.018, x=Math.cos(a)*edge, y=Math.sin(a)*edge;
      const lvl=i%23===0?L:i%5===0?3:2;
      grain(put,cx+x,cy+y,lvl,i%53===0);
      if(i%2===0) grain(put,cx+Math.cos(a+.008)*(edge-1.15),cy+Math.sin(a+.008)*(edge-1.15),1);
    }
    for(let i=0;i<286;i++) {
      const a=hash(i*2.37+seed)*TAU+t*(.045+(i%5)*.006)*(i%2?1:-1);
      const d=Math.sqrt(hash(i*5.11+seed*2.7))*edge*.91;
      const drift=Math.sin(t*.5+i*.73)*r*.012;
      const x=Math.cos(a)*d+Math.cos(a+Math.PI/2)*drift, y=Math.sin(a)*d+Math.sin(a+Math.PI/2)*drift;
      const near=d/edge, lvl=near<.22?(i%11===0?L:3):near<.58?(i%5===0?3:2):near>.82?2:i%7===0?3:1;
      grain(put,cx+x,cy+y,lvl,e>1.15&&i%61===0);
    }
    // A bright internal current makes the orb feel powered rather than hollow.
    for(let arm=0;arm<3;arm++) for(let i=0;i<34;i++) {
      const u=i/33, a=arm*TAU/3+u*TAU*1.22-t*(.34+e*.05), d=u*edge*.58;
      grain(put,cx+Math.cos(a)*d,cy+Math.sin(a)*d, i<5?L:i%6===0?3:2, i===3&&arm===0);
    }
    // A few coherent currents make the interior visibly flow at small sizes.
    for(let band=-1;band<=1;band++) for(let i=0;i<24;i++) {
      const u=fract(i/24+t*(.07+band*.004)+seed*.11), x=(u*2-1)*r*.61;
      const y=band*r*.17+Math.sin(u*TAU+t*.38+band)*r*.075;
      grain(put,cx+x,cy+y,Math.abs(u-.5)<.34?2:1,i===12&&band===0&&e>1.1);
    }
    // Sparse orbital dust and two small particle satellites, like a tiny
    // system around the circular core rather than disconnected decorations.
    for(let i=0;i<64;i++) {
      if(i%11<3) continue;
      const a=i/64*TAU-t*.09, d=r*1.08;
      grain(put,cx+Math.cos(a)*d,cy+Math.sin(a)*d*.46,i%17===0?3:1);
    }
    const satelliteSpeed=st.mode==='think' ? .31 : st.mode==='listen' ? .22 : st.mode==='talk' ? .26 : .13;
    for(let s=0;s<2;s++) {
      const a=t*satelliteSpeed*(s ? 1 : -.78)+s*Math.PI*1.08+.35, sx=cx+Math.cos(a)*r*(1.03+s*.16), sy=cy+Math.sin(a)*r*(.55+s*.05), sr=r*(s ? .105 : .13);
      for(let i=0;i<28;i++) { const q=i/28*TAU; grain(put,sx+Math.cos(q)*sr,sy+Math.sin(q)*sr,i%7===0?L:3); }
      for(let i=0;i<16;i++) { const q=hash(i+s*19)*TAU,d=Math.sqrt(hash(i*3.1+s))*sr*.78; grain(put,sx+Math.cos(q)*d,sy+Math.sin(q)*d,2); }
    }
    // Active states send a thin pressure wave through the membrane. It is
    // deliberately broken into grains, never a solid ring.
    if(active) for(let wave=0;wave<2;wave++) {
      const u=fract(t*(st.mode==='talk' ? .78 : .42)+wave*.53), wr=edge*(1.02+u*.34);
      for(let i=0;i<58;i++) {
        if((i+wave*9)%13<5) continue;
        const a=i/58*TAU+t*(wave ? .12 : -.09);
        grain(put,cx+Math.cos(a)*wr,cy+Math.sin(a)*wr,lvlForWave(u,i,L));
      }
    }
  };

  // A crisp four-point star made from straight particle segments. Alternating
  // outer and deeply inset vertices produce genuinely sharp points.
  const fourStar = (put,cx,cy,r,st,L,seed) => {
    const t=st.t;
    // A restrained idle turn: enough to stay alive without making the sharp
    // silhouette restless. Thinking adds only a small, temporary lift.
    const spin=st.mode==='think' ? .11 : st.mode==='listen' ? .035 : st.mode==='talk' ? .065 : .045;
    const turn=t*spin;
    const verts=(scale=1)=>Array.from({length:8},(_,i)=>{
      const a=i*Math.PI/4+turn, rr=r*scale*(i%2===0?1:.17);
      return [cx+Math.cos(a)*rr,cy+Math.sin(a)*rr];
    });
    const edge=verts(1);
    for(let i=0;i<8;i++) lineGrains(put,edge[i][0],edge[i][1],edge[(i+1)%8][0],edge[(i+1)%8][1],28,i%2?3:L,seed+i*7,t,.045);
    const outer=verts(.88);
    for(let i=0;i<238;i++) {
      const edge=Math.floor(hash(i*3.17+seed)*8), u=hash(i*5.13+seed*2.1), fill=Math.sqrt(hash(i*7.03+seed*4.7));
      const a=outer[edge],b=outer[(edge+1)%8];
      const x=(a[0]+(b[0]-a[0])*u-cx)*fill, y=(a[1]+(b[1]-a[1])*u-cy)*fill;
      const lvl=fill<.24?(i%13===0?L:3):fill<.62?(i%7===0?3:2):1;
      grain(put,cx+x,cy+y,lvl,i%89===0);
    }
  };

  const lvlForWave = (u, i, L) => u < .22 && i % 17 === 0 ? L : u < .58 ? 2 : 1;

  const lattice = (put,cx,cy,r,st,L,seed) => {
    const t=st.t,e=energy(st), turns=2.35;
    for(let side=0;side<2;side++) for(let i=0;i<112;i++) {
      const u=i/111, y=cy+(u*2-1)*r;
      const a=u*TAU*turns+t*(.36+e*.08)+side*Math.PI;
      const depth=Math.sin(a), x=cx+Math.cos(a)*r*(.47+depth*.08);
      grain(put,x,y,depth>.1?(i%19===0?L:3):2,i%47===0&&depth>.2);
    }
    for(let row=0;row<9;row++) {
      const u=(row+.5)/9, y=cy+(u*2-1)*r, a=u*TAU*turns+t*(.36+e*.08);
      const x=Math.cos(a)*r*.47;
      lineGrains(put,cx-x,y,cx+x,y,12,row%3===0?3:2,seed+row*13,t,.14);
    }
    // A contained central signal column makes the silhouette readable.
    for(let i=0;i<44;i++) {
      const u=fract(hash(i+seed)+t*.055), y=cy+(u*2-1)*r*.78;
      grain(put,cx+Math.sin(u*14+t)*r*.09,y,i%9===0?L:2);
    }
  };

  const polyhedron = (put,cx,cy,r,st,L,seed) => {
    const t=st.t, ay=t*.18, ax=.42+Math.sin(t*.13)*.08;
    const raw=[[0,-1,0],[.86,0,0],[0,1,0],[-.86,0,0],[0,0,.82],[0,0,-.82]];
    const pts=raw.map(([x,y,z])=>{
      [x,z]=[x*Math.cos(ay)+z*Math.sin(ay),-x*Math.sin(ay)+z*Math.cos(ay)];
      [y,z]=[y*Math.cos(ax)-z*Math.sin(ax),y*Math.sin(ax)+z*Math.cos(ax)];
      const p=.9+z*.15;return [cx+x*r*p,cy+y*r*p,z];
    });
    const edges=[[0,1],[0,3],[0,4],[0,5],[2,1],[2,3],[2,4],[2,5],[1,4],[4,3],[3,5],[5,1]];
    edges.forEach(([a,b],i)=>lineGrains(put,pts[a][0],pts[a][1],pts[b][0],pts[b][1],15,(pts[a][2]+pts[b][2])>0?3:2,seed+i*11,t,.22));
    for(let i=0;i<72;i++) {
      const a=i/72*TAU-t*.31, d=r*(.25+hash(i+seed)*.16);
      grain(put,cx+Math.cos(a)*d,cy+Math.sin(a)*d*.58,i%13===0?L:3,i%41===0);
    }
    for(const [x,y,z] of pts) grain(put,x,y,z>0?L:3,true);
  };

  // A short spring pulls the rear surface away from the moving head. A slower spring holds
  // one drop of the same material. Their rounded distance fields split and fuse on turns.
  const smoothUnion = (a, b, radius) => {
    const overlap = Math.max(radius - Math.abs(a - b), 0);
    return Math.min(a, b) - overlap * overlap / (4 * radius);
  };
  const sand = Float32Array.from({ length: 1024 }, (_, i) => hash(i + 94));
  const liquidTrail = (put, cx, cy, r, st, L, density) => {
    const strength = st.dragEcho ?? (st.dragging ? 1 : 0);
    if (strength < .02 || !st.trail?.length) return put;
    const anchor = (offset, limit) => {
      const [x, y] = offset;
      const d = Math.hypot(x, y);
      const scale = strength * limit / Math.max(d, .001) * Math.tanh(d / limit);
      return [x * scale, y * scale];
    };
    const [sx, sy] = anchor(st.trail[0], 1.12 * r);
    const [tx, ty] = anchor(st.trail[st.trail.length - 1], 2.40 * r);
    const length = Math.hypot(sx, sy);
    const strain = clamp((Math.max(length, Math.hypot(tx, ty) * .58) / r - .12) / .78, 0, 1);
    if (strain < .015) return put;
    const nx = sx / Math.max(length, .001), ny = sy / Math.max(length, .001);
    const shoulder = r * .49 * strain, drop = r * .32 * strain;
    const blend = r * .42 * strain, pad = shoulder + blend;
    const left = Math.floor(Math.min(sx, tx) - pad), right = Math.ceil(Math.max(sx, tx) + pad);
    const top = Math.floor(Math.min(sy, ty) - pad), bottom = Math.ceil(Math.max(sy, ty) + pad);
    for (let y = top; y <= bottom; y++) for (let x = left; x <= right; x++) {
      const dsx = x - sx, dsy = y - sy, dtx = x - tx, dty = y - ty;
      const a = Math.sqrt(dsx * dsx + dsy * dsy) - shoulder;
      const b = Math.sqrt(dtx * dtx + dty * dty) - drop;
      const wake = smoothUnion(a, b, blend);
      const head = Math.sqrt(x * x + y * y) - r * .57;
      const join = clamp(.64 + (head - wake) / blend, 0, 1);
      if (!join) continue;
      const surface = smoothUnion(wake, head, blend);
      if (surface > 0) continue;
      // Grain positions ride each lobe. This keeps a moving highlight attached to its material.
      const ax = b < a ? dtx : dsx, ay = b < a ? dty : dsy;
      const radius = b < a ? drop : shoulder;
      const light = clamp(.54 - (ax * .44 + ay * .72) / radius, 0, 1);
      const rim = surface > -Math.max(.9, radius * .085);
      const noise = sand[(ir(ax) & 31) + (ir(ay) & 31) * 32];
      if (noise > (rim ? .61 : .11 + .21 * light) * strain * density * join) continue;
      const level = light > .94 && noise < .045 ? L : light > .60 ? 3 : light > .33 ? 2 : 1;
      put(ir(cx + x), ir(cy + y), rim ? 2 : level);
    }
    return (x, y, level) => {
      const dx = x - cx, dy = y - cy;
      const rear = clamp((dx * nx + dy * ny) / r, 0, 1);
      const extension = rear * rear * .48;
      const squeeze = .12 * strain * rear * (dy * nx - dx * ny);
      put(ir(x + sx * extension + ny * squeeze), ir(y + sy * extension - nx * squeeze), level);
    };
  };

  const responseFlow = (put, cx, cy, r, st, L, seed) => {
    const t = st.t, e = energy(st), act = st.act;
    if (st.mode === 'listen' || st.heard) {
      for (let ring = 0; ring < 2; ring++) for (let i = 0; i < 36; i++) {
        if ((i + ring * 5) % 11 < 3) continue;
        const u = fract(t * (.24 + ring * .04) + i / 36 + ring * .41);
        const a = i / 36 * TAU + t * (ring ? -.28 : .22);
        const d = r * (1.04 + u * .48);
        grain(put, cx + Math.cos(a) * d, cy + Math.sin(a) * d * .68, u < .28 ? (i % 9 === 0 ? L : 3) : u < .66 ? 2 : 1);
      }
    }
    if (st.mode === 'think') {
      for (let strand = 0; strand < 2; strand++) for (let i = 0; i < 28; i++) {
        const u = i / 27, a = t * (strand ? -.82 : .82) + u * TAU * 1.65 + strand * Math.PI;
        const d = r * (.40 + u * .72);
        grain(put, cx + Math.cos(a) * d, cy - r * 1.08 + u * r * 2.16 + Math.sin(a) * r * .13, i < 4 ? L : i % 5 === 0 ? 3 : 2);
      }
    }
    if (st.mode === 'talk') {
      for (let wave = 0; wave < 2; wave++) {
        const u = fract(t * (.82 + e * .26) + wave * .51), d = r * (.94 + u * .63);
        for (let i = 0; i < 42; i++) {
          if ((i + wave * 4) % 12 < 4) continue;
          const a = i / 42 * TAU + t * (wave ? -.16 : .14);
          grain(put, cx + Math.cos(a) * d, cy + Math.sin(a) * d * .72, lvlForWave(u, i, L), u < .2 && i % 19 === 0);
        }
      }
    }
    if (act) {
      const force = act === 'hype' ? 1.5 : act === 'upset' ? 1.2 : act === 'motivate' ? 1.05 : 0.8;
      for (let i = 0; i < 34; i++) {
        const a = seed + i * 2.399 + t * (act === 'upset' ? 1.1 : 0.35);
        const d = r * (0.82 + fract(i * 0.317 + t * 0.22 * force) * (0.32 + force * 0.12));
        const rise = act === 'motivate' ? -fract(i * 0.13 + t * 0.25) * r * 0.8 : 0;
        grain(put, cx + Math.cos(a) * d, cy + Math.sin(a) * d * 0.72 + rise, i % 9 === 0 ? L : 2, e > 1.2 && i % 17 === 0);
      }
    }
    if (st.sleepy > 0.6) {
      for (let i = 0; i < 18; i++) {
        const u = fract(i * 0.271 + t * 0.055);
        grain(put, cx + r * (0.45 + u * 1.2), cy + r * 0.6 - u * r * 1.8 + Math.sin(u * 12) * 2, i % 7 === 0 ? 3 : 1);
      }
    }
  };

  const formation = (shape, put, cx, cy, r, st, L, seed, ambience = true) => {
    if (ambience && shape !== 'blob' && shape !== 'star') streams(put, cx, cy, r, st, L, seed);
    if (shape === 'hologram') hologram(put, cx, cy, r, st, L, seed);
    else if (shape === 'orbit') torus(put, cx, cy, r, st, L, seed);
    else if (shape === 'blob') blob(put, cx, cy, r, st, L, seed);
    else if (shape === 'star') fourStar(put, cx, cy, r, st, L, seed);
    else if (shape === 'ribbon') lattice(put, cx, cy, r, st, L, seed);
    else if (shape === 'prism') polyhedron(put, cx, cy, r, st, L, seed);
    else if (shape === 'sentinel') sentinel(put, cx, cy, r, st, L, seed);
    else cloud(put, cx, cy, r, st, L, seed, shape);
  };

  const make = (shape, code, seed) => ({
    body(k, cx, cy, rad, st) {
      const { put, L } = k, r = clamp(rad * 0.78, 6, 58);
      const density = shape === 'star' || shape === 'prism' ? .57 : .80;
      const bodyPut = liquidTrail(put, cx, cy, r, st, L, density);
      formation(shape, bodyPut, cx, cy, r, st, L, seed);
      if (shape !== 'star') responseFlow(put, cx, cy, r, st, L, seed);
      // Telemetry resolves from the cloud for a moment, then returns to sand.
      const phase = fract(st.t * 0.11 + seed * 0.17);
      if (shape !== 'star' && phase > 0.16 && phase < 0.62 && st.sleepy < 0.6) {
        const level = phase < 0.24 || phase > 0.54 ? 2 : Math.min(L, 3);
        const scale = r > 30 ? 2 : 1;
        glyph(put, code, cx - code.length * 2 * scale, cy - 2.5 * scale, level, 0, scale);
      }
    },
  });

  R.cindyAvatars = {
    classic: make('hologram', 'C1', 0.3),
    orbit: make('blob', '01', 1.7),
    pixel: make('star', 'C3', 3.1),
    prism: make('prism', 'PX', 4.6),
  };
})();
