// Cindy's shared glass surface for bubbles, task tags and cards. The old stepped
// frame is kept as a compatibility primitive, while visible chrome uses a calm
// rounded silhouette and a soft liquid tail.
(() => {
  const R = window.Roamie;
  if (!R || typeof document === 'undefined') return;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const C = CindyTheme.canvas;
  const MONO = '"Martian Mono", "Cindy Arabic", ui-monospace, monospace';
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const rgba = (h, a) => `rgba(${hex(h).join(',')},${a})`;

  // The outline, clockwise from the top-left; tail: { side: 'top'|'right'|'bottom'|'left', at, to: [x, y] } adds a
  // stepped tail on that side, centred at `at` along it and stepping toward the point `to`.
  function stepped(x, y, w, h, c = 8, tail = null) {
    const s = c / 2, b = y + h, r = x + w;
    const pts = [[x + c, y], [r - c, y], [r - c, y + s], [r - s, y + s], [r - s, y + c], [r, y + c], [r, b - c], [r - s, b - c], [r - s, b - s], [r - c, b - s], [r - c, b],
      [x + c, b], [x + c, b - s], [x + s, b - s], [x + s, b - c], [x, b - c], [x, y + c], [x + s, y + c], [x + s, y + s], [x + c, y + s]];
    if (!tail) return pts;
    // Each side as the path walks it: where it starts, its direction, its outward normal, and the point it follows.
    const SIDE = { top: [[x, y], [1, 0], [0, -1], 0], right: [[r, y], [0, 1], [1, 0], 5], bottom: [[r, b], [-1, 0], [0, 1], 10], left: [[x, b], [0, -1], [-1, 0], 15] }[tail.side];
    if (!SIDE) return pts;
    const [o, e, n, after] = SIDE, len = Math.abs(e[0]) ? w : h;
    // Position along the walked side, kept clear of the corners.
    const w0 = tail.w ?? 12, along = clamp(Math.abs(e[0]) ? (tail.at - o[0]) * e[0] : (tail.at - o[1]) * e[1], c + w0 / 2 + 2, len - c - w0 / 2 - 2);
    const base = [o[0] + e[0] * along, o[1] + e[1] * along];
    const to = tail.to ?? [base[0] + n[0] * 14, base[1] + n[1] * 14];
    const depth = clamp((to[0] - base[0]) * n[0] + (to[1] - base[1]) * n[1], 6, tail.max ?? 18), shift = (to[0] - base[0]) * e[0] + (to[1] - base[1]) * e[1];
    const hs = depth / 3, ws = [w0, w0 * 0.66, w0 * 0.33], ds = [0, shift * 0.45, shift * 0.8];
    const P = (a, d) => [base[0] + e[0] * a + n[0] * d, base[1] + e[1] * a + n[1] * d];
    const t = [P(-ws[0] / 2, 0), P(-ws[0] / 2, hs), P(ds[1] - ws[1] / 2, hs), P(ds[1] - ws[1] / 2, 2 * hs), P(ds[2] - ws[2] / 2, 2 * hs), P(ds[2] - ws[2] / 2, 3 * hs),
      P(ds[2] + ws[2] / 2, 3 * hs), P(ds[2] + ws[2] / 2, 2 * hs), P(ds[1] + ws[1] / 2, 2 * hs), P(ds[1] + ws[1] / 2, hs), P(ws[0] / 2, hs), P(ws[0] / 2, 0)];
    pts.splice(after + 1, 0, ...t);
    return pts;
  }
  const steppedPath = (x, y, w, h, c, tail) => { const p = new Path2D(); stepped(x, y, w, h, c, tail).forEach((q, i) => (i ? p.lineTo(q[0], q[1]) : p.moveTo(q[0], q[1]))); p.closePath(); return p; };

  // One continuous rounded outline, including the speech tail. Keeping it in a
  // single path avoids the seam a separate triangle leaves across the bubble.
  function roundedPath(x, y, w, h, radius = 14, tail = null) {
    const p = new Path2D(), r = clamp(radius, 2, Math.min(w, h) / 2), x1 = x + w, y1 = y + h;
    const insert = (side, from, to, fixed, dir = 1) => {
      const horizontal = side === 'top' || side === 'bottom';
      const line = (v) => horizontal ? p.lineTo(v, fixed) : p.lineTo(fixed, v);
      if (tail?.side !== side) { line(to); return; }
      const at = clamp(tail.at, Math.min(from, to) + 14, Math.max(from, to) - 14);
      const half = clamp((tail.w ?? 18) / 2, 5, 13);
      // The target may be the companion itself, which can sit far away from
      // the card. Use it only for direction: a speech pointer should remain a
      // compact notch on the card instead of stretching across that whole gap.
      const rawTip = tail.to ?? (side === 'top' ? [at, y - 14] : side === 'bottom' ? [at, y1 + 14] : side === 'left' ? [x - 14, at] : [x1 + 14, at]);
      const maxDepth = tail.max ?? 14;
      const depth = side === 'top' ? clamp(y - rawTip[1], 7, maxDepth)
        : side === 'bottom' ? clamp(rawTip[1] - y1, 7, maxDepth)
          : side === 'left' ? clamp(x - rawTip[0], 7, maxDepth)
            : clamp(rawTip[0] - x1, 7, maxDepth);
      const tip = side === 'top' ? [at, y - depth] : side === 'bottom' ? [at, y1 + depth]
        : side === 'left' ? [x - depth, at] : [x1 + depth, at];
      const a = at - half * dir, b = at + half * dir;
      line(a);
      if (horizontal) {
        p.quadraticCurveTo(at - half * .2 * dir, fixed, tip[0], tip[1]);
        p.quadraticCurveTo(at + half * .2 * dir, fixed, b, fixed);
      } else {
        p.quadraticCurveTo(fixed, at - half * .2 * dir, tip[0], tip[1]);
        p.quadraticCurveTo(fixed, at + half * .2 * dir, fixed, b);
      }
      line(to);
    };
    p.moveTo(x + r, y);
    insert('top', x + r, x1 - r, y, 1);
    p.quadraticCurveTo(x1, y, x1, y + r);
    insert('right', y + r, y1 - r, x1, 1);
    p.quadraticCurveTo(x1, y1, x1 - r, y1);
    insert('bottom', x1 - r, x + r, y1, -1);
    p.quadraticCurveTo(x, y1, x, y1 - r);
    insert('left', y1 - r, y + r, x, -1);
    p.quadraticCurveTo(x, y, x + r, y);
    p.closePath();
    return p;
  }

  // Dark glass with a restrained halo, a hairline edge and a diffuse top light.
  function chrome(c, x, y, w, h, o = {}) {
    const path = o.path || roundedPath(x, y, w, h, o.corner ?? 14, o.tail), edge = o.edge || C.ACC;
    c.save();
    c.fillStyle = C.GLASS; c.shadowColor = 'rgba(0,0,0,0.32)'; c.shadowBlur = 22; c.shadowOffsetY = 8; c.fill(path);
    c.shadowColor = rgba(edge, 0.42); c.shadowBlur = 11; c.shadowOffsetY = 0; c.strokeStyle = rgba(edge, .88); c.lineWidth = 1.15; c.stroke(path);
    if (o.glint !== false && w > 30) {
      const g = c.createLinearGradient(x + 12, y, x + Math.min(w * .58, 150), y);
      g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(.34, 'rgba(255,255,255,.48)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      c.shadowBlur = 0; c.strokeStyle = g; c.lineWidth = .8; c.beginPath(); c.moveTo(x + 12, y + 1); c.lineTo(x + Math.min(w * .58, 150), y + 1); c.stroke();
    }
    c.restore();
  }

  const meas = document.createElement('canvas').getContext('2d');
  const textW = (s, font) => { meas.font = font; return meas.measureText(String(s ?? '')).width; };
  // Words typing themselves in; the last couple land white. Returns the full width.
  function typed(c, str, x, y, font, color, u = 1, o = {}) {
    str = String(str ?? '');
    c.save(); c.font = R.rtlFont ? R.rtlFont(str, font) : font; c.textBaseline = o.baseline || 'middle'; c.textAlign = 'left';
    const full = c.measureText(str).width, x0 = o.anchor === 'middle' ? x - full / 2 : o.anchor === 'end' ? x - full : x;
    const n = Math.floor(str.length * clamp(u, 0, 1));
    if (n >= str.length) { c.fillStyle = color; c.fillText(str, x0, y); }
    else if (n > 0) { const head = str.slice(0, Math.max(0, n - 2)); c.fillStyle = color; c.fillText(head, x0, y); c.fillStyle = C.HOT; c.fillText(str.slice(head.length, n), x0 + c.measureText(head).width, y); }
    c.restore();
    return full;
  }
  // Lines of at most w px (a word wider than a line is broken); past max rows the last one ends in an ellipsis.
  function wrapRows(str, w, font, max = Infinity) {
    meas.font = font;
    const fits = (t) => meas.measureText(t).width <= w, rows = [];
    for (const para of String(str ?? '').split('\n')) {
      let row = '';
      for (let wd of para.split(/\s+/).filter(Boolean)) {
        const tr = row ? `${row} ${wd}` : wd;
        if (fits(tr)) { row = tr; continue; }
        if (row) { rows.push(row); row = ''; }
        while (!fits(wd)) { let k = wd.length - 1; while (k > 1 && !fits(wd.slice(0, k))) k--; rows.push(wd.slice(0, k)); wd = wd.slice(k); }
        row = wd;
      }
      rows.push(row);
    }
    if (rows.length > max) {
      const rest = rows.splice(max), full = `${rows[max - 1]} ${rest.join(' ')}`;
      let last = full;
      while (last && !fits(`${last}…`)) last = last.slice(0, -1);
      // End on a whole word when one is close, rather than mid-word.
      const sp = last.lastIndexOf(' ');
      if (full[last.length] !== ' ' && sp > last.length * 0.6) last = last.slice(0, sp);
      rows[max - 1] = `${last.trimEnd()}…`;
    }
    return rows;
  }
  // A hand-drawn ring: a slightly wobbly circle that overshoots where it closes, the same each time for one seed.
  const ringPts = (cx, cy, r, seed = 0) => Array.from({ length: 34 }, (_, i) => {
    const a = -2.2 + (i / 30) * Math.PI * 2, k = 1 + 0.06 * Math.sin(i * 1.7 + seed) + (i > 28 ? 0.08 : 0);
    return [cx + Math.cos(a) * r * k, cy + Math.sin(a) * r * k];
  });
  // The pen's stroke (a dark edge so it reads on white, then the colour with a soft glow), drawn up to u of its length.
  function pen(c, pts, color, w = 2.2, u = 1) {
    const n = Math.max(2, Math.ceil(pts.length * clamp(u, 0, 1)));
    if (u <= 0) return;
    const path = new Path2D(); pts.slice(0, n).forEach((q, i) => (i ? path.lineTo(q[0], q[1]) : path.moveTo(q[0], q[1])));
    c.save(); c.lineCap = 'round'; c.lineJoin = 'round';
    c.strokeStyle = C.EDGE; c.lineWidth = w + 2; c.stroke(path);
    c.shadowColor = rgba(color, 0.7); c.shadowBlur = 6; c.strokeStyle = color; c.lineWidth = w; c.stroke(path);
    c.restore();
  }

  // Compact rounded actions used by approval bubbles. They keep Cindy's accent
  // and tactile states without the old stepped arcade-button silhouette.
  const CHIP_F = `700 11px ${MONO}`;
  const mix = (a, b, k) => `rgb(${hex(a).map((v, i) => Math.round(v + (hex(b)[i] - v) * k)).join(',')})`;
  const chipW = (label) => Math.round(textW(label, CHIP_F) + 22);
  function chip(c, x, y, w, h, label, o = {}) {
    c.save();
    if (o.focus) { c.strokeStyle = C.HOT; c.lineWidth = 1.5; c.stroke(roundedPath(x - 3, y - 3, w + 6, h + 6, 9)); }
    if (o.down) c.translate(0, 1);
    const face = roundedPath(x, y, w, h, 7);
    c.shadowColor = o.filled ? rgba(C.ACC,.28) : 'rgba(0,0,0,.28)'; c.shadowBlur = o.filled ? 10 : 7; c.shadowOffsetY = 3;
    if (o.filled) {
      c.fillStyle = o.hover ? mix(C.ACC, '#ffffff', 0.22) : C.ACC; c.fill(face);
    } else {
      c.fillStyle = C.GLASS; c.fill(face);
      if (o.hover) { c.fillStyle = rgba(C.ACC, 0.12); c.fill(face); }
      c.shadowBlur = 0; c.shadowOffsetY = 0; c.strokeStyle = rgba(C.ACC,.82); c.lineWidth = 1; c.stroke(face);
    }
    c.shadowBlur = 0; c.shadowOffsetY = 0;
    c.font = CHIP_F; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = o.filled ? C.INKDARK : C.TEXT;
    c.fillText(String(label ?? ''), x + w / 2, y + h / 2 + 0.5);
    c.restore();
  }

  R.glass = { get ACC() { return C.ACC; }, get HOT() { return C.HOT; }, get MID() { return C.MID; }, get DEEP() { return C.DEEP; }, get EDGE() { return C.EDGE; }, get GLASS() { return C.GLASS; }, get TEXT() { return C.TEXT; }, get DIM() { return C.DIM; }, get CORAL() { return C.CORAL; }, get NOTE() { return C.NOTE; }, MONO, rgba, stepped, steppedPath, roundedPath, chrome, textW, typed, wrapRows, ringPts, pen, chip, chipW, CHIP_H: 23 };
})();
