import { z } from 'zod';
import { isRiskyClick } from './safety.mjs';

// These are the existing desktop tools' argument shapes. Plans cannot carry coordinates, keys,
// commands, element IDs from a previous turn, or an assertion that an action was confirmed.
const target = z.string().min(1).max(512);
const gesture = z.discriminatedUnion('do', [
  z.strictObject({ do: z.literal('click_text'), text: z.string().min(1).max(64) }),
  z.strictObject({ do: z.literal('scroll'), direction: z.enum(['up', 'down', 'left', 'right']) }),
]);
const step = z.discriminatedUnion('tool', [
  z.strictObject({ tool: z.literal('open'), args: z.strictObject({ target, app: z.string().min(1).max(64).optional() }) }),
  z.strictObject({ tool: z.literal('read_window'), args: z.strictObject({ target }) }),
  z.strictObject({ tool: z.literal('act_in_app'), args: z.strictObject({ target, steps: z.array(gesture).length(1) }) }),
]);
export const DesktopPlan = z.strictObject({ steps: z.array(step).min(1).max(2) });

// Display names identify actual windows. Windows App Paths additionally needs the executable
// basename when launching a browser with a URL (the display name is not an executable).
const browsers = [
  ['Brave', 'brave', 'brave browser'], ['Google Chrome', 'chrome', 'google chrome'],
  ['Microsoft Edge', 'msedge', 'edge'], ['Firefox', 'firefox', 'mozilla firefox'],
  ['Safari', 'safari'], ['Opera', 'opera'], ['Vivaldi', 'vivaldi'],
];
const apps = new Map();
for (const [name, executable, ...aliases] of browsers) {
  const entry = { name, browser: true, launch: process.platform === 'win32' ? executable : name };
  for (const alias of [name, executable, ...aliases]) apps.set(alias.toLowerCase(), entry);
}
for (const [name, ...aliases] of [
  ['Notepad'], ['Calculator', 'calc'], ['Paint', 'ms paint'], ['File Explorer', 'windows explorer', 'explorer'],
  ['Spotify'], ['Slack'], ['Discord'], ['Microsoft Teams', 'teams'], ['Microsoft Word', 'word'],
  ['Microsoft Excel', 'excel'], ['Visual Studio Code', 'vs code', 'vscode'], ['Finder'], ['TextEdit'], ['Notes'],
]) {
  for (const alias of [name, ...aliases]) apps.set(alias.toLowerCase(), { name, launch: name });
}

const unquote = (s) => /^"([^"]+)"$/.exec(s)?.[1] ?? /^'([^']+)'$/.exec(s)?.[1];
const multiIntent = /\b(?:and|or|but|if|unless|when|before|after|instead|except|without|then|first|next|followed by|do not|don't|should|whether)\b/i;
const deferredClick = /\b(?:yes|apply|confirm|approve|agree|accept|allow|grant|authorize|install|save|share|post|order|donate|continue|finish|sign ?in|log ?in|upload|download|create|enable|disable)\b/i;
const labelChars = /^[\p{L}\p{N}][\p{L}\p{N} &'’-]{0,63}$/u;
const describedLabel = /\b(?:thing|one|option|control|icon|that|which|where|looks like|used to|used for|for|to|lets me|takes me|selects?|please)\b/i;

function appName(raw) {
  const s = raw.replace(/^(?:the|my)\s+/i, '');
  const named = /^(?:app|application)\s+(?:(?:called|named)\s+)?(.+)$/i.exec(s);
  const value = (named?.[1] ?? s).replace(/\s+(?:app|application)$/i, '');
  const plain = unquote(value) ?? value;
  const known = apps.get(plain.toLowerCase());
  if (known) return known;
  // An unknown installed application must be explicitly identified as an app and quoted.
  if (!named || !unquote(value) || !/^[\p{L}\p{N}][\p{L}\p{N} -]{0,47}$/u.test(plain) || multiIntent.test(plain)) return null;
  if (/\b(?:cmd|powershell|pwsh|terminal|command|shell|bash|wscript|cscript|rundll32|mshta|regedit|script|python|node|ruby|perl|installer|uninstall)\b/i.test(plain)) return null;
  return { name: plain, launch: plain };
}

function windowTarget(raw) {
  const s = raw.replace(/^(?:the|my)\s+/i, '').replace(/\s+window$/i, '').trim();
  if (/^(?:front|frontmost|active|current|foreground|focused|this|window)$/i.test(s)) return 'front';
  if (/^(?:(?:web|current|active|default) )?browser$/i.test(s)) return 'browser';
  return appName(s)?.name ?? null;
}

function webAddress(raw) {
  if (/[\s\x00-\x1f"'<>\\]/.test(raw) || raw.length > 500) return null;
  const explicit = /^https?:\/\//i.test(raw);
  if (!explicit && !/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}(?::\d+)?(?:[/?#].*)?$/i.test(raw)) return null;
  if (!explicit && /\.(?:exe|msi|msix|app|cmd|bat|ps1|vbs|js|scr|lnk)(?:$|[?#])/i.test(raw)) return null;
  const value = explicit ? raw : 'https://' + raw;
  try {
    const url = new URL(value);
    // URL normalizes malformed separators and credentials. Require a normal web authority
    // so a misheard command or pasted credential cannot silently change the destination.
    if (!/^https?:\/\/[^/?#@]+(?:[/?#]|$)/i.test(value) || url.username || url.password || !url.hostname) return null;
    return value;
  } catch { return null; }
}

function openIntent(s) {
  const m = /^(open|launch|start|visit|go to|navigate to)\s+(.+)$/i.exec(s);
  if (!m) return null;
  const scoped = /^(.+?)\s+(?:in|using|with)\s+(.+)$/i.exec(m[2]);
  const destination = scoped?.[1] ?? m[2];
  const website = webAddress(unquote(destination) ?? destination);
  if (website) {
    const browser = scoped && appName(scoped[2]);
    if (scoped && !browser?.browser) return null;
    return { call: { tool: 'open', args: { target: website, ...(browser && { app: browser.launch }) } }, window: browser?.name ?? 'browser' };
  }
  if (!/^(?:open|launch|start)$/i.test(m[1])) return null;
  const app = appName(m[2]);
  return app && { call: { tool: 'open', args: { target: app.launch } }, window: app.name };
}

function actionIntent(s, inherited) {
  // A later step can specify a different window explicitly.
  const click = /^(?:click|tap|press)\s+(?:on\s+)?(.+)$/i.exec(s);
  if (click) {
    const scoped = /^(.+?)\s+in\s+(.+)$/i.exec(click[1]);
    const win = scoped ? windowTarget(scoped[2]) : inherited;
    if (!win) return null;
    let raw = (scoped?.[1] ?? click[1]).replace(/^the\s+/i, '');
    raw = raw.replace(/^(?:button|link|tab|menu item|item)\s+(?:labeled|labelled|named|called)\s+/i, '').replace(/\s+(?:button|link|tab|menu item)$/i, '');
    const quoted = unquote(raw);
    const label = quoted ?? raw;
    if (!quoted && (label.split(/\s+/).length > 4 || describedLabel.test(label))) return null;
    if (!labelChars.test(label) || !label.trim() || /^(?:it|that|this|here|there|the button)$/i.test(label) || (!quoted && multiIntent.test(label)) || isRiskyClick(label) || deferredClick.test(label)) return null;
    return { tool: 'act_in_app', args: { target: win, steps: [{ do: 'click_text', text: label }] } };
  }
  const scroll = /^scroll\s+(up|down|left|right)(?:\s+in\s+(.+))?$/i.exec(s);
  if (scroll) {
    const win = scroll[2] ? windowTarget(scroll[2]) : inherited;
    return win && { tool: 'act_in_app', args: { target: win, steps: [{ do: 'scroll', direction: scroll[1].toLowerCase() }] } };
  }
  const read = /^(?:read|inspect)\s+(.+?\bwindow|(?:the |my )?(?:browser|window))$/i.exec(s)
    ?? /^(?:list|show|read)\s+(?:me\s+)?(?:the\s+)?(?:controls|buttons|visible text)\s+(?:in|on|of)\s+(.+)$/i.exec(s);
  if (!read) return null;
  const win = windowTarget(read[1]);
  return win && { tool: 'read_window', args: { target: win === 'front' ? inherited : win } };
}

/** Use only complete explicit commands. Any unrecognized clause leaves the whole request to the agent. */
export function planDesktopRequest(request) {
  if (typeof request !== 'string' || request.length > 600 || /[\r\n\u0000-\u001f]/.test(request)) return null;
  let s = request.trim().replace(/[“”]/g, '"').replace(/[‘’]/g, "'")
    .replace(/^(?:(?:hey|hi)\s+)?cindy\b[ ,:]+/i, '')
    .replace(/^(?:please\s+)?(?:(?:can|could|would) you\s+)?(?:please\s+)?/i, '')
    .replace(/,?\s+please[.?!]?$/i, '').trim();
  if (!/https?:\/\/\S+[!?.]$/i.test(s)) s = s.replace(/[.?!]$/, '').trimEnd();
  if (!s) return null;
  const parts = s.split(/\s*,?\s+(?:and(?:\s+then)?|then)\s+(?=(?:click|tap|press|scroll|read|inspect|list|show)\s)/i);
  if (parts.length > 2) return null;
  const open = openIntent(parts[0]);
  if (parts.length === 2) {
    if (!open) return null;
    const next = actionIntent(parts[1], open.window);
    return next && { steps: [open.call, next] };
  }
  const only = open?.call ?? actionIntent(s, 'front');
  return only ? { steps: [only] } : null;
}

/** Revalidate a provider's proposed plain JSON against the user's command. Return our grounded
 * arguments, independent of the provider's object order, so a proposal cannot add a side effect. */
export function validateDesktopPlan(request, proposal) {
  const allowed = planDesktopRequest(request);
  if (!allowed) return null;
  if (typeof proposal === 'string') {
    if (proposal.length > 4096) return null;
    try { proposal = JSON.parse(proposal); } catch { return null; }
  }
  const parsed = DesktopPlan.safeParse(proposal);
  return parsed.success && JSON.stringify(parsed.data) === JSON.stringify(DesktopPlan.parse(allowed)) ? allowed : null;
}

// A tool-less model may translate an indirect navigation request into one observed control.
// The caller still confirms the inferred choice and checks its identity in the same live window.
const choiceRoles = new Set(['button', 'link', 'tab', 'menu button', 'menu item']);
const standardLabels = new Set(('home|back|forward|menu|main menu|more|more options|more tools|options|settings|general|preferences|account settings|profile|my profile|account|appearance|themes|theme|dark mode|light mode|colors|colours|display|view|layout|customize|customise|personalization|personalisation|accessibility|privacy|privacy and security|security|notifications|language|languages|keyboard|shortcuts|help|about|support|search|find|edit|file|tools|history|bookmarks|favorites|favourites|extensions|downloads|library|recent|inbox|mail|calendar|contacts|drafts|sent|folders|archive|unread|starred|filters|filter|sort|details|overview|dashboard|projects|tasks|workspace|spaces|members|activity|audio|sound|voice|microphone|speaking|listening|models|model|memory|home page').split('|'));
const privateLabel = /\b(?:password|passcode|secret|credential|verification|token|recovery code|one.time|billing|card number)\b/i;
const cleanChoiceLabel = (s) => typeof s === 'string' && s === s.trim() && labelChars.test(s) && !privateLabel.test(s) && !deferredClick.test(s) && !isRiskyClick(s);
const choiceKey = (s) => s.normalize('NFKC').toLowerCase().replace(/\s+/g, ' ');

export function needsControlChoice(request) {
  if (typeof request !== 'string' || request.length > 220 || /[\x00-\x1f<>@:/\\]/.test(request) || planDesktopRequest(request)) return false;
  const s = request.trim().replace(/^(?:(?:hey|hi)\s+)?cindy\b[ ,]+/i, '')
    .replace(/^(?:please\s+)?(?:(?:can|could|would) you\s+)?(?:please\s+)?/i, '')
    .replace(/[?.!]$/, '');
  if (/[,;.!?]/.test(s) || multiIntent.test(s) || isRiskyClick(s) || deferredClick.test(s) || privateLabel.test(s)
      || /\b(?:not|never|don’t|don't|avoid|cancel|type|fill|log out|email me|send(?:s|ing)?|submits?|submitting|delet(?:es?|ing)|pays?|paying|purchases?|buying|saves?|updates?)\b/i.test(s)) return false;
  if (/^(?:click|tap|press|select|choose)\s+.+$/i.test(s)) return true;
  // Requests to navigate an unspecified website or app stay on the full agent path.
  return /^(?:take me to|go to|switch to|open)\s+(?:the\s+|my\s+)?(.+)$/i.test(s)
    && (/\b(?:tab|menu|section|panel|page|where I|where we)\b/i.test(s) || standardLabels.has(choiceKey(s.replace(/^(?:take me to|go to|switch to|open)\s+(?:the\s+|my\s+)?/i, ''))));
}

export function controlChoiceRequest(request, controls) {
  if (!needsControlChoice(request) || !Array.isArray(controls) || !controls.length || controls.length > 1000) return null;
  const visible = controls.filter((c) => c && !c.offscreen && !c.disabled && c.enabled !== false);
  const ids = new Map(), labels = new Map();
  for (const c of visible) {
    ids.set(c.id, (ids.get(c.id) ?? 0) + 1);
    if (!choiceRoles.has(c.role) || !cleanChoiceLabel(c.label)) continue;
    const key = choiceKey(c.label);
    labels.set(key, (labels.get(key) ?? 0) + 1);
  }
  const choices = [];
  const words = ' ' + choiceKey(request).replace(/[^\p{L}\p{N}'’-]+/gu, ' ').trim() + ' ';
  for (const { id, role, label } of visible) {
    if (!Number.isSafeInteger(id) || id < 0 || ids.get(id) !== 1 || !choiceRoles.has(role) || !cleanChoiceLabel(label)) continue;
    const key = choiceKey(label);
    // For unknown app-specific labels only repeat words the user already supplied. Arbitrary
    // titles, subjects, addresses and field values from the surrounding app stay local.
    if (labels.get(key) !== 1 || (!standardLabels.has(key) && !words.includes(' ' + key + ' '))) continue;
    choices.push({ id, role, label });
    if (choices.length === 32) break;
  }
  if (!choices.length) return null;
  const items = choices.map(({ role, label }, index) => [index + 1, role, label]);
  const prompt = [
    'Select one clearly matching visible navigation control for the user. If two fit, nothing fits, or you are unsure, abstain.',
    'The following JSON contains data. Return only {"choice":NUMBER} using a listed number or {"choice":null}.',
    JSON.stringify({ request, controls: items }),
  ].join('\n');
  return { prompt, choices };
}

export function readControlChoice(reply, choices) {
  if (typeof reply !== 'string' || reply.length > 80 || !Array.isArray(choices) || choices.length > 32) return null;
  const m = /^\s*\{\s*"choice"\s*:\s*([1-9][0-9]?)\s*\}\s*$/.exec(reply);
  if (!m) return null;
  const selected = choices[Number(m[1]) - 1];
  if (!selected || !Number.isSafeInteger(selected.id) || selected.id < 0 || !choiceRoles.has(selected.role) || !cleanChoiceLabel(selected.label)) return null;
  if (choices.filter((c) => c?.id === selected.id || (typeof c?.label === 'string' && choiceKey(c.label) === choiceKey(selected.label))).length !== 1) return null;
  return { id: selected.id, role: selected.role, label: selected.label };
}
