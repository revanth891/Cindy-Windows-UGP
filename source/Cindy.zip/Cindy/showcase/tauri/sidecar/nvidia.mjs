import { parseLocalModelId } from '@kenkaiiii/gg-core';
export const NVIDIA = {id:'nvidia-nim',label:'NVIDIA',kind:'custom',baseUrl:'https://integrate.api.nvidia.com/v1'};
export const NVIDIA_KEYS='https://build.nvidia.com/settings/api-keys';
export const nvidiaEndpoint = servers => servers.find(s=>s.baseUrl.replace(/\/$/,'')===NVIDIA.baseUrl) ?? NVIDIA;
export function preferredNvidia(models) {
  const names=['nvidia/nemotron-3.5-super-vl-120b-a12b','nvidia/nemotron-3.5-lightning-30b-a3b','nvidia/nemotron-3-super-120b-a12b','meta/llama-3.3-70b-instruct'];
  return names.map(raw=>models.find(m=>parseLocalModelId(m.id)?.rawId===raw)).find(Boolean) ?? models[0];
}
export async function verifyNvidiaKey(key,raw,request=fetch){
  const res=await request(NVIDIA.baseUrl+'/chat/completions',{method:'POST',redirect:'error',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({model:raw,messages:[{role:'user',content:'Reply OK'}],max_tokens:4,stream:true}),signal:AbortSignal.timeout(45000)});
  await res.body?.cancel();
  if(!res.ok)throw Error([401,403].includes(res.status)?'NVIDIA rejected this key.':res.status===429?'NVIDIA rate-limited the connection check. Try again shortly.':'NVIDIA could not start this model ('+res.status+').');
}
