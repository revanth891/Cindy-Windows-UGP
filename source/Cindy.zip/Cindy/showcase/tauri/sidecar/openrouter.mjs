// OpenRouter can list a model even if its serving endpoint only accepts approved apps.
// Its app-specific 403 leaves the rest of the account and the user's chosen backups usable.
export const APP_RESTRICTED = /only available (?:on|to|for) (?:approved |listed )?agentic harnesses|only available (?:on|to|for) (?:approved|allowlisted) (?:apps|applications)|harnesses? (?:listed|found) on https:\/\/openrouter\.ai\/apps/i;
export const POLICY_ROUTE = /no endpoints found (?:that match|matching) (?:your |the )(?:data policy|privacy|guardrail|provider (?:preferences|settings))/i;
export const FREE_DAY = /\bfree-models-per-day\b/i;
export const FREE_TIER_KEY = 'openrouter-free';
export const isFreeRoute = (provider, model) => provider === 'openrouter' && (model === 'openrouter/free' || model?.endsWith(':free'));

// Cindy is a local desktop app with no published application URL.
const headers = { 'X-OpenRouter-Title': 'Cindy', 'User-Agent': 'Cindy' };
// The agent SDK normally retries 429s with backoff. It recognizes "usage limit reached"
// as a hard quota. Keep the original details and HTTP status while classifying this one
// OpenRouter error, so the agent can immediately display its reason or use a selected backup.
async function routerFetch(input, init) {
  const response = await fetch(input, init);
  if (response.status !== 429) return response;
  const body = await response.clone().json().catch(() => null);
  if (!FREE_DAY.test(body?.error?.message)) return response;
  body.error.message = 'Usage limit reached: ' + body.error.message;
  const headers = new Headers(response.headers);
  headers.delete('content-length');
  headers.delete('content-encoding');
  return new Response(JSON.stringify(body), { status: response.status, statusText: response.statusText, headers });
}
export const openRouterOptions = provider => provider === 'openrouter' ? { defaultHeaders: headers, fetch: routerFetch } : {};
