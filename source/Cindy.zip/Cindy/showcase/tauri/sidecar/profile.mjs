// Cindy downstream modification, 2026-11-18: independent application data and
// provider environment. No migration or fallback to legacy credentials.
import os from 'node:os';
import path from 'node:path';
import { readFileSync } from 'node:fs';

export function profilePaths(env = process.env, platform = process.platform, home = os.homedir()) {
  const p = platform === 'win32' ? path.win32 : path.posix;
  const root = env.CINDY_DATA_DIR || (platform === 'win32' && env.LOCALAPPDATA
    ? p.join(env.LOCALAPPDATA, 'CindyData') : p.join(home, '.cindy-data'));
  if (!p.isAbsolute(root)) throw new Error('CINDY_DATA_DIR must be an absolute path.');
  const data = p.normalize(root), gg = p.join(data, 'gg');
  const shellLogs = p.normalize(env.CINDY_SHELL_LOG_DIR || data);
  const relativeLogs = p.relative(data, shellLogs);
  if (!p.isAbsolute(shellLogs) || relativeLogs === '..' || relativeLogs.startsWith(`..${p.sep}`) || p.isAbsolute(relativeLogs)) throw new Error('Cindy native logs must stay inside its profile.');
  return {
    data, gg, config: p.join(data, 'sidekick.json'), store: p.join(data, 'sidekick'),
    auth: p.join(gg, 'auth.json'), env: p.join(gg, '.env'),
    claude: p.join(gg, 'claude-code'), hostId: p.join(gg, 'openai-host-id'),
    registration: p.join(gg, 'openai-chatgpt-client.json'), models: p.join(data, 'models'),
    agents: p.join(data, 'Cindy'), shellLogs,
  };
}

const PROVIDER_ENV = /^(?:GG|OPENAI|ANTHROPIC|CLAUDE|GEMINI|GOOGLE|XAI|GROK|KIMI|MOONSHOT|DEEPSEEK|OPENROUTER|OPENCODE|MINIMAX|MISTRAL|GROQ|CEREBRAS|TOGETHER|FIREWORKS|XIAOMI|ZAI|ZHIPU|DASHSCOPE|QWEN|ARK|SILICONFLOW|FISH|SARVAM|AWS|AZURE|COHERE|HUGGINGFACE|HF)_/i;
const CREDENTIAL_ENV = /(?:^|_)(?:API_KEY|AUTH_TOKEN|ACCESS_TOKEN|REFRESH_TOKEN|SECRET_KEY|PASSWORD|CREDENTIALS)$/i;
export const providerEnvironmentName = name => PROVIDER_ENV.test(name) || CREDENTIAL_ENV.test(name);
const PROVIDER_VALUE = /(?:API_KEY|AUTH_TOKEN|OAUTH_TOKEN|ACCESS_TOKEN|REFRESH_TOKEN|SECRET_KEY|API_BASE|BASE_URL|ENDPOINT|REGION|PROJECT|LOCATION)$/i;

// This intentionally is not a shell/dotenv evaluator: no interpolation, commands,
// multiline values, arbitrary process settings, or loading from a working folder.
export function parseProviderEnvironment(text) {
  const entries = {};
  for (const line of String(text).split(/\r?\n/)) {
    const match = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (!match || !providerEnvironmentName(match[1]) || !PROVIDER_VALUE.test(match[1])) continue;
    let value = match[2];
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    else value = value.replace(/\s+#.*$/, '').trim();
    if (value.includes('\0') || value.length > 16384) throw new Error('Invalid Cindy provider environment value.');
    entries[match[1]] = value;
  }
  return entries;
}

export function prepareProviderEnvironment({ env = process.env, paths = profilePaths(env), read = file => readFileSync(file, 'utf8') } = {}) {
  for (const name of Object.keys(env)) if (providerEnvironmentName(name)) delete env[name];
  // Inherited injection flags must not import code before a child agent starts.
  delete env.NODE_OPTIONS;
  delete env.CINDY_DATA_DIR;
  let text = '';
  try { text = read(paths.env); } catch (error) { if (error.code !== 'ENOENT') throw new Error('Could not read Cindy provider configuration.'); }
  if (text.length > 262144) throw new Error('Cindy provider configuration is too large.');
  Object.assign(env, parseProviderEnvironment(text));
  // Provider .env may carry keys/endpoints, but cannot select another app's vault.
  env.CLAUDE_CONFIG_DIR = path.join(paths.claude, 'config');
  env.CLAUDE_SECURESTORAGE_CONFIG_DIR = env.CLAUDE_CONFIG_DIR;
  env.CINDY_DATA_DIR = paths.data;
  return paths;
}

export const CINDY_PATHS = profilePaths();
