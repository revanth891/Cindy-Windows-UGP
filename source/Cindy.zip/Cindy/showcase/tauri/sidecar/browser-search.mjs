import { setTimeout as delay } from 'node:timers/promises';

// These public search addresses are built from the user's words. No model or search API is required.
export function browserSearchTask(words) {
  const input = String(words || '').trim();
  if (input.length > 400 || /[\n\r<>]/.test(input)) return null;
  let s = input
    .replace(/^(?:(?:uh|um|hi|hey|cindy|please)\b[\s,:]*)+/i, '')
    .replace(/^(?:(?:can|could|would|will) you )?(?:please )?/i, '')
    .replace(/[.!?]+$/, '');
  const launch =
    /^open (?:up )?(?:(?:my|the) )?(browser|brave(?: browser)?|chrome|firefox|edge|youtube) (?:and then|and|then) (?:uh |um )?/i.exec(
      s,
    );
  if (launch) s = s.slice(launch[0].length);
  const intent = /^(search(?: (?:youtube|the web|google))? for|look up|play) (.+)$/i.exec(s);
  if (!intent) return null;
  const playSuffix = /(?:,? (?:and then|and|then) play (?:it|the (?:first|top) (?:result|video)))$/i;
  const play = /^play$/i.test(intent[1]) || playSuffix.test(intent[2]);
  const youtube =
    /\byoutube\b/i.test(intent[1]) ||
    /^youtube$/i.test(launch?.[1] || '') ||
    / on youtube$/i.test(intent[2].replace(playSuffix, '')) ||
    (play && /\b(?:video|trailer|song)\b/i.test(intent[2]));
  if (!youtube && ((!launch && !/the web|google/i.test(intent[1])) || play)) return null;
  const query = intent[2]
    .replace(playSuffix, '')
    .replace(/ on (?:youtube|google)$/i, '')
    .trim();
  if (
    !query ||
    query.length > 220 ||
    /\b(?:and then|but|before you|unless|without|instead|(?:do not|don't) (?:do|open|click|play|submit)|then (?:open|click)|and (?:open|fill|send|click|play|submit)|my (?:inbox|webmail|email|account|password))\b|https?:\/\/|@/i.test(
      query,
    )
  )
    return null;
  const url = new URL(youtube ? 'https://www.youtube.com/results' : 'https://www.google.com/search');
  url.searchParams.set(youtube ? 'search_query' : 'q', query);
  const apps = {
    brave: 'Brave',
    'brave browser': 'Brave',
    chrome: 'Google Chrome',
    edge: 'Microsoft Edge',
    firefox: 'Firefox',
  };
  const app = apps[launch?.[1].toLowerCase()];
  return {
    kind: 'browser-search',
    url: url.href,
    query,
    play,
    first: /the (?:first|top) (?:result|video)$/i.test(intent[2]),
    app,
  };
}

const page = (snap) => {
  try {
    return new URL(snap.window.url);
  } catch {
    return null;
  }
};
const visible = (c) =>
  c.id > 0 && c.label && !c.browserChrome && !c.disabled && !c.offscreen && c.enabled !== false;
const key = (s) => s.normalize('NFKC').toLowerCase();
const terms = (s) => key(s).match(/[\p{L}\p{N}]+/gu) || [];
const isYoutube = (u) => u?.origin === 'https://www.youtube.com' || u?.origin === 'https://youtube.com';
const playback = (snap) =>
  snap.controls.some((c) => visible(c) && /^button$/i.test(c.role) && /^pause(?:\s*\(k\))?$/i.test(c.label));

export async function runBrowserSearch(task, { call, observe, choose, signal, wait = delay }) {
  const check = () => signal?.throwIfAborted();
  const destination = new URL(task.url);
  const match = (snap) => {
    const u = page(snap);
    return (
      u?.origin === destination.origin &&
      u.pathname === destination.pathname &&
      [...destination.searchParams].every(([k, v]) => u.searchParams.get(k) === v)
    );
  };
  async function until(ref, predicate) {
    for (let i = 0; i < 8; i++) {
      check();
      if (i) await wait(Math.min(i * 170, 600), undefined, { signal });
      const next = await observe(ref, signal).catch(() => null);
      check();
      if (next && predicate(next)) return next;
    }
    return null;
  }
  check();
  const windowsApp = {
    'Google Chrome': 'chrome',
    'Microsoft Edge': 'msedge',
    Brave: 'brave',
    Firefox: 'firefox',
  };
  await call('open', {
    target: task.url,
    ...(task.app && { app: process.platform === 'win32' ? windowsApp[task.app] : task.app }),
  });
  const opened = await until(task.app || 'browser', match);
  if (!opened) return 'I sent the search to the browser but couldn’t verify the results page.';
  if (!task.play) return `Opened search results for “${task.query}”.`;
  const ref = 'window:' + opened.window.id;
  const wanted = terms(task.query).filter(
    (w) =>
      !['the', 'latest', 'new', 'newest', 'official', 'video', 'a', 'an', 'for', 'on', 'of', 'please'].includes(
        w,
      ),
  );
  function results(snap) {
    return snap.controls.filter(
      (c) =>
        visible(c) &&
        /^(?:hyperlink|link)$/i.test(c.role) &&
        !/\b(?:sponsored|advertisement)\b/i.test(c.label) &&
        wanted.length &&
        wanted.every((w) => terms(c.label).includes(w)),
    );
  }
  const loaded = await until(ref, (s) => match(s) && results(s).length > 0);
  if (!loaded) return 'The results are open. I couldn’t identify a video matching the words I heard.';
  const rows = results(loaded);
  const choices = rows.filter((c) => rows.filter((other) => other.label === c.label).length === 1);
  if (!choices.length) return 'The results contain duplicate titles. I couldn’t identify a unique video.';
  const pick =
    choices.length === 1 || task.first
      ? choices[0]
      : await choose('Which video should I play?', choices, signal);
  if (!pick) return 'I left the search results open.';
  const click = async (s, c) => {
    check();
    return call('act_in_app', { target: ref, steps: [{ do: 'click', id: c.id }] }, s);
  };
  const now = await observe(ref, signal);
  const hits = match(now) ? results(now).filter((c) => c.id === pick.id && c.label === pick.label) : [];
  if (hits.length !== 1) return 'The results changed before I could open that video.';
  await click(now, hits[0]);
  const watch = (s) => {
    const u = page(s);
    return isYoutube(u) && u.pathname === '/watch' && !!u.searchParams.get('v');
  };
  const player = await until(
    ref,
    (s) =>
      watch(s) &&
      (playback(s) ||
        s.controls.some((c) => visible(c) && /^button$/i.test(c.role) && /^play(?:\s*\(k\))?$/i.test(c.label))),
  );
  if (!player) return 'I selected the video but couldn’t verify its player.';
  if (playback(player)) return `Playing “${pick.label}”.`;
  const fresh = await observe(ref, signal);
  if (fresh.window.url !== player.window.url) return 'The video page changed before playback.';
  if (playback(fresh)) return `Playing “${pick.label}”.`;
  const buttons = fresh.controls.filter(
    (c) => visible(c) && /^button$/i.test(c.role) && /^play(?:\s*\(k\))?$/i.test(c.label),
  );
  if (buttons.length === 1) {
    await click(fresh, buttons[0]);
    if (await until(ref, (s) => s.window.url === fresh.window.url && playback(s)))
      return `Playing “${pick.label}”.`;
  }
  return 'The video is open. I couldn’t verify that playback started.';
}
