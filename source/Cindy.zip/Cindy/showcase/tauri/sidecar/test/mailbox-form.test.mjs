import assert from 'node:assert/strict';
import test from 'node:test';
import { desktopTask, executeDesktopTask } from '../desktop-task.mjs';

const question = 'Find a mail asking me to fill a form, fill it from memory and ask me before submitting.';
const subject = 'Please complete the campus registration form';
const link = 'Campus registration form';
const oldLink = 'Previously completed forms';
const email = 'mira@example.test';
const origin = 'https://forms.example.test';
const row = (id, label, role = 'link') => ({ id, role, label, enabled: true, value: '' });
const browser = (id, title, url) => ({ id, title, url, app: 'Fixture Browser' });

// Snapshots behave like native accessibility reads: edits on a later page cannot modify an earlier observation.
function mailbox(options = {}) {
  const controller = new AbortController();
  const events = [];
  const inbox = {
    window: browser(41, 'Inbox', 'https://mail.example.test/inbox'),
    controls: [row(1, 'Inbox'), row(2, oldLink), row(3, subject, 'row')],
  };
  const message = {
    window: browser(41, subject, 'https://mail.example.test/message/3'),
    controls: [row(1, 'Inbox'), row(2, oldLink), ...(options.oldOnly ? [] : [row(3, link)])],
  };
  const form = {
    window: browser(91, 'Campus registration', options.formUrl ?? origin + '/campus'),
    controls: [row(1, 'Email', 'text field'), row(2, 'Submit', 'button')],
  };
  if (options.multiple) {
    inbox.controls.push(row(4, 'Action required: fill the course survey form', 'row'));
    message.controls.push(row(4, 'Course feedback survey'));
  }
  if (options.linkHref) message.controls.find((c) => c.label === link).href = options.linkHref;
  if (options.resultsSubject) inbox.controls.push(row(5, options.resultsSubject, 'row'));
  if (options.unknownField) form.controls.push(row(3, 'Programme', 'text field'));
  if (options.campus) {
    for (const view of [inbox,message,form]) view.window.app = 'Brave Browser';
    inbox.window.url = 'https://nwm.iitk.ac.in/?_task=mail&_mbox=INBOX';
    message.window.url = 'https://nwm.iitk.ac.in/?_task=mail&_uid=3';
  }
  const login = {window:browser(41,'IIT Kanpur Webmail','https://nwm.iitk.ac.in/'),
    controls:[row(1,'Username','text field'),{...row(2,'Password','text field'),password:true},row(3,'Login','button')]};
  login.window.app = 'Brave Browser';
  if (options.challenge) login.controls.push(row(4,'Verification code','text field'));
  let page = options.launch ? {window:browser(20,'Desktop',''),controls:[]} : inbox;
  let pendingList=options.delayedList || 0;
  const runtime = {
    actions: () => true, signal: controller.signal, facts: () => [{ id: 'f1', text: 'My email is ' + email }],
    async observe(ref, signal) {
      signal?.throwIfAborted();
      assert.ok(ref === 'front' || ref === 'window:' + page.window.id, 'wrong window read: ' + ref);
      events.push({ type: 'read', title: page.window.title, email: page === form ? form.controls[0].value : undefined });
      if (page===inbox && pendingList-- > 0) return {...structuredClone(page),controls:[]};
      return structuredClone(page);
    },
    async choose(question, choices) {
      events.push({ type: 'choose', question, labels: choices.map((c) => c.label) });
      if (options.cancelChoice) return null;
      const wanted = question.includes('message') ? subject : link;
      return choices.find((c) => c.label === wanted);
    },
    async confirmFill(destination) {
      events.push({ type: 'fill approval', destination });
      if (options.redirectAfterApproval) form.window.url = 'https://other.example.test/different-form';
      if (options.abortAfterApproval) controller.abort();
      return options.allowFill !== false;
    },
    async call(tool, args, snapshot) {
      controller.signal.throwIfAborted();
      if (tool === 'open') {
        assert.deepEqual(args,{target:'https://nwm.iitk.ac.in/',app:'Brave'});
        events.push({type:'launch'}); page = options.login ? login : inbox; return;
      }
      if (tool === 'use_saved_login') {
        assert.equal(page,login); assert.equal(args.url, login.window.url);
        events.push({type:'select saved account'}); return;
      }
      assert.equal(tool, 'act_in_app');
      assert.equal(args.target, 'window:' + page.window.id);
      assert.deepEqual(snapshot.window, page.window);
      assert.equal(args.steps.length, 1);
      const step = args.steps[0], control = page.controls.find((c) => c.id === step.id);
      assert.ok(control, 'action on unobserved control');
      if (step.do === 'click' && page === login) {
        assert.equal(control.label,'Login'); events.push({type:'sign in'}); page=inbox;
      } else if (step.do === 'click' && page === inbox) {
        assert.equal(control.label, subject);
        events.push({ type: 'open message' }); page = message;
      } else if (step.do === 'click' && page === message) {
        assert.equal(control.label, link);
        events.push({ type: 'open form' }); page = form;
      } else if (step.do === 'fill' && page === form) {
        assert.equal(control.label, 'Email');
        assert.equal(step.text, email);
        assert.deepEqual(step.expectedControl, { label: control.label, role: control.role });
        events.push({ type: 'write' });
        if (!options.dropWrite) control.value = step.text;
        if (options.appliedThenFailed) throw new Error('Native write acknowledgement timed out');
      } else if (step.do === 'click' && page === form && control.label === 'Submit') {
        // The real act_in_app tool owns this prompt. A distinct guard here detects an accidental direct submit.
        events.push({ type: 'submit approval', observedValue: form.controls[0].value });
        if (!options.allowSubmit) throw new Error('The form was left unsubmitted.');
        events.push({ type: 'submitted' });
      } else assert.fail('Unexpected action ' + JSON.stringify(step));
    },
  };
  return {
    events, form, count: (type) => events.filter((e) => e.type === type).length,
    run: (input = question) => {
      const task = desktopTask(input);
      assert.equal(task?.kind, 'mail-form', 'ordinary typed request should use the mail workflow');
      return executeDesktopTask(task, runtime);
    },
  };
}

const guided = 'Open Brave, log in to my IITK webmail, open the email titled "' + subject + '" and fill the form from memory. Stop before submitting.';
test('guided Brave path opens once, selects a saved account once and leaves the filled form open',async()=>{
  const f=mailbox({campus:true,launch:true,login:true,resultsSubject:'Please complete another registration form',allowSubmit:true});
  assert.match(await f.run(guided),/Filled and verified Email/);
  assert.deepEqual(f.events.filter(e=>e.type!=='read').map(e=>e.type),
    ['launch','select saved account','sign in','open message','open form','fill approval','write']);
});
test('guided path reuses the active signed-in inbox',async()=>{
  const f=mailbox({campus:true});
  assert.match(await f.run(guided),/Filled and verified/);
  assert.equal(f.count('launch')+f.count('select saved account')+f.count('submitted'),0);
});
test('guided path waits for the message list when only the title has loaded',async()=>{
  const f=mailbox({campus:true,delayedList:2});
  assert.match(await f.run(guided),/Filled and verified/);
  assert.equal(f.count('open message'),1);
});
test('MFA and a missing explicit sign-in request hand control to the user',async()=>{
  for (const [challenge,input] of [[true,guided],[false,'Open my IITK inbox and fill the form']]) {
    const f=mailbox({campus:true,launch:true,login:true,challenge});
    assert.match(await f.run(input),/Finish signing in/);
    assert.equal(f.count('select saved account')+f.count('sign in')+f.count('write'),0);
  }
});

test('two message subjects and two form links each need a choice; review and submission each need approval', async () => {
  const f = mailbox({ multiple: true, allowSubmit: true });
  assert.match(await f.run(), /verified Email/i);
  assert.deepEqual(f.events.filter((e) => e.type === 'choose').map((e) => e.labels), [
    [subject, 'Action required: fill the course survey form'], [link, 'Course feedback survey'],
  ]);
  assert.deepEqual(f.events.filter((e) => e.type !== 'read').map((e) => e.type), [
    'choose', 'open message', 'choose', 'open form', 'fill approval', 'write', 'submit approval', 'submitted',
  ]);
  assert.equal(f.events.find((e) => e.type === 'fill approval').destination, origin);
  const written = f.events.findIndex((e) => e.type === 'write');
  const submit = f.events.findIndex((e) => e.type === 'submit approval');
  assert.ok(f.events.slice(written + 1, submit).some((e) => e.type === 'read' && e.email === email));
  assert.equal(f.events[submit].observedValue, email);
});

test('a find-only request opens just the requested message', async () => {
  const f = mailbox();
  assert.match(await f.run('Find a message asking me to fill a form'), /contains a form link/);
  assert.equal(f.count('open message'), 1);
  assert.equal(f.count('open form'), 0);
  assert.equal(f.count('fill approval'), 0);
});

test('a link already visible in the inbox cannot be treated as a link from the message', async () => {
  const f = mailbox({ oldOnly: true });
  assert.match(await f.run(), /couldn.t verify a form link/);
  assert.equal(f.count('open message'), 1);
  assert.equal(f.count('open form') + f.count('write'), 0);
});

test('an old survey-results announcement is not a request to fill a form', async () => {
  const f = mailbox({ resultsSubject: 'Survey results published yesterday' });
  await f.run('Find a message asking me to fill a form');
  assert.equal(f.count('choose'), 0, 'a results announcement must not compete with an actionable subject');
  assert.equal(f.count('open message'), 1);
});

test('rejects non-HTTPS, a changed explicit destination, and a redirect after approval', async () => {
  const plain = mailbox({ formUrl: 'http://forms.example.test/campus' });
  assert.match(await plain.run(), /couldn.t verify a form/);
  assert.equal(plain.count('fill approval') + plain.count('write'), 0);
  const wrongForm = mailbox({ linkHref: origin + '/campus?group=1', formUrl: origin + '/campus?group=2' });
  assert.match(await wrongForm.run(), /couldn.t verify a form/);
  assert.equal(wrongForm.count('fill approval') + wrongForm.count('write'), 0);
  const redirected = mailbox({ redirectAfterApproval: true });
  assert.match(await redirected.run(), /destination changed/i);
  assert.equal(redirected.count('fill approval'), 1);
  assert.equal(redirected.count('write') + redirected.count('submit approval'), 0);
});

test('canceling at message selection, fill approval, or the submission prompt preserves the corresponding boundary', async () => {
  const choice = mailbox({ multiple: true, cancelChoice: true });
  await choice.run();
  assert.equal(choice.count('open message'), 0);
  const fill = mailbox({ allowFill: false });
  await fill.run();
  assert.equal(fill.count('write') + fill.count('submit approval'), 0);
  const abort = mailbox({ abortAfterApproval: true });
  await assert.rejects(abort.run(), { name: 'AbortError' });
  assert.equal(abort.count('write') + abort.count('submit approval'), 0);
  const submit = mailbox({ allowSubmit: false });
  await assert.rejects(submit.run(), /unsubmitted/);
  assert.equal(submit.form.controls[0].value, email);
  assert.equal(submit.count('submit approval'), 1);
  assert.equal(submit.count('submitted'), 0);
});

test('missing memory keeps unknown fields blank and each attempted write is reconciled exactly once', async () => {
  const partial = mailbox({ unknownField: true, appliedThenFailed: true });
  assert.match(await partial.run(), /verified Email.*review Programme/is);
  assert.equal(partial.form.controls[2].value, '');
  assert.equal(partial.count('write'), 1);
  assert.equal(partial.count('submit approval'), 0);
  const dropped = mailbox({ dropWrite: true });
  assert.match(await dropped.run(), /could not be verified/i);
  assert.equal(dropped.form.controls[0].value, '');
  assert.equal(dropped.count('write'), 1);
  assert.equal(dropped.count('submit approval'), 0);
});
