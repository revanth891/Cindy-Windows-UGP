import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs/promises';

const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'cindy-history-'));
process.env.CINDY_DATA_DIR = tmp;
try {
  const { historyIndex, historySession, historyTurns, projectTurns, savedCards, windowKey } = await import('../history.mjs');
  const { newSession, saveSession, archiveFolded, SUMMARY_HEAD } = await import('../store.mjs');
  const chat = newSession('test', 'local');
  const older = [{ role:'user',content:'Show the key.' },{ role:'assistant',content:[{ type:'thinking',thinking:'internal' },{type:'text', text:'Earlier reply.'}] }];
  await archiveFolded(chat.id, older);
  const stamped = '[Thu, Nov 19, 2026 3:15 PM Asia/Calcutta] Compare A and B.';
  chat.messages = [{role:'user',content:SUMMARY_HEAD + '\nSummary.'},{role:'user',content:stamped},{role:'assistant',content:'internal draft'}];
  const cards = savedCards([{marks:[{kind:'note',text:'Read this',action:{do:'open',url:'https://example.org'}},{kind:'open',url:'https://example.org'},{kind:'clip',at:{id:1}}]}]);
  assert.equal(cards.length,1); assert.equal(cards[0].action, undefined);
  chat.windows = {[windowKey(stamped)]:{question:'Compare A and B.',answer:'Displayed reply.',cards}};
  await saveSession(chat);
  const loaded = await historySession(chat.id);
  const rows = await historyTurns(loaded);
  assert.deepEqual(rows.map(t=>t.answer),['Earlier reply.','Displayed reply.']);
  assert.equal(rows[1].question,'Compare A and B.'); assert.deepEqual(rows[1].cards,cards);
  assert.equal(JSON.stringify(rows).includes('internal'),false);
  assert.equal((await historyIndex())[0].id, chat.id);
  assert.equal(await historySession('../sidekick'),null);
  assert.equal(windowKey([{type:'text',text:stamped},{type:'image',data:'fixture'}]),windowKey([{type:'text',text:stamped},{type:'text',text:'screen placeholder'}]));
  assert.equal(projectTurns([{role:'user',content:'(System, not the user: test)'},{role:'assistant',content:'Private reminder'}]).length,0);
  console.log('history tests: passed');
} finally { await fs.rm(tmp,{recursive:true,force:true}); }
