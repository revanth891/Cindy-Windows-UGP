import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs/promises';
import {createArtifacts} from '../artifacts.mjs';

const dir=await fs.mkdtemp(path.join(os.tmpdir(),'cindy-preview-'));
try {
  const events=[];
  const tabs=createArtifacts({show:()=>{},publish:m=>events.push(m),theme:()=>({theme:'dark',accent:'#ff0000'})});
  const md=path.join(dir,'report.md'), image=path.join(dir,'figure.png');
  await fs.writeFile(md,'# First');
  await fs.writeFile(image,Buffer.from([137,80,78,71]));
  await tabs.open(md);
  const first=events.at(-1).tabs[0];
  await tabs.open(image);
  assert.equal(events.at(-1).tabs.length,2);
  await tabs.handle({type:'preview_select',id:first.id});
  assert.equal(events.at(-1).active,first.id);
  await tabs.handle({type:'preview_content',id:first.id,rev:first.rev});
  assert.equal(events.at(-1).data,'# First');
  const count=events.length;
  for(const src of ['../outside.png','https://example.org/p.png','file:///etc/passwd']) {
    await tabs.handle({type:'preview_image',id:first.id,rev:first.rev,src});
    assert.equal(events.length,count);
  }
  await tabs.handle({type:'preview_image',id:first.id,rev:first.rev,src:'figure.png'});
  assert.equal(events.at(-1).mime,'image/png');
  await fs.writeFile(md,'# Updated');
  await tabs.open(md);
  assert.equal(events.at(-1).tabs.length,2);
  assert.equal(events.at(-1).tabs[0].rev,first.rev+1);
  await tabs.handle({type:'preview_close',id:first.id});
  assert.equal(events.at(-1).tabs.length,1);
  assert.equal(events.at(-1).tabs[0].id,events.at(-1).active);
  console.log('artifact preview tests: passed');
} finally { await fs.rm(dir,{recursive:true,force:true}); }
