// Cindy's isolated profile: synthetic environment/files only, no credentials or network.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { profilePaths, parseProviderEnvironment, prepareProviderEnvironment } from '../profile.mjs';
import { disabledUpdates } from '../updates.mjs';

const win = profilePaths({ LOCALAPPDATA: 'C:\\Users\\Test\\AppData\\Local', CINDY_DATA_DIR: 'C:\\old-profile' }, 'win32', 'C:\\Users\\Test');
assert.equal(win.data, 'C:\\Users\\Test\\AppData\\Local\\CindyData');
assert.equal(win.auth, path.win32.join(win.data, 'gg', 'auth.json'));
assert.equal(win.config, path.win32.join(win.data, 'sidekick.json'));
assert.equal(win.store, path.win32.join(win.data, 'sidekick'));
assert.equal(win.claude, path.win32.join(win.data, 'gg', 'claude-code'));
assert.equal(win.hostId, path.win32.join(win.data, 'gg', 'openai-host-id'));
assert.equal(win.registration, path.win32.join(win.data, 'gg', 'openai-chatgpt-client.json'));
assert.equal(profilePaths({}, 'linux', '/home/test').data, '/home/test/.cindy-data');
assert.throws(() => profilePaths({ CINDY_DATA_DIR: 'relative' }, 'win32', 'C:\\Users\\Test'), /absolute/);
assert.throws(() => profilePaths({ CINDY_DATA_DIR: 'C:\\private', CINDY_SHELL_LOG_DIR: 'C:\\shared' }, 'win32', 'C:\\Users\\Test'), /inside its profile/);

const own = profilePaths({ CINDY_DATA_DIR: path.resolve('synthetic-profile') });
const environment = {
  CINDY_DATA_DIR: own.data, CINDY_DATA_DIR: '/shared-cindy', HOME: '/actual-home', USERPROFILE: '/actual-home',
  OPENAI_API_KEY: 'synthetic-upstream-key', ANTHROPIC_API_KEY: 'synthetic-other-key', GG_CONFIG_DIR: '/shared-gg',
  CLAUDE_CONFIG_DIR: '/shared-claude', CLAUDE_SECURESTORAGE_CONFIG_DIR: '/shared-secure',
  GOOGLE_APPLICATION_CREDENTIALS: '/shared-google.json', NODE_OPTIONS: '--import /shared-inject.mjs',
  PATH: '/system/tools', CINDY_HANDS: '/cindy/bundled/hands', FAKE_LOG: '/test/log',
};
const reads = [];
prepareProviderEnvironment({ env: environment, paths: own, read: file => {
  reads.push(file);
  return 'OPENAI_API_KEY=synthetic-cindy-key\nGEMINI_API_KEY="synthetic-gemini"\nOPENAI_BASE_URL=https://example.invalid\nHOME=/replacement\nNODE_OPTIONS=--import /bad\nCLAUDE_CONFIG_DIR=/shared\nGOOGLE_APPLICATION_CREDENTIALS=/shared\n';
} });
assert.deepEqual(reads, [own.env]);
assert.equal(environment.OPENAI_API_KEY, 'synthetic-cindy-key');
assert.equal(environment.GEMINI_API_KEY, 'synthetic-gemini');
for (const removed of ['ANTHROPIC_API_KEY', 'GG_CONFIG_DIR', 'GOOGLE_APPLICATION_CREDENTIALS', 'NODE_OPTIONS', 'CINDY_DATA_DIR']) assert.equal(environment[removed], undefined, removed);
assert.equal(environment.HOME, '/actual-home'); assert.equal(environment.USERPROFILE, '/actual-home');
assert.equal(environment.PATH, '/system/tools'); assert.equal(environment.CINDY_HANDS, '/cindy/bundled/hands');
assert.equal(environment.CLAUDE_CONFIG_DIR, path.join(own.claude, 'config'));
assert.equal(environment.CLAUDE_SECURESTORAGE_CONFIG_DIR, environment.CLAUDE_CONFIG_DIR);
const missing = { OPENAI_API_KEY: 'synthetic-shared' };
prepareProviderEnvironment({ env: missing, paths: own, read: () => { throw Object.assign(new Error('missing'), { code: 'ENOENT' }); } });
assert.equal(missing.OPENAI_API_KEY, undefined, 'a missing own env never restores inherited keys');
assert.throws(() => prepareProviderEnvironment({ env: {}, paths: own, read: () => { throw Object.assign(new Error('sensitive details'), { code: 'EACCES' }); } }), /^Error: Could not read Cindy provider configuration\.$/);
assert.deepEqual(parseProviderEnvironment('export FISH_API_KEY="$(nothing-is-executed)"\nUNKNOWN=ignored'), { FISH_API_KEY: '$(nothing-is-executed)' });

let changed = 0; const notes = [];
const updates = disabledUpdates({ changed: () => changed++, notify: note => notes.push(note), now: () => 123 });
updates.check(); updates.status({ state: 'available', version: '999.0.0' });
assert.equal(changed, 0); assert.equal(updates.state.available, null);
updates.check(true); updates.install();
assert.equal(changed, 2); assert.equal(notes.length, 2);
assert.equal(updates.state.installing, false); assert.equal(updates.state.checking, false);
assert.equal(updates.state.enabled, false); assert.match(updates.state.result.error, /disabled/);

// A real isolated storage write does not touch a neighboring upstream sentinel.
const temporary = fs.realpathSync.native(fs.mkdtempSync(path.join(os.tmpdir(), 'cindy-profile-check-')));
try {
  const isolated = path.join(temporary, 'cindy'), shared = path.join(temporary, 'cindy-shared');
  fs.mkdirSync(shared); fs.writeFileSync(path.join(shared, 'sidekick.json'), '{"sentinel":"unchanged"}');
  const child = spawnSync(process.execPath, ['--input-type=module', '-e', `
    import assert from 'node:assert/strict';
    import path from 'node:path';
    await import('./profile-init.mjs');
    globalThis.fetch=()=>{throw new Error('Network is forbidden in this fixture');};
    const {CINDY_PATHS:p}=await import('./profile.mjs');
    const {AuthStorage,claudeCodeEnv}=await import('@kenkaiiii/gg-core');
    const auth=new AuthStorage(p.auth);
    assert.deepEqual(await auth.listProviders(),[]);
    await auth.setCredentials('gemini-api',{accessToken:'synthetic-only',refreshToken:'',expiresAt:Date.now()+86400000});
    assert.deepEqual(await auth.listProviders(),['gemini-api']);
    assert.equal(auth.path,p.auth);
    assert.equal(claudeCodeEnv({home:p.claude}).CLAUDE_CONFIG_DIR,path.join(p.claude,'config'));
    const {checkRead,checkWrite,classifyCommand,BLOCK}=await import('./safety.mjs');
    for(const file of [p.auth,p.registration,path.join(p.claude,'config','.credentials.json'),path.join(p.store,'secrets.json')]){
      assert.equal(checkRead(file, process.cwd()).level,BLOCK,file);
      assert.equal(checkWrite(file, process.cwd(),{own:p.data}).level,BLOCK,file);
      assert.equal(classifyCommand('cat "'+file+'"',process.cwd()).level,BLOCK,file);
    }
    const s=await import('./store.mjs');
    await s.writeJson(path.join(s.DIR,'memory.json'),{synthetic:true});
    assert.equal(s.DIR,path.join(process.env.CINDY_DATA_DIR,'sidekick'));
  `], { cwd: new URL('..', import.meta.url), env: { ...process.env, CINDY_DATA_DIR: isolated, CINDY_DATA_DIR: shared }, encoding: 'utf8' });
  assert.equal(child.status, 0, child.stderr);
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(isolated, 'sidekick', 'memory.json'))), { synthetic: true });
  assert.ok(fs.existsSync(path.join(isolated, 'gg', 'auth.json')));
  assert.equal(fs.readFileSync(path.join(shared, 'sidekick.json'), 'utf8'), '{"sentinel":"unchanged"}');
  assert.deepEqual(fs.readdirSync(shared), ['sidekick.json']);
} finally { fs.rmSync(temporary, { recursive: true, force: true }); }
console.log('Cindy profile isolation and disabled updater: passed');
