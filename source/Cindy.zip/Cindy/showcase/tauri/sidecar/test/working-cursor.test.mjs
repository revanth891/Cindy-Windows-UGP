import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { themeFixture } from './cindy-theme-fixture.mjs';

// Run the production desktop creature and pen clock. Capture the image buffer the renderer paints.
let bitmap;
const canvas = {
  createImageData(width, height) {
    bitmap = { width, height, data: new Uint8ClampedArray(width * height * 4) };
    return bitmap;
  },
};
const screen = vm.createContext({
  CindyTheme: themeFixture(), console, performance, setTimeout, URLSearchParams,
  matchMedia: () => ({ matches: false }), addEventListener() {},
  document: { addEventListener() {}, createElement: () => ({ getContext: () => canvas }) },
});
screen.window = screen;
for (const name of ['core', 'glass', 'agent', 'cindy-avatars', '10-dither', '12-sidekick']) {
  const script = readFileSync(new URL(`../../../cindy/${name}.js`, import.meta.url), 'utf8');
  vm.runInContext(script, screen, { filename: name });
}
const env = { w: 402, h: 300, unit: 340, spawn: { x: 128, y: 128 }, mouse: { active: false, x: -1000, y: -1000 }, transparent: true, sleepy: 0 };
const creature = screen.Roamie.types.find((type) => type.id === 'sidekick').create(env);
creature.resize(env);
assert.equal(env.w / bitmap.width, 2, 'the normal desktop avatar uses two CSS pixels per grain cell');
creature.setForm('small');
assert.equal(env.w / bitmap.width, 2, 'the small avatar keeps its grain pitch');
creature.setForm('cursor');
for (const look of Object.keys(screen.Roamie.cindyAvatars)) {
  creature.setLook(look);
  creature.prepare(env);
  const pitch = env.w / bitmap.width;
  assert.ok(pitch >= 3, `${look} pointer is at least 27 by 45 CSS pixels`);
  const x = Math.round(env.spawn.x / pitch) - 4, y = Math.round(env.spawn.y / pitch) - 7;
  // The upper arrow is a solid diagonal starting exactly at the drawing hotspot.
  for (let row = 0; row <= 8; row++) {
    for (let col = -1; col <= 9; col++) {
      const alpha = bitmap.data[((y + row) * bitmap.width + x + col) * 4 + 3];
      assert.equal(alpha, col >= 0 && col <= row ? 255 : 0, `${look} pointer at (${col}, ${row})`);
    }
  }
}
creature.setForm('small');
const { hand, pen } = creature.agent;
for (const action of ['open', 'click']) {
  const sounds = [];
  screen.Roamie.sfx = { play: (name) => sounds.push(name) };
  creature.agent.hide({ instant: true });
  hand.begin();
  await new Promise(setImmediate);
  assert.equal(creature.form, 'cursor', 'an action from idle reveals the working arrow before the next frame');
  assert.equal(pen.owner, 'hand');
  const [startX] = pen.tip, targetX = startX < env.w / 2 ? 285 : 70;
  hand.at(targetX, 82, action);
  let done = false, reached = false, inTransit = false;
  hand.end().then(() => { done = true; });
  for (let frame = 0; frame < 360 && !done; frame++) {
    creature.update(1 / 60, env);
    await new Promise(setImmediate);
    if (creature.form === 'cursor') {
      const [x, y] = pen.tip;
      const progress = (x - startX) / (targetX - startX);
      if (progress > .1 && progress < .9) inTransit = true;
      if (x === targetX && y === 82) reached = true;
    }
  }
  assert.ok(done && inTransit && reached, `${action} visits the target even when the host already sent the end event`);
  assert.equal(sounds.includes('pip'), action === 'click', 'only an actual click gets a tap');
  assert.equal(creature.form, 'small', 'the pointer returns to the configured size');
  assert.equal(pen.held, false);
}
// Native automation can report several UIA controls before the avatar has finished morphing.
const targets = [[70, 110], [180, 138], [303, 90]];
const visited = [];
hand.begin();
for (const [x, y] of targets) hand.at(x, y, 'click');
let finished = false;
hand.end().then(() => { finished = true; });
for (let frame = 0; frame < 480 && !finished; frame++) {
  creature.update(1 / 60, env);
  await new Promise(setImmediate);
  const target = targets[visited.length];
  if (target && creature.form === 'cursor' && pen.tip.every((v, i) => v === target[i])) visited.push(target);
}
assert.deepEqual(visited, targets);
assert.ok(finished && !pen.held);
hand.begin();
await new Promise(setImmediate);
assert.equal(pen.owner, 'hand');
hand.at(51, 80, 'click');
creature.agent.hide({ instant: true });
await hand.end();
assert.equal(creature.form, 'small', 'cancelling a working cursor restores the selected avatar size');
assert.equal(pen.owner, null);
// The presenter releases the native action only after Orbit's arrow has arrived.
creature.setLook('orbit');
hand.begin();
await new Promise(setImmediate);
for (const [x,y] of [[82,72],[275,144],[91,208]]) {
  let arrived=false, frames=0;
  hand.at(x,y,'aim').then(()=>{arrived=true});
  while (!arrived && frames++ < 60) {creature.update(1/60,env); await new Promise(setImmediate);}
  assert.ok(arrived && frames >= 3 && frames < 30, 'fast glide spans several frames');
  assert.deepEqual(Array.from(pen.tip),[x,y]);
  assert.equal(creature.form,'cursor');
  let tapped=false;
  hand.at(x,y,'field_click').then(()=>{tapped=true});
  for(let i=0; !tapped && i<60; i++){creature.update(1/60,env); await new Promise(setImmediate);}
  assert.ok(tapped);
}
console.log('working cursor tests: passed');
