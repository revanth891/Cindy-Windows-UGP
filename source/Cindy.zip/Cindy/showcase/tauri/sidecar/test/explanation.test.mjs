import assert from 'node:assert/strict';
import { requestsIllustration, explanationFromReply, readDiagramDraft, standaloneIllustration } from '../explanation.mjs';
import { DrawArgs, checkDraw } from '../draw.mjs';
import { createTools } from '../tools.mjs';

for (const ask of ['Draw a diagram on my desktop explaining how a clock works.', 'Explain tides visually', 'Show me a diagram of the layers', 'Please illustrate the process']) {
  assert.ok(requestsIllustration(ask), ask);
}
for (const ask of ['How does the clock work?', 'Text only, no diagram please', "Don't draw any illustration", 'Draw a conclusion from my notes', 'Upload a diagram to this page', 'Draw the circuit as an SVG file', 'Draw a circle around this field', 'How do I draw a star?', 'Click the submit button']) {
  assert.equal(requestsIllustration(ask), false, ask);
}
const sectioned = explanationFromReply('# How a clock works\n## Power\nA battery supplies energy.\n## Oscillator\nA crystal sets a steady frequency.\n## Display\nThe display counts oscillations.');
assert.equal(requestsIllustration('Draw a box around the account name'), false);
assert.equal(requestsIllustration('Generate a Mermaid diagram'), false);
assert.equal(sectioned.marks[0].kind, 'mindmap');
assert.deepEqual(sectioned.marks[0].branches.map((b) => b.text), ['Power', 'Oscillator', 'Display']);
assert.equal(sectioned.marks[0].branches[0].items[0], 'A battery supplies energy.');
assert.deepEqual(checkDraw(DrawArgs.parse({ beats: [sectioned] })), []);
assert.deepEqual(explanationFromReply('Signal → Receiver').marks[0].links, [{ from: '1', to: '2' }]);
assert.equal(explanationFromReply('Signal → Receiver\nThe signal arrives at the receiver.').say, 'The signal arrives at the receiver.');
assert.equal(standaloneIllustration('Draw a diagram on my desktop explaining how rain forms.'), true);
for (const grounded of ['Draw a diagram of my budget', 'Explain this document visually', 'Draw a diagram from https://example.org', 'Open email then show me a diagram of the request', 'Draw a square around the button', 'Draw a map of Antarctica']) {
  assert.equal(standaloneIllustration(grounded), false, grounded);
}
const draft = { title: 'Power', layout: 'sequence', caption: 'Energy passes through two stages.', sections: [
  { label: 'Battery', detail: 'The battery supplies power.' }, { label: 'Motor', detail: 'The motor converts electrical energy to motion.' },
] };
for (const layout of ['sequence', 'topics']) {
  const { beat, answer } = readDiagramDraft(JSON.stringify({ ...draft, layout }));
  assert.deepEqual(checkDraw(DrawArgs.parse({ beats: [beat] })), []);
  assert.equal(beat.marks[0].kind, layout === 'sequence' ? 'flow' : 'mindmap');
  assert.ok(answer.includes(draft.sections[1].detail));
}
assert.equal(readDiagramDraft(JSON.stringify({ ...draft, layout: 'clarification' })).beat, null);
assert.equal(readDiagramDraft('{"title":"incomplete"}'), null);
assert.equal(explanationFromReply('Every orbit involves a continuous change in direction.').marks[0].kind, 'card');
for (const reply of ["I can't draw on the desktop.", "I've created a diagram.", 'A diagram:', '<think>Some reasoning</think>', '```js\nopenWindow()\n```']) assert.equal(explanationFromReply(reply), null);

// A first-visible ACK is insufficient: the renderer must finish. Exercise both failure phases and
// prove a later lookup failure closes the queue and releases the pen.
let inject, made;
const events = [];
made = createTools({
  allowActions: () => false, userName: 'Test', ask: async () => false,
  ui(message) { if (message.e?.type === 'draw') { events.push(message.e); inject(message.e); } },
});
const draw = made.tools.find((t) => t.name === 'draw');
let serial = 0;
const run = (beats) => draw.execute({ beats }, { toolCallId: 'play-' + (++serial) });
const rendered = (e) => { made.ink.started(e.id, e.seg); if (e.last) made.ink.done(e.id); };
const reject = (e) => { for (const b of e.beats) for (const m of b.marks) if (m.part) made.ink.closed(m.part); made.ink.failed(e.id); };
inject = reject;
await assert.rejects(run([sectioned]), /couldn't draw the first beat/);
assert.equal(made.ink.describe(), '', 'a failed card is not listed as on screen');
inject = (e) => { made.ink.started(e.id, e.seg); setImmediate(() => reject(e)); };
await assert.rejects(run([sectioned]), /couldn't finish drawing/);
assert.equal(made.ink.describe(), '');
inject = rendered;
events.length = 0;
const truncated = await run([sectioned, { say: 'The location.', marks: [{ kind: 'target', at: { id: 4 } }] }]);
assert.match(truncated, /Stopped before beat 2/);
assert.equal(events.at(-1).last, true);
assert.deepEqual(events.at(-1).beats, []);
console.log('desktop illustration fallback and renderer acknowledgement tests: passed');
