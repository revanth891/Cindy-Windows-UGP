import fs from 'node:fs';
import vm from 'node:vm';

// Load the same palette used by the browser, without adding a DOM to pure-function tests.
export function themeFixture() {
  const window = {};
  vm.runInNewContext(fs.readFileSync(new URL('../../../cindy/cindy-theme.js', import.meta.url), 'utf8'), {
    window, document: { documentElement: { dataset: {} } }, location: { search: '' },
    URLSearchParams, addEventListener() {},
  });
  return window.CindyTheme;
}
