import assert from 'node:assert/strict';
import { browserActionRequest, browserOutcome, browserProgress } from '../browser-run.mjs';
import { localModels } from '../local.mjs';
import { browserToolCall } from '../browser-fetch.mjs';
import { EchoFilter } from '../reply.mjs';
import { browserSearchTask, runBrowserSearch } from '../browser-search.mjs';

const spoken =
  'Uh hey, can you open my browser and search for the latest Godzilla trailer on YouTube and play it.';
assert.equal(browserActionRequest(spoken), true);
assert.equal(browserActionRequest('How do I open my browser and search YouTube?'), false);
assert.equal(browserActionRequest('Open YouTube without clicking anything'), false);
const user = { role: 'user', content: spoken };
const prose = (content) => ({ role: 'assistant', content: [{ type: 'text', text: content }] });
const call = (name) => ({ role: 'assistant', content: [{ type: 'tool_call', name, args: {} }] });
const result = (isError) => ({
  role: 'tool',
  content: [{ type: 'tool_result', isError, content: [{ type: 'text', text: 'fixture' }] }],
});
const progress = browserProgress(spoken);
const draft = prose('Open YouTube and select a video.');
const correction = progress.followUp([user, draft]);
assert.equal(correction.length, 1);
assert.deepEqual(progress.followUp([user, draft, ...correction, draft]), []);
assert.deepEqual(progress.cleanHistory([user, draft, ...correction, call('act_in_app'), result(false)]), [
  user,
  call('act_in_app'),
  result(false),
]);
assert.equal(
  browserProgress(spoken).followUp([user, call('read_window'), result(false), prose('I opened the page.')])
    .length,
  1,
);
for (const history of [
  [user, prose('Which trailer did you mean?')],
  [user, call('act_in_app'), result(false), prose('Playback started.')],
  [user, call('open'), result(true), prose('Open the page yourself.')],
])
  assert.deepEqual(browserProgress(spoken).followUp(history), []);
assert.match(browserOutcome(draft, 0, false), /without taking a browser action/);
assert.match(browserOutcome(call('open'), 1, false), /couldn’t verify/);
assert.match(browserOutcome(null, 3, true), /step limit/);
assert.equal(browserOutcome(prose('Playback started.'), 2, false), 'Playback started.');

const raw = 'nvidia/nemotron-3.5-super-vl-120b-a12b';
const listed = (url, ids, declaredTools) =>
  localModels([
    {
      endpoint: { id: 'mine', label: 'Server', kind: 'custom', baseUrl: url },
      reachable: true,
      declaredTools,
      models: ids.map((rawId) => ({
        rawId,
        endpointId: 'mine',
        contextWindow: 4096,
        contextWindowKnown: false,
        supportsImages: false,
      })),
    },
  ]);
const nvidia = 'https://integrate.api.nvidia.com/v1';
const [model] = listed(nvidia, [raw, 'nvidia/llama-3.1-nemotron-safety-guard-8b-v3']);
assert.equal(listed(nvidia, [raw, 'nvidia/llama-3.1-nemotron-safety-guard-8b-v3']).length, 1);
assert.ok(model.supportsImages && model.supportsNativeTools && model.contextWindow > 32768);
assert.equal(listed(nvidia, [raw], new Map([[raw, false]]))[0].supportsNativeTools, false);
assert.equal(listed('https://example.org/v1', [raw])[0].toolSupportUnknown, true);
assert.equal(
  listed('https://api.fireworks.ai/inference/v1', ['accounts/fireworks/models/glm-5p3-flash'])[0]
    .supportsNativeTools,
  true,
);
const envelope =
  '<tool_call>\n<function=act_in_app>\n<parameter=target>front</parameter>\n<parameter=steps>[{"do":"click","id":2,"x":null}]</parameter>\n</function>\n</tool_call>';
const offered = new Set(['act_in_app', 'open', 'read_window']);
assert.deepEqual(JSON.parse(browserToolCall(envelope, offered).function.arguments), {
  target: 'browser',
  steps: [{ do: 'click', id: 2 }],
});
for (const bad of [
  envelope + ' extra',
  envelope + envelope,
  envelope.replace('act_in_app', 'run_command'),
  envelope.replace('"x":null', '"confirmed":true'),
  envelope.replace('front', 'Windows Terminal'),
])
  assert.equal(browserToolCall(bad, offered), null);
for (const size of [1, 4, 18, 1000]) {
  const filter = new EchoFilter();
  const input = 'Before ' + envelope + ' after';
  let visible = '';
  for (let i = 0; i < input.length; i += size) visible += filter.push(input.slice(i, i + size));
  assert.equal(visible + filter.flush(), 'Before  after');
}
const search = browserSearchTask(spoken);
assert.equal(search.kind, 'browser-search');
assert.equal(search.play, true);
assert.equal(new URL(search.url).searchParams.get('search_query'), 'the latest Godzilla trailer');
assert.equal(browserSearchTask('How do I search YouTube for a trailer?'), null);
assert.equal(browserSearchTask('Open my browser and search for my inbox and fill a form'), null);
let current = 'results';
const snapshot = () => ({
  window: { id: 7, url: current === 'results' ? search.url : 'https://www.youtube.com/watch?v=fixture' },
  controls:
    current === 'results'
      ? [{ id: 2, role: 'link', label: 'Godzilla official trailer' }]
      : [{ id: 3, role: 'button', label: current === 'playing' ? 'Pause (k)' : 'Play (k)' }],
});
const actions = [];
const response = await runBrowserSearch(search, {
  observe: async () => snapshot(),
  wait: async () => {},
  call: async (name, args) => {
    actions.push(name);
    if (name === 'act_in_app') current = args.steps[0].id === 2 ? 'player' : 'playing';
  },
});
assert.deepEqual(actions, ['open', 'act_in_app', 'act_in_app']);
assert.equal(response, 'Playing “Godzilla official trailer”.');
console.log('Browser action routing, bounded continuation, and provider capabilities passed.');
