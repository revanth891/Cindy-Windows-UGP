import assert from 'node:assert/strict';
import {answerClient,machineTask,zenOrigin} from '../zen-session.mjs';
import {desktopTask} from '../desktop-task.mjs';

assert.equal(zenOrigin('https://zenservices.pages.dev.evil.invalid/'),false);
assert.equal(zenOrigin('http://zenservices.pages.dev/'),false);
assert.equal(machineTask('answer the visible question','https://example.org'),null);
assert.equal(machineTask('answer the visible question','https://zenservices.pages.dev/').kind,'client-question');
assert.equal(machineTask('research on the host and answer the question on the client').kind,'client-question');
const host=machineTask('Open Notepad on the host machine');
assert.equal(host.kind,'host-task');
assert.equal(desktopTask(host.request).steps[0].tool,'open');
assert.equal(machineTask('Open Notepad on the client machine').kind,'client-unsupported');
assert.equal(machineTask('open the host machine and the client machine').kind,'machine-ambiguous');
assert.equal(machineTask('read the question on the client but do not click').readOnly,true);
assert.equal(machineTask('read the question on the client and give me the answer on the host').readOnly,true);
assert.equal(machineTask('research the question on the host and select the right option on the client').readOnly,false);
assert.equal(machineTask('open Notepad on the host and answer a question on the client').kind,'machine-ambiguous');
const view={window:21,device:'Practice',stamp:'v1',image:'fixture'};
const task=machineTask('answer the question on the client');
const runtime={capture:async()=>view,status:()=>{},signal:new AbortController().signal,
  search:async()=> 'Practice index: basalt.',
  model:async(prompt,image)=>image?{kind:'mcq',question:'Which rock?',options:['basalt','granite']}:{answer:'basalt'}};
let allowed=0;
await assert.rejects(answerClient(task,{...runtime,apply:async command=>{
  allowed++;assert.equal(command.window,21);assert.equal(command.label,'basalt');throw Error('The paired device changed.');
}}),/device changed/);
assert.equal(allowed,1,'a failed client write is not tried on the host');
const read=await answerClient({...task,readOnly:true},{...runtime,apply:()=>assert.fail('read-only request changed a client')});
assert.match(read,/basalt/);
console.log('Host and client routing tests: passed');
