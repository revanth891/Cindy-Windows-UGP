import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { themeFixture } from './cindy-theme-fixture.mjs';

const script = readFileSync(new URL('../../../cindy/ink.js', import.meta.url), 'utf8');
const noop = () => {};
function fixture({ failStroke = false, pen } = {}) {
  let strokes = 0;
  const errors = [], events = [];
  const ctx = new Proxy({ stroke() {
    if (failStroke) throw new Error('canvas stroke failed');
    strokes++;
  } }, { get: (object, key) => object[key] ?? noop });
  const host = vm.createContext({
    Roamie: { tiles: [{ creature: { agent: { pen } } }] }, CindyTheme: themeFixture(), innerWidth: 800, innerHeight: 600, devicePixelRatio: 1,
    console: { error: (...args) => errors.push(args) }, addEventListener: noop,
    document: { getElementById: () => null, body: { appendChild: noop }, createElement: () => ({
      setAttribute: noop, style: {}, getContext: () => ctx,
    }) },
    Path2D: class { moveTo() {} lineTo() {} closePath() {} },
    matchMedia: () => ({ matches: true }), performance: { now: () => performance.now() * 100 },
    requestAnimationFrame: (cb) => setTimeout(cb, 1), setTimeout: (cb, ms) => setTimeout(cb, Math.min(2, ms)),
  });
  host.window = host;
  vm.runInContext(script, host);
  const ink = host.Roamie.ink;
  ink.send = (event) => events.push({ ...event, strokes });
  return { ink, events, errors };
}
const beat = (part) => ({ caption: 'Look here.', marks: [{ kind: 'ring', part, at: { rect: [30, 30, 60, 25] } }] });
{
  const { ink, events, errors } = fixture();
  ink.play({ id: 'guide', seg: 0, beats: [beat('p1')] });
  assert.deepEqual(events, [], 'accepting a drawing is not a paint acknowledgement');
  ink.play({ id: 'guide', seg: 1, beats: [], edits: [], last: true });
  await ink.whenIdle();
  assert.deepEqual(errors, []);
  assert.deepEqual(events.map((e) => e.type), ['draw_started', 'draw_done']);
  assert.ok(events[0].strokes > 0, 'the acknowledgement follows a real stroke on the canvas');
}
{
  const { ink, events, errors } = fixture({ failStroke: true });
  ink.play({ id: 'broken', seg: 0, beats: [beat('p2')] });
  ink.play({ id: 'broken', seg: 1, beats: [beat('p3')], last: true });
  await ink.whenIdle();
  ink.play({ id: 'broken', seg: 2, beats: [beat('p4')], last: true });
  assert.ok(errors.length);
  assert.deepEqual(events.filter((e) => e.type === 'ink_closed').map((e) => e.part), ['p2', 'p3', 'p4']);
  assert.deepEqual(events.filter((e) => e.type.startsWith('draw')).map((e) => [e.type, e.seg]), [['draw_failed', 0]]);
  ink.play({ id: 'next', seg: 0, beats: [{ caption: 'Finished.', marks: [] }], last: true });
  await ink.whenIdle();
  assert.deepEqual(events.filter((e) => e.id === 'next').map((e) => e.type), ['draw_started', 'draw_done']);
}
{
  let enter;
  const pen = {
    held: false, owner: 'ink',
    async take() { await new Promise((resolve) => { enter = resolve; }); this.held = true; },
    release() { this.held = false; },
  };
  const { ink, events } = fixture({ pen });
  ink.play({ id: 'cancelled', seg: 0, beats: [beat('p5')], last: true });
  assert.equal(typeof enter, 'function');
  ink.clear({ stop: true });
  enter();
  await ink.whenIdle();
  assert.equal(pen.held, false, 'a cancelled guide releases its pen even if the entrance finishes later');
  assert.deepEqual(events, []);
}
console.log('ink playback tests: passed');
