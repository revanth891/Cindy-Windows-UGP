import assert from 'node:assert/strict';
import { Agent } from '@kenkaiiii/gg-agent';
import { agentEvents } from '../agentstream.mjs';
import { summaryModelFor } from '../brain.mjs';
import { explain } from '../errors.mjs';
import { createLimits, firstFree, limitFrom } from '../limits.mjs';
import { FREE_TIER_KEY, openRouterOptions } from '../openrouter.mjs';

const msg = 'Rate limit exceeded: free-models-per-day. Add 10 credits to unlock 1000 free model requests per day.';
const now = Date.now(), reset = now + 6 * 3600_000;
const free = ['openrouter/free', 'test/model:free'].map(model => ({provider:'openrouter', model, spec:'openrouter:' + model}));
const paid = {provider:'openrouter', model:'test/model', spec:'openrouter:test/model'};
const expected = {kind:'free-day',until:reset};
const limits = createLimits({now: () => now});
const originalFetch = globalThis.fetch;
const calls = [];
try {
  globalThis.fetch = async (url, init) => {
    calls.push(String(url));
    assert.equal(new Headers(init.headers).get('x-openrouter-title'), 'Cindy');
    return Response.json({error:{code:429, message:msg}}, {status:429, headers:{'X-RateLimit-Reset': String(reset)}});
  };
  const agent = new Agent({provider:'openrouter',model:free[0].model,apiKey:'test',baseUrl:'http://fixture.invalid',
    tools:[],maxTurns:1,signal:AbortSignal.timeout(8000),...openRouterOptions('openrouter')});
  await assert.rejects(async () => {
    for await (const event of agentEvents(agent.prompt('Hello'))) if (event.type === 'error') throw event.error;
  }, error => {
    assert.equal(explain('reply',error,{who:'OpenRouter'}).code,'E2C');
    assert.deepEqual(limitFrom(error,now),expected);
    return true;
  });
  assert.equal(calls.length,1,'a daily free limit takes one HTTP request');
  globalThis.fetch = async () => Response.json({error:{code:429, message:'Temporary provider overload'}},{status:429});
  const transient = await openRouterOptions('openrouter').fetch('http://fixture.invalid');
  assert.equal((await transient.json()).error.message, 'Temporary provider overload');
} finally {globalThis.fetch = originalFetch;}

limits.mark(FREE_TIER_KEY,reset,'free-day');
assert.equal(firstFree([...free,paid],limits).pick,paid);
assert.equal(firstFree(free,limits).pick,null,'a free-only selection stays within that tier');
assert.equal(summaryModelFor('openrouter',free[0].model),free[0].model,'background memory uses the selected free route');
assert.equal(summaryModelFor('openrouter',free[1].model),free[1].model);
const restricted = new Error('403: That model is only available on agentic harnesses.');
assert.equal(limitFrom(restricted,now).kind,'missing');
assert.equal(explain('reply',restricted,{who:'OpenRouter'}).code,'E29');
assert.equal(explain('reply',new Error('OpenRouter returned no visible reply.'),{who:'OpenRouter'}).code,'E2B');
console.log('OpenRouter app identity, daily-limit transport, backup scope and model messages passed');
