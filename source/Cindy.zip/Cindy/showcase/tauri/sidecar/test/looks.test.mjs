import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { DEFAULT_VOICE } from '../fish.mjs';
import { themeFixture } from './cindy-theme-fixture.mjs';

const src = (p) => readFileSync(fileURLToPath(new URL(p, import.meta.url)), 'utf8');
const side = src('../sidekick.mjs'), guide = src('../../../onboarding/onboarding.js'), panel = src('../../../panel/panel.js');
const block = side.slice(side.indexOf('const LOOKS = ['), side.indexOf('];', side.indexOf('const LOOKS = [')));
const looks = [...block.matchAll(/\['(\w+)', '([^']+)', (DEFAULT_VOICE|'(\w+)')\]/g)];
assert.deepEqual(looks.map((m) => [m[1],m[2]]), [['classic','Core'],['orbit','Pulse'],['pixel','Orbit'],['prism','Prism']]);
assert.equal(DEFAULT_VOICE, '2680da81de8348a68e1f4dbaa79272f1');
for (const [, id, label] of looks) {
  assert.ok(guide.includes(`['${id}', '${label}']`), `guide offers ${label}`);
  assert.ok(panel.includes(`['${id}', '${label}']`), `panel offers ${label}`);
}
assert.match(side, /const lookName = \(\) => 'Cindy'/);
assert.ok(!/JARVIS|GlayOS|Ultren|Anime Girl|Sarah|Adrian|Rita X/.test(block));

globalThis.window = { Roamie: {} };
new Function(src('../../../cindy/cindy-avatars.js'))();
const family = window.Roamie.cindyAvatars;
assert.deepEqual(Object.keys(family), ['classic','orbit','pixel','prism']);
const base = { t: 1.4, mode: null, heard: false, voice: null, act: null, open: 1, look: [0,0], speed: 0, vx: 0, vy: 0, dragging: false, trail: [[0,0],[0,0],[0,0]], sq: 0, wide: 0, dizzy: 0, happy: 0, sleepy: 0, mouth: null, brow: null };
for (const [id, avatar] of Object.entries(family)) for (const state of [base, {...base,mode:'talk',voice:.9}, {...base,mode:'listen'}, {...base,mode:'think'}, {...base,dragging:true,speed:320,vx:250,vy:40,trail:[[-3,0],[-8,1],[-15,3]]}, {...base,act:'hype'}]) {
  const cells=[]; const k={L:4,put:(x,y,l)=>{assert.ok(Number.isInteger(x)&&Number.isInteger(y),`${id} integer cell`);assert.ok(l>=0&&l<=4,`${id} level`);cells.push([x,y]);}};
  avatar.body(k,50,50,15,state);
  assert.ok(cells.length>90,`${id} body has a dense particle field`);
}
const kit = src('../../../cindy/10-dither.js');
assert.match(kit, /trail: tail\.map/,'physical tail is passed into the sand renderer');
assert.match(kit, /if \(!drawn\(look\)\) drawHands/,'sand forms do not get sprite hands');
assert.match(kit, /if \(!drawn\(look\) && act/,'sand forms do not get game-style icon bubbles');
assert.match(src('../../../desktop.html'), /cindy-avatars\.js/);

// All live renderers share the accent. Switching modes restores the destination palette.
const theme = themeFixture(), liveLed = theme.led, redLed = structuredClone(liveLed);
assert.equal(theme.accent, '#ff0000');
theme.set('dark', '#00a7a0');
assert.equal(theme.accent, '#00a7a0');
assert.strictEqual(theme.led, liveLed);
assert.notDeepEqual(structuredClone(theme.led), redLed);
theme.set('dark');
assert.equal(theme.accent, '#00a7a0', 'refreshing the same mode keeps a custom accent');
theme.set('light');
assert.equal(theme.accent, '#8000ff');
assert.equal(theme.canvas.ACC, theme.color('#78ffe2'));
theme.set('light', '#ffcc00');
theme.set('dark');
assert.equal(theme.accent, '#ff0000');
assert.deepEqual(structuredClone(liveLed), redLed);
console.log('looks tests: passed');
