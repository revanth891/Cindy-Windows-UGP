import assert from 'node:assert/strict';
import { aboutCindy } from '../about.mjs';

const base = { name: 'Cindy', looks: ['Core', 'Pulse', 'Orbit', 'Prism'], mac: false, linux: false, snap: false, pointer: false, voice: false, hotkeys: false };
const mac = aboutCindy({ ...base, mac: true, snap: true, pointer: true, voice: true, hotkeys: true });
const win = aboutCindy(base);
const linux = aboutCindy({ ...base, linux: true, voice: true });
assert.match(mac, /menu bar at the top/);
assert.match(mac, /Ask About an Area/);
assert.match(mac, /Core, Pulse, Orbit and Prism/);
assert.match(win, /bottom right/);
assert.ok(!/Ask About an Area/.test(win));
assert.match(linux, /system tray/);
for (const text of [mac, win, linux]) {
  assert.match(text, /made by drkzen/i);
  assert.match(text, /Save diagnostics/i);
  assert.match(text, /AGPL-3\.0/);
  assert.match(text, /final form submission require confirmation/i);
  assert.ok(!/JARVIS|undefined|\$\{/.test(text));
}
console.log('about tests: passed');
