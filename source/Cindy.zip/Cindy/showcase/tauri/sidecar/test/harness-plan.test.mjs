import assert from 'node:assert/strict';
import {
  DesktopPlan, planDesktopRequest, validateDesktopPlan, needsControlChoice, controlChoiceRequest, readControlChoice,
} from '../harness-plan.mjs';

const open = (target, app) => ({ tool: 'open', args: { target, ...(app && { app }) } });
const read = (target) => ({ tool: 'read_window', args: { target } });
const click = (target, text) => ({ tool: 'act_in_app', args: { target, steps: [{ do: 'click_text', text }] } });
const scroll = (target, direction) => ({ tool: 'act_in_app', args: { target, steps: [{ do: 'scroll', direction }] } });
const brave = process.platform === 'win32' ? 'brave' : 'Brave';
for (const [request, steps] of [
  ['Hey Cindy, could you please open the Notepad app?', [open('Notepad')]],
  ['launch the app called "Example Notes"', [open('Example Notes')]],
  ['Open webmail.iitk.ac.in in Brave', [open('https://webmail.iitk.ac.in', brave)]],
  ['go to https://example.org/?q=one&view=two#anchor', [open('https://example.org/?q=one&view=two#anchor')]],
  ['open example.org in Brave and then click the “Settings” button', [open('https://example.org', brave), click('Brave', 'Settings')]],
  ['Open Notepad, then click File', [open('Notepad'), click('Notepad', 'File')]],
  ['open example.com then scroll down', [open('https://example.com'), scroll('browser', 'down')]],
  ['Read the active window.', [read('front')]], ['Inspect the Brave window', [read('Brave')]],
  ['list the controls in Chrome', [read('Google Chrome')]], ['show me the buttons in my browser', [read('browser')]],
  ['Click "Privacy and security" in Brave', [click('Brave', 'Privacy and security')]],
  ['Click the Back button', [click('front', 'Back')]], ["click the tab labeled 'Library' in Firefox", [click('Firefox', 'Library')]],
  ['scroll left in Notepad', [scroll('Notepad', 'left')]],
]) {
  const actual = planDesktopRequest(request);
  assert.deepEqual(actual, { steps }, request);
  assert.deepEqual(DesktopPlan.parse(actual), actual, request);
  assert.deepEqual(validateDesktopPlan(request, JSON.stringify(actual)), actual, request);
  assert.equal(needsControlChoice(request), false, request);
}

for (const request of [
  '', 'how do I open Notepad?', "Don't open Notepad", 'open a new savings account', 'Visit my university webmail',
  'click File if the clock is running', 'open Brave then fill my details', 'read my notes',
  'click it', 'open something', 'open Notepad then click File then click Help',
  'open cmd', 'open app "PowerShell"', 'open C:\\temp\\payload.exe', 'open example.exe',
  'open javascript:alert(1)', 'open https://user:pw@example.org', 'open https:///missing.authority',
  'open Notepad and delete the file', 'click Submit', 'click "Register and pay"', 'click Allow',
  'click "New task"\nthen send it', 'scroll to the form', 'read the browser window then send the message',
]) assert.equal(planDesktopRequest(request), null, request);

const request = 'open Notepad then click Help';
const steps = planDesktopRequest(request).steps;
for (const proposal of [
  null, '<think>sure</think>', { steps: [] }, { steps, note: 'run now' }, { steps: steps.toReversed() },
  { steps: [open('Calculator'), steps[1]] }, { steps: [steps[0], click('front', 'Help')] },
  { steps: [steps[0], click('Notepad', 'Submit')] }, { steps: [steps[0], steps[1], read('front')] },
  { steps: [{ tool: 'run_command', args: { command: 'calc' } }] },
  { steps: [steps[0], { tool: 'act_in_app', args: { ...steps[1].args, confirmed: true } }] },
  { steps: [steps[0], { tool: 'act_in_app', args: { target: 'Notepad', steps: [{ do: 'key', key: 'Enter' }] } }] },
]) assert.equal(validateDesktopPlan(request, proposal), null);
assert.deepEqual(validateDesktopPlan(request, { steps: steps.map(({ tool, args }) => ({ args, tool })) }), { steps });
assert.equal(validateDesktopPlan('How do I open Notepad?', { steps: [open('Notepad')] }), null);

const paraphrase = 'Click the control that changes how this app looks';
for (const text of [paraphrase, 'Please take me to the appearance section.', 'Choose the tab for earlier activity', 'Can you open preferences?']) {
  assert.equal(needsControlChoice(text), true, text);
}
for (const text of ['What is a tab?', 'Never click this icon', 'Go to my bank', 'open a spreadsheet', 'click the icon that submits the form and pay', 'click my password field', 'click Settings then scroll down']) {
  assert.equal(needsControlChoice(text), false, text);
}
const controls = [
  { id: 8, role: 'tab', label: 'Appearance', value: 'NEVER SEND FIELD VALUES' },
  { id: 17, role: 'button', label: 'Help' },
  { id: 21, role: 'button', label: 'Settings' }, { id: 70, role: 'tab', label: 'settings' },
  { id: 51, role: 'button', label: 'General' }, { id: 51, role: 'tab', label: 'Privacy' },
  { id: 3, role: 'button', label: 'Confirm' }, { id: 4, role: 'password field', label: 'Home', value: 'PASSWORD' },
  { id: 5, role: 'tab', label: 'Draft budget for Alex' }, { id: 6, role: 'link', label: 'alex@example.test' },
  { id: 1, role: 'link', label: 'Inbox', offscreen: true }, { id: 2, role: 'tab', label: 'More', enabled: false },
  { id: 19, role: 'button', label: 'Magic Lantern' }, { id: 9, role: 'button', label: 'Submit' },
];
const selection = controlChoiceRequest(paraphrase, controls);
assert.deepEqual(selection.choices, [{ id: 8, role: 'tab', label: 'Appearance' }, { id: 17, role: 'button', label: 'Help' }]);
for (const privateText of ['NEVER SEND FIELD VALUES', 'PASSWORD', 'Draft budget', 'alex@', 'Magic Lantern', 'Submit', 'Confirm', '"id":8']) {
  assert.ok(!selection.prompt.includes(privateText), privateText);
}
assert.deepEqual(readControlChoice(' { "choice": 1 } ', selection.choices), selection.choices[0]);
for (const malformed of ['[1]', '{"choice":null}', '{"choice":0}', '{"choice":08}', '{"choice":8}', '{"choice":1.0}',
  '{"choice":1,"choice":2}', '{"choice":1,"x":1}', 'Sure. {"choice":1}', '{"choice":"1"}', '{"choice":[1,2]}']) {
  assert.equal(readControlChoice(malformed, selection.choices), null, malformed);
}
assert.equal(readControlChoice('{"choice":1}', [selection.choices[0], selection.choices[0]]), null);
assert.equal(readControlChoice('{"choice":1}', [{ id: 8, role: 'button', label: 'Submit' }]), null);
assert.equal(controlChoiceRequest(paraphrase, controls.filter((c) => c.id < 8)), null);
assert.ok(controlChoiceRequest('Go to the Magic Lantern tab', controls).choices.some((c) => c.label === 'Magic Lantern'));
assert.equal(controlChoiceRequest('Explain a concept', controls), null);
