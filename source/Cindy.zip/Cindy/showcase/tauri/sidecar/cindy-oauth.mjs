export function registrationUrl(raw) {
  const url=new URL(raw);
  if(url.origin==='https://auth.openai.com' && url.searchParams.get('client_id')==='dynamic_agent_client' && url.searchParams.has('agent_name_hint'))url.searchParams.set('agent_name_hint','drkzen');
  return url.href;
}
