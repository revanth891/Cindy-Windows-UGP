// Models served on this computer or the user's own servers: Ollama, LM Studio, and any OpenAI-compatible server they
// add (llama.cpp, vLLM, oMLX…). gg-core finds the models and talks to them; this picks the ones Cindy can use and
// keeps their context window honest.
import {
  DEFAULT_LOCAL_ENDPOINTS, LOCAL_API_KEY_PLACEHOLDER, clearRuntimeModels, localAuthStorageKey, parseLocalModelId, probeEndpoint,
  registerRuntimeModels, toModelInfo,
} from '@kenkaiiii/gg-core';

export const OLLAMA = DEFAULT_LOCAL_ENDPOINTS.find((e) => e.id === 'ollama');
export const OLLAMA_KEY = localAuthStorageKey(OLLAMA.id);
export const LMSTUDIO = { id: 'lmstudio', label: 'LM Studio', baseUrl: 'http://127.0.0.1:1234/v1', kind: 'lmstudio' };
export const BUILT_IN = [OLLAMA, LMSTUDIO];
export const MAX_SERVERS = 8;
// Requests are fitted to half the window, and the system prompt and tools alone are about 12.6k tokens.
export const MIN_CONTEXT = 32_768;

// The window gg-core gives a model of this size (room for the prompt on small windows).
export const withWindow = (info, contextWindow) => ({ ...info, contextWindow, maxOutputTokens: Math.max(512, Math.min(4096, Math.floor(contextWindow / 4))) });

/** gg-core probes chat models and removes embedding-only rows. Vision and native tools are independent. */
// Hosted inference catalogs often return only an OpenAI model ID. These documented
// capabilities belong to the provider's endpoint, never to arbitrary matching model names.
const hostedChat = new Map([
  ['https://integrate.api.nvidia.com/v1', new Map([
    ['nvidia/nemotron-3.5-super-vl-120b-a12b', { context: 262144, images: true }],
    ['nvidia/nemotron-3-ultra-550b-a55b', { images: false }],
  ])],
  ['https://api.fireworks.ai/inference/v1', new Map([
    ['accounts/fireworks/models/glm-5p3-flash', { context: 1048576, images: true }],
    ['accounts/fireworks/models/minimax-m3p1-flash', { context: 1048576, images: true }],
  ])],
]);
export const classifierModel = id => /(?:^|[/:_.-])(?:safety-guard|llama-guard|prompt-guard|content-safety|moderation|safeguard)(?:$|[/:_.-])/i.test(id);
export const localModels = (probes, windows = new Map()) => probes.filter((p) => p.reachable).flatMap((p) => p.models.filter(m => !classifierModel(m.rawId))
  .map((m) => {
    // gg-core defaults generic servers and LM Studio to native tools without checking.
    // Ollama's model metadata declares them. Use the independent harness for unknown servers.
    const hosted = hostedChat.get(p.endpoint.baseUrl.replace(/\/+$/, ''))?.get(m.rawId);
    const declared = p.declaredTools?.get(m.rawId);
    const native = declared ?? (p.nativeTools?.has(m.rawId) || !!hosted || (p.endpoint.kind === 'ollama' && m.supportsTools === true && !p.nativeTools));
    const info = { ...toModelInfo(m, p.endpoint), supportsNativeTools: native,
      toolSupportUnknown: p.endpoint.kind === 'custom' && declared == null && !native };
    if (hosted) info.supportsImages = hosted.images;
    const context = windows.get(info.id) ?? hosted?.context;
    return !m.contextWindowKnown && context ? withWindow(info, context) : info;
  }));

const okServer = (s) => s && typeof s === 'object' && typeof s.id === 'string' && /^[a-z0-9][a-z0-9-]{0,39}$/.test(s.id)
  && !BUILT_IN.some((b) => b.id === s.id) && typeof s.label === 'string' && typeof s.baseUrl === 'string';

/** Ollama, LM Studio, then the servers the user added (`config.localServers`: { id, label, baseUrl, images }). */
export const serverList = (saved) => [...BUILT_IN, ...(Array.isArray(saved) ? saved : []).filter(okServer).slice(0, MAX_SERVERS).map((s) => ({
  id: s.id, label: s.label, baseUrl: s.baseUrl, kind: 'custom', custom: true,
  // Off means "let the server say" (llama.cpp reports it), not "never".
  ...(s.images === true ? { supportsImages: true } : {}),
}))];

/** The server a local model id runs on, from the list. */
export const serverFor = (servers, modelId) => servers.find((s) => s.id === parseLocalModelId(modelId ?? '')?.endpointId);

/** The address as Cindy stores it: http(s), no key or query in it, and `/v1` when only the host was given. Else null. */
export function serverUrl(text) {
  let u;
  try { u = new URL(String(text ?? '').trim()); } catch { return null; }
  if (!/^https?:$/.test(u.protocol) || u.username || u.password) return null;
  const path = u.pathname.replace(/\/+$/, '');
  return `${u.origin}${path || '/v1'}`;
}

/** A new server for `config.localServers`, from the Add a server form. → { server } or { error } in the user's words. */
export function newServer(saved, { label, baseUrl, images } = {}) {
  const list = Array.isArray(saved) ? saved.filter(okServer) : [];
  const name = String(label ?? '').trim().replace(/\s+/g, ' ').slice(0, 40);
  if (!name) return { error: 'Give the server a name.' };
  const url = serverUrl(baseUrl);
  if (!url) return { error: 'That address doesn\'t look right. It should start with http:// or https://, like http://127.0.0.1:8080/v1' };
  if (list.length >= MAX_SERVERS) return { error: `You can add up to ${MAX_SERVERS} servers. Remove one first.` };
  if (list.some((s) => s.baseUrl === url)) return { error: 'That server is already on the list.' };
  const base = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30) || 'server';
  const taken = new Set([...BUILT_IN, ...list].map((s) => s.id));
  let id = base;
  for (let n = 2; taken.has(id); n++) id = `${base}-${n}`;
  return { server: { id, label: name, baseUrl: url, images: images === true } };
}

/** The key saved for a server, if it has a real one. */
export async function storedKey(auth, id) {
  const token = (await auth.getCredentials(localAuthStorageKey(id)).catch(() => null))?.accessToken;
  return token && token !== LOCAL_API_KEY_PLACEHOLDER ? token : undefined;
}

const onServer = (id) => (m) => m.provider === 'local' && parseLocalModelId(m.id)?.endpointId === id;

// The SDK normalizes model discovery but discards the local endpoint's own tool-capability
// metadata. Ask only that endpoint, with its own key, and preserve a working chat listing
// when the extra metadata is absent or unavailable.
async function probeLocalEndpoint(endpoint, options) {
  const root = endpoint.baseUrl.replace(/\/v1\/?$/, '');
  async function detail(url, data = undefined) {
    try {
      const res = await fetch(url, {
        method: data ? 'POST' : 'GET', redirect: 'error', signal: AbortSignal.timeout(options.timeoutMs),
        headers: { ...(endpoint.apiKey && { Authorization: 'Bearer ' + endpoint.apiKey }), ...(data && { 'Content-Type': 'application/json' }) },
        ...(data && { body: JSON.stringify(data) }),
      });
      return res.ok ? await res.json() : null;
    } catch { return null; }
  }
  const nativeTools = new Set();
  const declaredTools = new Map();
  if (endpoint.kind === 'ollama') {
    const probe = await probeEndpoint(endpoint, options);
    // The SDK's optimistic fallback after /api/show fails has tools:true and no other
    // capabilities. Confirm only that ambiguous case. Each successful vision/thinking
    // declaration already proves /api/show answered.
    const ambiguous = probe.models.filter((m) => m.supportsTools && !m.supportsImages && !m.supportsThinking);
    for (const m of probe.models) if (m.supportsTools && (m.supportsImages || m.supportsThinking)) nativeTools.add(m.rawId);
    for (let i = 0; i < ambiguous.length; i += 4) {
      await Promise.all(ambiguous.slice(i, i + 4).map(async (m) => {
        const meta = await detail(root + '/api/show', { model: m.rawId });
        if (Array.isArray(meta?.capabilities) && meta.capabilities.includes('tools')) nativeTools.add(m.rawId);
      }));
    }
    return { ...probe, nativeTools };
  }
  const lm = endpoint.kind === 'lmstudio';
  const [probe, meta] = await Promise.all([probeEndpoint(endpoint, options), detail(lm ? root + '/api/v1/models' : endpoint.baseUrl.replace(/\/$/, '') + '/models')]);
  if (lm && Array.isArray(meta?.models)) {
    for (const entry of meta.models) {
      if (entry?.type !== 'llm' || entry.capabilities?.trained_for_tool_use !== true) continue;
      nativeTools.add(entry.key);
      for (const instance of Array.isArray(entry.loaded_instances) ? entry.loaded_instances : []) if (instance?.id) nativeTools.add(instance.id);
    }
  } else if (!lm && Array.isArray(meta?.data)) {
    for (const entry of meta.data) {
      const value = entry?.capabilities?.tools?.supported ?? entry?.supportsTools ?? entry?.supports_tools ??
        (Array.isArray(entry?.supported_parameters) ? entry.supported_parameters.includes('tools') : undefined);
      if (typeof value === 'boolean') declaredTools.set(entry.id, value);
    }
  }
  return { ...probe, nativeTools, declaredTools };
}

/** Takes a server's models out of the Model menu (after it's removed). */
export const forgetLocal = (id) => clearRuntimeModels(onServer(id));

/**
 * Asks one server what it serves and registers its usable models, leaving other servers' alone. `save`: also store
 * its `local:<id>` credential, with `apiKey` (only when it answered). → { ok, reason, models, all } where `all`
 * counts every chat model, usable or not.
 */
export async function connectLocal(auth, server, { save = false, apiKey, windows, probe = probeLocalEndpoint } = {}) {
  const key = apiKey || await storedKey(auth, server.id);
  const p = await probe(key ? { ...server, apiKey: key } : server, { timeoutMs: server.baseUrl === 'https://integrate.api.nvidia.com/v1' ? 12000 : 1500 });
  if (!p.reachable) return { ok: false, reason: p.reason ?? 'not running', models: [], all: 0 };
  const models = localModels([p], windows);
  clearRuntimeModels(onServer(server.id));
  registerRuntimeModels(models);
  if (save) await auth.setLocalEndpoint(server.id, server.baseUrl, key);
  return { ok: true, models, all: p.models.length };
}

/** Refreshes every connected server at once; the models of servers not connected leave the menu. → Map id → result. */
export async function syncLocal(auth, servers, { windows, probe } = {}) {
  const on = [];
  for (const s of servers) if (await auth.hasCredentials(localAuthStorageKey(s.id)).catch(() => false)) on.push(s);
  clearRuntimeModels((m) => m.provider === 'local' && !on.some((s) => onServer(s.id)(m)));
  const results = await Promise.all(on.map((s) => connectLocal(auth, s, { windows, probe }).catch(() => ({ ok: false, models: [], all: 0 }))));
  return new Map(on.map((s, i) => [s.id, results[i]]));
}

/** What to say when a server is connected but none of its models can be used. `short`: one line, for its row. */
export function noModelsNote(server, all, short = false) {
  if (short) return 'No chat models served.';
  if (server.id === 'ollama') return 'Ollama is serving no chat models. Install a chat model in Ollama, then refresh.';
  if (server.id === 'lmstudio') return 'LM Studio is serving no chat models. Load a chat model in LM Studio, then refresh.';
  return `${server.label} is serving no chat models.`;
}

/** Why a server that's connected isn't answering, in plain words. */
export const downNote = (server, reason) => (/rejected the API key/.test(reason ?? '')
  ? `${server.label} rejected the key. Remove it and add it again with the right key.`
  : `${server.label} isn't running${server.custom ? ` at ${server.baseUrl}` : ''}.`);

/** What to tell the user when a server serves too small a context, else ''. */
// Lite mode (#73) sends far less each time, so half the memory is enough.
export const LITE_MIN_CONTEXT = 16_384;
export const contextNote = (window, server = OLLAMA, lite = false) => {
  const min = lite ? LITE_MIN_CONTEXT : MIN_CONTEXT, need = `${min / 1024}k`;
  if (!window || window >= min) return '';
  const k = Math.round(window / 1024);
  if (server.id === 'ollama') return `Ollama gives this model only ${k}k tokens of memory, too little for me to work well. In Ollama's settings, set Context length to ${need} or more (or start it with OLLAMA_CONTEXT_LENGTH=${min}), then pick the model again.`;
  if (server.id === 'lmstudio') return `LM Studio gives this model only ${k}k tokens of memory (or hasn't loaded it yet), too little for me to work well. In LM Studio, load it with Context Length set to ${need} or more, then pick the model again.`;
  return `${server.label} says this model has only ${k}k tokens of memory (or didn't say), too little for me to work well. Start it with a context of ${need} or more, then pick the model again.`;
};
// A model's size from its name ("qwen3.5:9b", "gemma-4-e4b-it", "llama-3.2-3B-instruct"), in billions; null when the
// name doesn't say. Small (9B or less) is when Lite mode is suggested.
export const modelBillions = (id) => {
  const m = /(?:^|[^a-z0-9.])e?(\d+(?:\.\d+)?)b(?![a-z0-9])/i.exec(String(id ?? ''));
  return m ? Number(m[1]) : null;
};
export const isSmallModel = (id) => { const b = modelBillions(id); return b != null && b <= 9; };
