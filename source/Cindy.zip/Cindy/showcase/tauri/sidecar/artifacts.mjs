import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { randomUUID } from 'node:crypto';
import { SAFE, checkRead } from './safety.mjs';

const formats = new Map();
for (const [kind, exts] of Object.entries({
  markdown: 'md markdown mdx', pdf: 'pdf', image: 'png jpg jpeg gif webp bmp avif svg',
  table: 'csv tsv', code: 'json js mjs cjs ts css html htm xml py rs sh yaml yml toml sql',
  text: 'txt log', audio: 'wav mp3 ogg m4a', video: 'mp4 webm'
})) for (const ext of exts.split(' ')) formats.set(ext, kind);
const mime = { jpg:'image/jpeg', jpeg:'image/jpeg', svg:'image/svg+xml', mp3:'audio/mpeg', m4a:'audio/mp4' };
function checked(file) {
  const v = checkRead(file, os.homedir());
  if (v.level !== SAFE) throw Error(v.reason);
  return v.path;
}
function typeOf(file) {
  const ext = path.extname(file).slice(1).toLowerCase();
  return { ext, kind: formats.get(ext) };
}
const isBinary = k => ['pdf','image','audio','video'].includes(k);
async function readContent(file, kind) {
  const limit = isBinary(kind) ? 24 * 1024 * 1024 : 1024 * 1024;
  const h = await fs.open(checked(await fs.realpath(checked(file))), 'r');
  try {
    const s = await h.stat();
    if (!s.isFile()) throw Error('Choose a file to preview.');
    if (s.size > limit) throw Error(`This file exceeds the ${limit / 1024 / 1024} MB preview limit.`);
    const bytes = Buffer.alloc(s.size);
    let offset = 0;
    while (offset < bytes.length) {
      const {bytesRead} = await h.read(bytes, offset, bytes.length-offset, offset);
      if (!bytesRead) break;
      offset += bytesRead;
    }
    return bytes.subarray(0, offset).toString(isBinary(kind) ? 'base64' : 'utf8');
  } finally { await h.close(); }
}
export function createArtifacts({ show, publish, theme }) {
  const tabs = new Map();
  let active = null;
  const publicTabs = () => Array.from(tabs.values(), ({file, ...tab}) => tab);
  const state = () => publish({ kind:'state', tabs:publicTabs(), active, ...theme() });
  async function open(file, strict = false) {
    const { ext, kind } = typeOf(file);
    if (!kind) { if (strict) throw Error('This file type has no preview.'); return; }
    const real = checked(await fs.realpath(checked(file)));
    const stat = await fs.stat(real);
    if (!stat.isFile()) throw Error('Choose a file to preview.');
    const existing = [...tabs.values()].find(tab => tab.file === real);
    const tab = existing ?? { id:randomUUID(), file:real, name:path.basename(real), ext, kind, rev:0 };
    tab.rev++;
    if (!existing && tabs.size >= 10) tabs.delete(tabs.keys().next().value);
    tabs.set(tab.id, tab);
    active = tab.id;
    show(); state();
  }
  async function handle(m) {
    if (m.type === 'preview_ready') { state(); return; }
    const t = tabs.get(m.id);
    if (!t) return;
    if (m.type === 'preview_select') { active=t.id; state(); }
    if (m.type === 'preview_close') {
      const ids=[...tabs.keys()], idx=ids.indexOf(t.id);
      tabs.delete(t.id);
      if (active===t.id) active=ids[idx+1] ?? ids[idx-1] ?? null;
      state();
    }
    if (m.type === 'preview_content' && m.rev===t.rev) {
      const rev=t.rev;
      try {
        const data=await readContent(t.file,t.kind);
        if(tabs.get(t.id)?.rev===rev) publish({kind:'content',id:t.id,rev,data,mime:mime[t.ext] ?? (t.kind==='pdf'?'application/pdf':t.kind+'/'+t.ext)});
      } catch(e) { publish({kind:'content',id:t.id,rev,error:e.code==='ENOENT'?'This file has moved or was deleted.':e.message}); }
    }
    if (m.type==='preview_image' && t.kind==='markdown' && t.rev===m.rev && typeof m.src==='string' && m.src.length<1024) {
      const dir=path.dirname(t.file);
      try {
        const relative=decodeURIComponent(m.src);
        if (/^[a-z]+:|^[\\/]|[\u0000-\u001f]/i.test(relative)) return;
        const file=checked(await fs.realpath(checked(path.resolve(dir,relative))));
        const within=path.relative(dir,file), {kind,ext}=typeOf(file);
        if (!within || within.startsWith('..'+path.sep) || path.isAbsolute(within) || kind!=='image') return;
        const size=(await fs.stat(file)).size;
        if(size>4*1024*1024)return;
        publish({kind:'image',id:t.id,rev:m.rev,src:m.src,data:await readContent(file,'image'),mime:mime[ext]??'image/'+ext});
      } catch { /* The alt text remains readable for missing or unavailable images. */ }
    }
  }
  return { open, handle, state };
}
