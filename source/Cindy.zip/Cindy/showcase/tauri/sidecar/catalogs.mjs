// OpenRouter's and OpenCode's model lists. gg-core ships only a few rows for each, so the Model menu showed just
// those; this reads the live lists and caches them so they survive restarts and offline starts.
import path from 'node:path';
import {
  OPENCODE_CATALOG_URLS, OPENROUTER_DEFAULT_BASE_URL, getProviderCatalog, parseOpenCodeCatalog, parseOpenRouterCatalog, setProviderCatalog,
} from '@kenkaiiii/gg-core';
import { readJson, writeJson } from './store.mjs';

export const CATALOG_PROVIDERS = ['openrouter', 'opencode', 'opencode-go'];
export const REFRESH_MS = 6 * 3600_000;
export const RETRY_MS = 10 * 60_000;

const OPENROUTER_FIELDS = ['id', 'name', 'context_length', 'supported_parameters', 'architecture', 'reasoning', 'top_provider', 'pricing'];
const CACHE_VERSION = 2;
function hasText(modalities) {
  return !Array.isArray(modalities) || modalities.includes('text');
}

// gg-core normalizes context limits, prices, reasoning and IDs, but its own CLI only lists
// models which take native tools. Reuse that normalization for chat while recording the
// *original* tool support independently. The unmodified provider metadata is what we cache.
function parse(p, body) {
  if (!Array.isArray(body?.data)) return [];
  const router = p === 'openrouter', tools = new Map(), rows = [];
  for (const raw of body.data) {
    const id = typeof raw?.id === 'string' && raw.id.trim();
    if (!id || tools.has(id)) continue;
    if (router) {
      const arch = raw.architecture ?? {};
      if (!hasText(arch.input_modalities) || !hasText(arch.output_modalities)) continue;
      if (/(?:^|[\/_:-])(?:embeddings?|rerank(?:er)?|moderation|whisper|tts)(?:$|[\/_:-])/i.test(id)) continue;
      const parameters = Array.isArray(raw.supported_parameters) ? raw.supported_parameters : [];
      tools.set(id, parameters.includes('tools'));
      rows.push({ ...raw, supported_parameters: [...parameters, 'tools'] });
    } else {
      if (!hasText(raw.modalities?.input) || !hasText(raw.modalities?.output)) continue;
      tools.set(id, raw.capabilities?.tools?.supported === true);
      rows.push({ ...raw, capabilities: { ...raw.capabilities, tools: { supported: true } } });
    }
  }
  const list = router ? parseOpenRouterCatalog({ data: rows }) : parseOpenCodeCatalog(p, { data: rows });
  return list.models.map((m) => ({ ...m, supportsNativeTools: tools.get(router ? m.id : m.id.slice(p.length + 1)) === true }));
}

/** → { load, refresh(provider), refreshStale(connected) }; the last two resolve true when the menu's list changed. */
export function createCatalogs({ auth, dir, fetch: doFetch = (...a) => fetch(...a), now = Date.now, timeoutMs = 15_000 }) {
  const nextRead = new Map(), inFlight = new Map();
  const file = (p) => path.join(dir, `${p}-models.json`);

  // Where the list comes from: OpenRouter's is the key's own endpoint (a custom base URL lists its own models).
  async function source(p) {
    if (p !== 'openrouter') return { url: OPENCODE_CATALOG_URLS[p], headers: {} };
    const creds = await auth.getCredentials('openrouter').catch(() => null);
    const base = (creds?.baseUrl ?? OPENROUTER_DEFAULT_BASE_URL).replace(/\/+$/, '');
    return { url: `${base}/models`, headers: creds?.accessToken ? { Authorization: `Bearer ${creds.accessToken}` } : {} };
  }

  function install(p, body) {
    const models = parse(p, body);
    // An empty answer never wipes a working list.
    if (!models.length) return false;
    const before = JSON.stringify(getProviderCatalog(p) ?? null);
    return JSON.stringify(setProviderCatalog(p, models)) !== before;
  }

  async function load() {
    for (const p of CATALOG_PROVIDERS) {
      const cached = readJson(file(p));
      if (!cached?.body || cached.url !== (await source(p)).url) continue;
      install(p, cached.body);
      // Earlier caches deliberately omitted text-only models. Use them offline and refresh
      // promptly when a connection returns to make the newly eligible rows available.
      nextRead.set(p, cached.version === CACHE_VERSION ? (Number(cached.syncedAt) || 0) + REFRESH_MS : 0);
    }
  }

  async function read(p) {
    nextRead.set(p, now() + RETRY_MS);
    try {
      const { url, headers } = await source(p);
      const res = await doFetch(url, { headers: { Accept: 'application/json', ...headers }, signal: AbortSignal.timeout(timeoutMs) });
      if (!res.ok) return false;
      let body = await res.json();
      const usable = parse(p, body);
      if (!usable.length) return false;
      // Keep only compatible chat models and the provider fields needed after a restart.
      if (p === 'openrouter') {
        const keep = new Set(usable.map((m) => m.id));
        body = { data: body.data.filter((r) => keep.has(r?.id?.trim?.())).map((r) => Object.fromEntries(OPENROUTER_FIELDS.filter((k) => k in r).map((k) => [k, r[k]]))) };
      }
      await writeJson(file(p), { version: CACHE_VERSION, url, syncedAt: now(), body });
      nextRead.set(p, now() + REFRESH_MS);
      return install(p, body);
    } catch {
      return false;
    }
  }

  const refresh = (p) => {
    let running = inFlight.get(p);
    if (!running) { running = read(p).finally(() => inFlight.delete(p)); inFlight.set(p, running); }
    return running;
  };

  const refreshStale = async (connected) => (await Promise.all(CATALOG_PROVIDERS
    .filter((p) => connected.includes(p) && (inFlight.has(p) || now() >= (nextRead.get(p) ?? 0)))
    .map(refresh))).some(Boolean);

  return { load, refresh, refreshStale };
}
