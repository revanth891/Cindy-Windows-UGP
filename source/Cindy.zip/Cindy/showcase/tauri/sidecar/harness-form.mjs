// Only this module chooses the values. The caller supplies the observed window, trusted
// saved data, and a narrow read / single-field-write transport. No model-generated steps.
const aliases = {
  fullName: ['full name', 'name', 'student name', 'name of student', 'applicant name', 'name of applicant'],
  firstName: ['first name', 'given name', 'given names'], middleName: ['middle name'],
  lastName: ['last name', 'family name', 'surname'], preferredName: ['preferred name', 'nickname'],
  email: ['email', 'e mail', 'email id', 'email address', 'e mail address'],
  workEmail: ['work email', 'work email address', 'business email'],
  personalEmail: ['personal email', 'personal email address'],
  institutionalEmail: ['institutional email', 'institutional email address', 'institute email', 'institute email id',
    'university email', 'university email address', 'student email', 'school email', 'college email', 'iitk email', 'iitk email id'],
  phone: ['phone', 'phone number', 'mobile', 'mobile number', 'telephone', 'telephone number', 'contact number'],
  rollNumber: ['roll number', 'roll no', 'rollno', 'rollnum'], studentId: ['student id', 'student number', 'student identification number'],
  department: ['department', 'academic department', 'dept'], programme: ['program', 'programme', 'degree program', 'degree programme', 'academic program', 'academic programme'],
  institution: ['institution', 'institution name', 'university', 'university name', 'college', 'college name'],
  jobTitle: ['job title', 'job role'], organisation: ['organization', 'organisation', 'employer', 'company name'],
  street: ['street address', 'address line 1'], addressLine2: ['address line 2'],
  city: ['city', 'town'], state: ['state', 'province', 'state province'],
  country: ['country', 'country of residence'], postcode: ['zip code', 'postal code', 'postcode', 'pin code'],
  github: ['github','GitHub','GitHub profile','GitHub URL','github profile','github url'], linkedin:['linkedin','LinkedIn','LinkedIn profile','LinkedIn URL','linkedin profile','linkedin url'],
  website: ['website', 'personal website','portfolio','portfolio url'], pronouns: ['pronouns'],
};
const normalize = value => String(value ?? '').normalize('NFC').trim().replace(/\s+/gu, ' ');
const words = value => normalize(value).replace(/([\p{Ll}\d])([\p{Lu}])/gu, '$1 $2').toLowerCase()
  .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const byAlias = new Map(Object.entries(aliases).flatMap(([key, names]) => [...names, key].map(n => [words(n), key])));
const textRoles = new Set(['text field', 'text area', 'textbox', 'text box', 'edit', 'email', 'tel', 'textarea']);
const sensitive = /\b(?:password|passwd|passphrase|passcode|otp|mfa|2fa|totp|captcha|verification|authentication|cvv|cvc|iban|swift|bank|routing|account number|credit|debit|card number|security|recovery|secret|token|private key|api key|one time|government id|passport|aadhaar|aadhar|ssn|social security|tax id|pan number|signature|consent|authorization)\b/iu;
const otherSubject = /\b(?:parent|guardian|mother|father|sibling|friend|emergency|supervisor|spouse|referee|reference|sponsor|dependent|recipient|nominee)\b/iu;
const unsafeValue = /[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]|(?:https?:\/\/[^\s/]+:[^\s/]+@)|(?:^|\s)(?:sk-[\w-]{12,}|gh[pousr]_[\w]{15,}|eyJ[\w-]+\.[\w-]+\.[\w-]+)|-----BEGIN .*KEY-----/iu;
const nameKeys = new Set(['fullName','firstName','middleName','lastName','preferredName']);

function fieldName(label) {
  const clean = normalize(label)
    .replace(/\s*\((?:required|optional|your answer|short answer|enter (?:your )?answer)\)\s*$/iu,'')
    .replace(/(?:\s*[*＊]\s*)+$/u,'');
  return words(clean).replace(/^(?:please )?(?:enter|type|provide) (?:your )?|^what is your |^your /u,'')
    .replace(/ (?:required(?: question)?|optional)$/u,'').trim();
}

function keyOf(label, custom = false) {
  const name = fieldName(label);
  if (!name || sensitive.test(name) || otherSubject.test(name)) return null;
  if (byAlias.has(name)) return byAlias.get(name);
  // Only an exact, explicitly saved custom profile label can authorize a nonstandard field.
  if (custom && name.length <= 45 && name.split(' ').length <= 6 &&
      /^[\p{L}][\p{L}\p{N} ]*$/u.test(name) &&
      !/\b(?:pin|code|secret|login|user name|username|submit|agree|accept|confirm|type|click|send|upload|attachment|payment|status|delete|verify|terms|certify|permission|agree|do you|are you|why|how|which|what)\b/iu.test(name))
    return 'custom/' + name;
  return null;
}

function validValue(key, raw) {
  // Numbers are deliberately strings: postal codes and student IDs can have leading zeroes.
  if (typeof raw !== 'string' || unsafeValue.test(raw) || sensitive.test(words(raw))) return null;
  const value = normalize(raw);
  if (!value || value.length > 80 || /^(?:unknown|not specified|prefer not to say|not provided|not known|n\/a|tbd|null|undefined)$/iu.test(value)) return null;
  if (nameKeys.has(key) && !/^[\p{L}\p{M}][\p{L}\p{M} .'’\-]*$/u.test(value)) return null;
  if ((key==='email' || key.endsWith('Email')) && !/^[^\s@<>]+@[\p{L}\d](?:[\p{L}\d.-]*[\p{L}\d])?\.[\p{L}]{2,}$/u.test(value)) return null;
  if (key==='phone' && (!/^\+?[\d .()-]+$/u.test(value) || !/^\d{7,15}$/.test(value.replace(/\D/g,'')))) return null;
  if (['rollNumber','studentId','postcode'].includes(key) && !/^[\p{L}\d][\p{L}\d /-]{1,23}$/u.test(value)) return null;
  if (['website','github','linkedin'].includes(key)) {
    try {const u=new URL(value); if (!['http:','https:'].includes(u.protocol)||u.username||u.password||u.search||u.hash) return null;}
    catch {return null;}
  }
  return value;
}

function factAssignment(fact) {
  if (typeof fact?.text !== 'string' || !fact.id || /[\r\n]/u.test(fact.text)) return null;
  // Only whole declarations. A bare association in a story, past value, instruction, or
  // inferred first/last name cannot supply a fill value.
  const match = normalize(fact.text).match(/^(?:(my|(?:the )?user['’]s)\s+)?([\p{L}][\p{L} -]{0,45}?)\s*(:|=|\bis\b)\s*(.+?)\s*$/iu);
  if (!match) return null;
  if (match[3].toLowerCase()==='is' && !match[1]) return null;
  const key = keyOf(match[2]);
  if (!key) return null;
  const raw=match[4].replace(/\.$/u,'');
  if (/\s+and\s+/iu.test(raw) && !['department','institution','organisation','programme'].includes(key)) return null;
  if (/[;!?]|\.\s+\p{Lu}\p{Ll}{2,}\s|\s(?:or|but|formerly|previously|maybe|probably|possibly)\s|\s+and\s+(?:my|i|the|you|please)\b/iu.test(raw) ||
      /^(?:probably|possibly|maybe|either|not|currently unknown)\b/iu.test(raw)) return null;
  return {key, value:raw, source:{type:'memory',id:fact.id}};
}

/** A memory command from the user. Save only the complete validated personal assignment. */
export function explicitFormFact(text) {
  if (typeof text !== 'string' || /[\r\n]/u.test(text)) return null;
  const match = normalize(text).match(/^(?:please )?remember (?:that )?(my .+)$/iu);
  if (!match) return null;
  const assignment = factAssignment({id:'candidate',text:match[1]});
  if (!assignment || !validValue(assignment.key,assignment.value)) return null;
  return {text:match[1],key:assignment.key};
}

function savedValues(profile, facts) {
  const saved=new Map();
  function add(key, raw, source) {
    if (!key) return;
    const value=validValue(key,raw);
    const entry=saved.get(key) || new Map();
    // An invalid assertion cannot break a tie in favor of another source.
    const fingerprint=value===null?null:normalize(value);
    if (!entry.has(fingerprint)) entry.set(fingerprint,{value,source});
    saved.set(key,entry);
  }
  for (const [label,value] of Object.entries(profile || {})) add(keyOf(label,true),value,{type:'profile',key:label});
  for (const fact of facts || []) {
    const record=factAssignment(fact);
    if (record) add(record.key,record.value,record.source);
  }
  return saved;
}

const labelOf = c => normalize(c?.label || c?.name || c?.placeholder);
const roles = c => words(c?.role);
const textInput = c => textRoles.has(roles(c));
const formInput = c => !c.browserChrome && (textInput(c) || ['password field','combo box','combobox','select','radio','radio button','checkbox','check box','spin button'].includes(roles(c)));
function unsafeControl(c) {
  return c.secure===true || c.password===true || (c.type && !['text','textarea','email','tel','url','search'].includes(words(c.type))) ||
    c.readOnly===true || c.readonly===true || c.enabled===false || c.disabled===true ||
    c.offscreen===true || c.visible===false || c.hidden===true ||
    sensitive.test(words([c.label,c.name,c.placeholder,c.autocomplete,c.type].filter(Boolean).join(' ')));
}
function pinned(a,b) {
  if (a?.id==null || a.id!==b?.id) return false;
  return ['app','title','url','documentId','formId'].every(k => !a[k] || a[k]===b[k]);
}
function sameValue(key,a,b) {
  if (key==='phone') return normalize(a).replace(/[ ().-]/gu,'')===normalize(b).replace(/[ ().-]/gu,'');
  return normalize(a)===normalize(b);
}

/** Plan only from actual observed controls. .fields contains sensitive personal values for local execution. */
export function planFormFill({snapshot,profile={},facts=[]}) {
  if (snapshot?.window?.id==null || !Array.isArray(snapshot.controls)) throw new Error('A current form window and its controls are required.');
  const saved=savedValues(profile,facts), fields=[], skipped=[];
  const inputs=snapshot.controls.filter(formInput);
  const keyFor=c=>keyOf(labelOf(c),true);
  const counts=new Map(), ids=new Set(), repeatIds=new Set();
  for (const c of snapshot.controls) {
    if(ids.has(c.id)) repeatIds.add(c.id);
    ids.add(c.id);
  }
  for (const c of inputs) {
    const k=keyFor(c);
    counts.set(k,(counts.get(k)||0)+1);
  }
  for (const c of inputs) {
    const label=labelOf(c), key=keyFor(c), entries=saved.get(key);
    let reason;
    if (!label) reason='unlabeled';
    else if (unsafeControl(c) || !key || roles(c)==='password field') reason='ineligible';
    else if (!textInput(c)) reason='unsupported control';
    else if (!Number.isSafeInteger(c.id) || c.id<1 || repeatIds.has(c.id) || counts.get(key)!==1) reason='ambiguous control';
    else if (!entries?.size) reason='no saved value';
    else if (entries.size!==1 || entries.has(null)) reason='uncertain saved value';
    else {
      const {value,source}=entries.values().next().value;
      if (normalize(c.value)) reason=sameValue(key,c.value,value)?'already filled':'existing value';
      else fields.push({label,key,value,source,id:c.id,role:roles(c)});
    }
    if (reason) skipped.push({label,reason});
  }
  return {fields, skipped};
}

/** Re-resolve every field by observed label/role, then verify the displayed value. Never presses a button. */
export async function fillFormFromMemory({snapshot,profile={},facts=[],read,fill,signal}) {
  const {fields,skipped}=planFormFill({snapshot,profile,facts});
  const result={filled:[],skipped,stopped:false,reason:null};
  const stop=(reason)=>Object.assign(result,{stopped:true,reason});
  const current=async()=>{
    if (signal?.aborted) throw new Error('cancelled');
    const fresh=await read(snapshot.window.id);
    if (signal?.aborted) throw new Error('cancelled');
    if (!pinned(snapshot.window,fresh?.window)||!Array.isArray(fresh?.controls)) throw new Error('changed');
    return fresh;
  };
  const locate=(fresh,f)=>{
    const matches=fresh.controls.filter(c=>formInput(c)&&keyOf(labelOf(c),true)===f.key);
    const c=matches.length===1?matches[0]:null;
    if (!c || labelOf(c)!==f.label || roles(c)!==f.role || unsafeControl(c) ||
        !Number.isSafeInteger(c.id)||c.id<1||fresh.controls.filter(row=>row.id===c.id).length!==1) return null;
    return c;
  };
  for (const f of fields) {
    try {
      const c=locate(await current(),f);
      if (!c) return stop('Form controls changed. Review the form.');
      if (normalize(c.value)) {
        skipped.push({label:f.label,reason:sameValue(f.key,c.value,f.value)?'already filled':'existing value'});
        continue;
      }
      // A native helper can fail after applying a write. Read once to reconcile; never blindly repeat.
      if (signal?.aborted) return stop('Cancelled.');
      try {await fill(snapshot.window.id,{do:'fill',id:c.id,field:f.label,text:f.value,expectedControl:{label:f.label,role:f.role}});} catch { /* reconcile below */ }
      const after=locate(await current(),f);
      if (!after || !sameValue(f.key,after.value,f.value)) return stop('A field could not be verified. Review the form.');
      result.filled.push({key:f.key,label:f.label,source:f.source});
    } catch {
      return stop(signal?.aborted?'Cancelled.':'The form could not be read or the page changed. Review it before continuing.');
    }
  }
  return result;
}
