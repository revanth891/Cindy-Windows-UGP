import { createHash } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { CARDS, DrawArgs, checkDraw } from './draw.mjs';
import { stripNote } from './intro.mjs';
import { readDiagramDraft } from './explanation.mjs';
import { CUE } from './speech.mjs';
import { EMOTES } from './reply.mjs';
import { DIR, isSummary } from './store.mjs';

const sessions = path.join(DIR, 'sessions');
const validId = id => typeof id === 'string' && /^\d{8}-\d{6}-[a-z0-9]{6}$/.test(id);
const textOf = content => typeof content === 'string' ? content : (Array.isArray(content) ? content : []).filter(p => p?.type === 'text').map(p => p.text).join('\n');
export const windowKey = content => createHash('sha256').update(Array.isArray(content) ? content.find(p => p.type === 'text')?.text || '' : textOf(content)).digest('hex').slice(0, 24);
const tags = new RegExp('\\[(?:' + EMOTES.join('|') + ')\\]', 'gi');
const readable = s => String(s ?? '').replace(/<(think|thinking|analysis|reasoning)\b[^>]*>[\s\S]*?(?:<\/\1>|$)/gi, '').replace(tags, '').replace(CUE, '').trim();

const standaloneCards = new Set(CARDS.filter(k => !['clip', 'photo'].includes(k)));
export function savedCards(beats = []) {
  if (!Array.isArray(beats)) return [];
  const cards = [];
  for (const beat of beats) for (const m of beat?.marks ?? []) {
    if (!standaloneCards.has(m?.kind)) continue;
    const { at, to, tie, action, part, ...content } = m;
    const result = DrawArgs.safeParse({ beats: [{ say: 'Saved reply', marks: [content] }] });
    if (!result.success) continue;
    const card = result.data.beats[0].marks[0];
    if (checkDraw(result.data).length) continue;
    cards.push(card);
  }
  return cards;
}

export async function historySession(id) {
  if (!validId(id)) return null;
  try {
    const s = JSON.parse(await fs.readFile(path.join(sessions, id + '.json'), 'utf8'));
    return s.version === 1 && s.id === id && s.kind !== 'intro' && Array.isArray(s.messages) ? s : null;
  } catch { return null; }
}

export function projectTurns(messages, views = {}) {
  const rows = [];
  let row = null;
  for (const m of messages) {
    if (m.role === 'user') {
      if (isSummary(m)) { row = null; continue; }
      const key = windowKey(m.content), view = views[key];
      const raw = stripNote(textOf(m.content)).replace(/^\[[^\]\n]{3,180}\d[^\]\n]*\]\s*/, '');
      const question = view?.question ?? raw.split(/\n\((?:Attached:|They asked for an agent:|System,)/)[0].trim();
      row = null;
      if (!question || /^\(System\b|^\[System\b/i.test(question)) continue;
      row = { id: rows.length, question, answer: view?.answer ?? '', cards: view?.cards ?? [], saved: !!view };
      rows.push(row);
    } else if (row && m.role === 'assistant' && !row.saved) {
      const text = readable(textOf(m.content));
      if (text) {
        const diagram = text.startsWith('{') ? readDiagramDraft(text) : null;
        row.answer = [row.answer, diagram?.answer || text].filter(Boolean).join('\n\n');
        if (diagram?.beat) row.cards.push(...savedCards([diagram.beat]));
      }
      for (const part of Array.isArray(m.content) ? m.content : []) {
        if (part.type === 'tool_call' && part.name === 'draw' && Array.isArray(part.args?.beats)) {
          row.cards.push(...savedCards(part.args.beats));
          if (!row.answer) row.answer = part.args.beats.map(b => readable(b.say)).filter(Boolean).join('\n');
        }
      }
    }
  }
  return rows.map(({saved,...r}) => r);
}

export async function historyTurns(s) {
  let older = [];
  if (validId(s.id)) {
    try {
      const lines = await fs.readFile(path.join(sessions, s.id + '.folded.jsonl'), 'utf8');
      for (const line of lines.split('\n')) if (line.trim()) {
        try { older.push(JSON.parse(line)); } catch {}
      }
    } catch (e) { if (e.code !== 'ENOENT') throw e; }
  }
  return projectTurns([...older, ...s.messages], s.windows);
}

export async function historyIndex() {
  let names;
  try { names = await fs.readdir(sessions); } catch (e) { if (e.code === 'ENOENT') return []; throw e; }
  const list = [];
  for (const name of names.filter(n => n.endsWith('.json'))) {
    const s = await historySession(name.slice(0,-5));
    if (!s) continue;
    const visible = projectTurns(s.messages, s.windows);
    const first = Object.values(s.windows ?? {})[0]?.question || visible[0]?.question;
    if (first) list.push({ id:s.id, title:first.slice(0,120), at:s.lastActiveAt || s.startedAt });
  }
  return list.sort((a,b) => b.at - a.at || b.id.localeCompare(a.id));
}
