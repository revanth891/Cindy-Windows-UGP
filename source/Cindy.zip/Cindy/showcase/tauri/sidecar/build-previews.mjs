import {build} from 'esbuild';
import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const dir=path.dirname(fileURLToPath(import.meta.url)), out=path.resolve(dir,'../dist/previews'), deps=path.join(dir,'node_modules');
await fs.mkdir(out,{recursive:true});
await build({entryPoints:[path.join(dir,'preview-ui.mjs')],bundle:true,minify:true,format:'esm',platform:'browser',target:'es2022',outfile:path.join(out,'preview.js'),legalComments:'eof'});
await fs.mkdir(path.join(out,'licenses'),{recursive:true});
for (const name of ['pdfjs-dist','markdown-it','highlight.js','katex','dompurify']) {
 const files=await fs.readdir(path.join(deps,name));
 const license=files.find(f=>/^license(?:\.|$)/i.test(f));
 if(license) await fs.copyFile(path.join(deps,name,license),path.join(out,'licenses',name+'.txt'));
}
for(const [src,dest] of [['pdfjs-dist/build/pdf.worker.min.mjs','pdf.worker.min.mjs'],['pdfjs-dist/cmaps','cmaps'],['pdfjs-dist/wasm','wasm'],['pdfjs-dist/standard_fonts','standard_fonts'],['katex/dist/katex.min.css','katex.min.css'],['katex/dist/fonts','fonts']]){
 await fs.cp(path.join(deps,src),path.join(out,dest),{recursive:true});
}
