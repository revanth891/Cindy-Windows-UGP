// Evaluate before provider modules in both entrypoints, including the bundled app.
import { CINDY_PATHS, prepareProviderEnvironment } from './profile.mjs';
import { mkdirSync } from 'node:fs';
prepareProviderEnvironment({ paths: CINDY_PATHS });
// GG's file lock is created before AuthStorage writes the auth file itself.
mkdirSync(CINDY_PATHS.gg, { recursive: true, mode: 0o700 });
