import { explicitFormFact, fillFormFromMemory, planFormFill } from './harness-form.mjs';
import { needsControlChoice, planDesktopRequest } from './harness-plan.mjs';
import { riskyKind } from './safety.mjs';
import { mailboxFormTask, runMailboxForm } from './mailbox-form.mjs';
import { browserSearchTask, runBrowserSearch } from './browser-search.mjs';

const normalize = text => String(text ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
const actionRoles = /^(?:button|link|hyperlink|menu ?item|tab(?: item)?|check ?box|radio(?: button)?|toggle|switch|list ?item)$/i;
const formRequest = /^(?:(?:hey )?cindy[, ]+)?(?:(?:please|can you|could you|would you) )?(?:auto[- ]?fill|fill(?: in| out)?|complete) (?:this|the|my|the current|the open|the visible) form(?: (?:using|with|from) (?:my |your |the )?(?:saved |personal |stored )?(?:memory|details|data|info(?:rmation)?|profile|facts))?(?:[, ]+(?:and )?(?:ask me|wait for (?:my )?approval|let me review)(?: before (?:you )?(?:submit(?:ting)?(?: it)?|send(?:ing)?(?: it)?))?)?[.!?]*$/i;
const submitRequest = /^(?:please )?(?:submit (?:this|the|the current|the completed) form|(?:click|press) (?:the )?["“']?submit["”']?(?: button)?)[.!?]*$/i;
export function desktopTask(text) {
  const input = String(text ?? '').trim();
  const address=input.match(/https:\/\/[^\s<>"']+/i)?.[0].replace(/[.,;!]+$/,'');
  const login=/\b(?:sign[ -]?in|log[ -]?in|saved (?:credential|login|password)s?)\b/i.test(input);
  const mailbox = mailboxFormTask(input);
  if (mailbox) return mailbox;
  if (login && (address || /\b(?:here|this (?:site|page)|first saved|saved (?:login|credential|password))\b/i.test(input)) && !/^(?:why|how|what|explain|don.t|do not)\b/i.test(input)) return {kind:'saved-login',url:address};
  const search = browserSearchTask(input);
  if (search) return search;
  if (formRequest.test(input)) return { kind: 'form', review: /ask me|approval|let me review/i.test(input) };
  if (submitRequest.test(input)) return { kind: 'submit' };
  const fact = explicitFormFact(input);
  if (fact) return { kind: 'remember', fact };
  const plan = planDesktopRequest(input);
  if (plan) return { kind: 'desktop', steps: plan.steps };
  return needsControlChoice(input) ? { kind: 'choice', request: input } : null;
}

const available = c => c.enabled !== false && !c.disabled && !c.offscreen && !c.secure && !c.password;
const clickable = c => available(c) && actionRoles.test(c.role) && c.label;
function summary(snapshot) {
  const labels = [...new Set(snapshot.controls.filter(available).map(c => c.label?.trim()).filter(Boolean))];
  return labels.length ? `${snapshot.window.title || snapshot.window.app} shows ${labels.slice(0, 8).join(', ')}.` : 'There are no labeled controls in this window.';
}
const samePage = (a, b) => ['id', 'title', 'app', 'url'].every(k => a[k] === b[k]);
const windowRef = snap => 'window:' + snap.window.id;
const signature = snap => JSON.stringify([snap.window.title, snap.window.url, snap.controls.map(c => [c.role, c.label, c.value, c.checked, c.selected]), snap.texts]);

// Each run owns one observation. The native tool revalidates the chosen control immediately before acting.
export async function executeDesktopTask(task, runtime) {
  const {call, observe, facts, remember, signal, actions, infer, startSnapshot, choose, confirmFill} = runtime;
  const check = () => signal?.throwIfAborted();
  check();
  if (task.kind === 'remember') { await remember(task.fact.text); return 'Saved that detail to your Cindy memory.'; }
  if (!actions() && (task.kind !== 'desktop' || task.steps.some(s => s.tool !== 'read_window'))) {
    throw new Error('Turn on desktop actions in Cindy’s settings to do that.');
  }
  if(task.kind==='saved-login'){
    if(task.url) await call('open',{target:task.url,app:'Brave'});
    return call('use_saved_login',task.url?{url:task.url}:{});
  }
  let snap;
  if (task.kind === 'browser-search') return runBrowserSearch(task,{call,observe,choose,signal});
  if (task.kind === 'mail-form') return runMailboxForm(task,{
    observe,signal,choose,confirmFill,
    open:url => call('open',{target:url,app:'Brave'}),
    selectLogin:page => call('use_saved_login',{url:page.window.url},page),
    click:async(snapshot,control) => {
      if (!actions()) throw new Error('Desktop actions were switched off.');
      return call('act_in_app',{target:windowRef(snapshot),steps:[{do:'click',id:control.id}]},snapshot);
    },
    fillForm:(snapshot,review) => executeDesktopTask({kind:'form',review,guided:task.campus},{...runtime,startSnapshot:snapshot}),
  });
  async function read(ref = 'front') {
    check();
    snap = await observe(ref, signal);
    check();
    return snap;
  }
  async function change(step) {
    check();
    if (!actions()) throw new Error('Desktop actions were switched off.');
    return call('act_in_app', { target: windowRef(snap), steps: [step] }, snap);
  }
  async function submit(snapshot) {
    const matches = snapshot.controls.filter(c => !c.browserChrome && clickable(c) && riskyKind(c.label) === 'submit');
    if (matches.length !== 1) return 'Review the form on screen. I couldn’t identify a single Submit button.';
    await change({ do: 'click', id: matches[0].id });
    return 'You approved the Submit click. Check the form for its confirmation.';
  }
  let inferred;
  if (task.kind === 'choice') {
    const before = await read();
    inferred = await infer(task.request, before);
    check();
    if (!inferred) return 'I didn’t click anything. Which control should I use?';
    snap = await read(windowRef(before));
    task = {kind:'desktop', steps:[{tool:'act_in_app', args:{target:windowRef(before), steps:[{do:'click_text',text:inferred.label}]}}]};
  }
  if (task.kind === 'form' || task.kind === 'submit') {
    const first = await read(startSnapshot ? windowRef(startSnapshot) : 'front');
    if (startSnapshot && !samePage(startSnapshot.window, first.window)) return 'The form changed. Review the current page before filling it.';
    if (task.kind === 'submit') return submit(first);
    const memory = facts();
    const fillPage = snapshot => fillFormFromMemory({snapshot,facts:memory,signal,
      read:id => read('window:' + id),fill:(_id,step) => change(step)});
    const result = await fillPage(first);
    if (task.guided && !result.stopped) {
      // Only scroll when a lower, currently offscreen field has an unambiguous saved value.
      // Each viewport uses the ordinary live, verified write path.
      const visited = new Set();
      for (let i=0; i<10 && !result.stopped; i++) {
        const page = await read(windowRef(first));
        if (!samePage(first.window,page.window)) { result.stopped=true; result.reason='The form changed. Review it in Brave.'; break; }
        const lower = new Set(page.controls.filter(c=>c.offscreen && c.bounds?.[1] > (page.window.bounds?.[1] ?? 0)).map(c=>c.id));
        const plan = planFormFill({snapshot:{...page,controls:page.controls.map(c=>lower.has(c.id)?{...c,offscreen:false}:c)},facts:memory});
        const position = JSON.stringify(page.controls.filter(c=>!c.browserChrome && !c.offscreen).map(c=>[c.label,c.bounds]));
        if (!plan.fields.some(f=>lower.has(f.id)) || visited.has(position)) break;
        visited.add(position);
        await change({do:'scroll',direction:'down',amount:4});
        const next = await read(windowRef(first));
        if (!samePage(first.window,next.window)) { result.stopped=true; result.reason='The form changed. Review it in Brave.'; break; }
        const more = await fillPage(next);
        result.filled.push(...more.filled); result.skipped=more.skipped; result.stopped=more.stopped; result.reason=more.reason;
      }
    }
    check();
    const labels = result.filled.map(f => f.label);
    const parts = [labels.length ? `Filled and verified ${labels.join(', ')}.` : 'I didn’t fill any fields.'];
    if (result.stopped && result.reason) parts.push(result.reason);
    const outstanding = result.skipped.filter(f => f.reason !== 'already filled' && !labels.includes(f.label));
    const needs = [...new Set(outstanding.map(f => f.label || 'an unlabeled field'))].slice(0, 8);
    if (needs.length) parts.push(`Review ${needs.join(', ')}.`);
    if (task.review && (labels.length || result.skipped.some(f => f.reason === 'already filled')) && !needs.length && !result.stopped) {
      const latest = await read(windowRef(first));
      if (samePage(first.window, latest.window)) parts.push(await submit(latest));
    } else if (labels.length) parts.push('The form is open for review.');
    return parts.join(' ');
  }

  const receipts = [];
  let opened = null;
  for (const item of task.steps) {
    check();
    const a = item.args;
    if (item.tool === 'open') {
      await call('open', a);
      opened = a.target;
      receipts.push(`Sent the request to open ${opened}.`);
      continue;
    }
    const target = a.target || 'front';
    if (!snap) {
      // Re-identify the launched app. A foreground switch must never redirect a subsequent click.
      let ref = target;
      if (opened && !/^(?:https?:\/\/|www\.)/i.test(opened)) ref = opened;
      await read(ref);
      if (opened && /^(?:https?:\/\/|www\.)/i.test(opened)) {
        const canonical = s => { try { return new URL(s.startsWith('www.') ? 'https://' + s : s).href; } catch { return null; } };
        if (!snap.window.url || canonical(snap.window.url) !== canonical(opened)) {
          return receipts.concat('I couldn’t verify the destination page, so I stopped there.').join(' ');
        }
      }
    }
    if (item.tool === 'read_window') { receipts.push(summary(snap)); continue; }
    if (item.tool !== 'act_in_app' || a.steps.length !== 1) throw new Error('That desktop step is unsupported.');
    const step = a.steps[0], before = snap;
    let label = '';
    if (step.do === 'click_text') {
      const matches = before.controls.filter(c => clickable(c) && normalize(c.label) === normalize(step.text));
      if (matches.length !== 1) return receipts.concat(matches.length ? `There are several controls named “${step.text}”. Which one did you mean?` : `I couldn’t find a visible control named “${step.text}”.`).join(' ');
      const c = matches[0];
      if (inferred && (!samePage(inferred.window, before.window) || c.role !== inferred.role || c.id !== inferred.id)) return 'The control changed during review. I stopped before clicking.';
      label = c.label;
      await change({ do: 'click', id: c.id });
    } else if (step.do === 'scroll') {
      await change(step);
    } else throw new Error('That desktop action is unsupported.');
    check();
    const after = await read(windowRef(before)).catch(e => { check(); return null; });
    const action = label ? `Sent a click to “${label}”.` : `Sent a scroll ${step.direction}.`;
    receipts.push(action);
    if (!after || signature(before) === signature(after)) {
      receipts.push('I couldn’t verify a change in the window.');
      break;
    }
    receipts.push(summary(after));
  }
  return receipts.join(' ');
}
