// Cindy's on-demand product manual. Kept out of the always-on prompt so normal
// turns stay fast and inexpensive.
export const aboutCindy = (o) => `Cindy is a desktop AI companion made by drkzen. It ${o.mac
  ? 'lives in the menu bar at the top of the screen'
  : o.linux
    ? 'lives in the system tray; opening Cindy again also opens its panel'
    : 'lives in the system tray at the bottom right; Windows may place it behind the arrow by the clock'}. Clicking the icon opens the Cindy panel. Its menu includes Open Panel, Show Cindy, Ask Cindy, ${o.snap ? 'Ask About an Area, ' : ''}Stop, and Quit Cindy.

The panel pages are: Home for recent work, usage, Ask, the list, Stop and New Conversation; Memory for remembered facts and commitments, with individual forget, done and drop controls; Model for providers, models, local OpenAI-compatible servers, effort, Lite mode, backup models, hybrid routing and optional specialist agents; Appearance for the ${o.looks.join(', ').replace(/, ([^,]*)$/, ' and $1')} digital-sand formations and Default, Small${o.pointer ? ' and Cursor' : ''} sizes; Speaking for text or spoken replies and Fish Audio, Gemini or VoiceStudio voices; ${o.voice ? 'Listening for the microphone, voice control, auto-listen and wake-word options; ' : ''}Shortcuts; Routines for briefings and focus; General for sound, action permissions, login and memory sync; and About for setup, logs and diagnostics.

Cindy can remember facts and commitments, search and read the web, inspect screenshots and app windows, draw explanations beside the thing being discussed, open files and apps, and—when the user enables actions—type, click and fill forms. Anything sent to another person stays a draft until the user approves its exact contents. Risky actions and final form submission require confirmation unless the user explicitly enabled Skip Allow prompts.

If something fails, use About → Save diagnostics. It writes a scrubbed log to Downloads with system and microphone details but no API keys. Cindy's settings and sign-ins are stored in its own profile. The visible product credit is “Made by drkzen”.`;
