import { setTimeout as delay } from 'node:timers/promises';

// This workflow starts in the user's open inbox. Subjects, controls and destinations come from the accessibility tree.
export function mailboxFormTask(input) {
  const text = String(input).trim().replace(/[’]/g, "'").replace(/^(?:hey )?cindy[, ]+/i, '').replace(/^(?:(?:can|could|would) you |please )/i, '');
  const campus = /\bIIT\s*K(?:anpur)?\b/i;
  if (/^(?:open|go to|launch|check|log ?in|sign ?in|find|use|start)\b/i.test(text) &&
      campus.test(text) && /\b(?:webmail|mail|email|inbox)\b/i.test(text) &&
      /\b(?:fill(?:\s+(?:in|out))?|complete|autofill)\b/i.test(text) && /\bform\b/i.test(text) &&
      !/\b(?:do not|don't|never)\s+(?:open|fill|log|sign)|\b(?:gmail|outlook|firefox|chrome|edge)\b/i.test(text)) {
    const links = text.match(/https?:\/\/[^\s<>"']+/gi) || [];
    if (links.some(link => !isCampusMail(webpage({window:{url:link}})))) return null;
    const named = text.match(/(?:subject(?:\s+is)?|titled|called|message|email|mail)\s*[:=]?\s*["“]([^"”]{2,160})["”]/i);
    return {kind:'mail-form', campus:true, login:/\b(?:sign[ -]?in|log[ -]?in|saved (?:login|credential|password))\b/i.test(text),
      subject:named?.[1] || null, fill:true, review:false};
  }
  const match = /^(?:find|look for|open) (?:an?|the) (?:e-?mail|message|mail) (?:asking|that asks|that asked|requesting) (?:me |us )?(?:to )?(?:fill(?: in| out)?|complete|submit) (?:an?|the) form(?: (?:in|from) my (?:inbox|webmail))?(?:\s*[,;]?\s*(?:and |then )?(?:open (?:it|the form)(?: and )?)?fill (?:it|the form)(?: (?:from|using|with) (?:my |your )?(?:memory|saved (?:details|data|profile)))?)?(?:\s*[,;]?\s*(?:and )?(?:ask me|wait for (?:my )?approval) before (?:you )?submit(?:ting)?(?: it)?)?[.!?]*$/i.exec(text);
  if (!match) return null;
  const fill = /(?:[,;]|\band\b|\bthen\b)\s*(?:and |then )?(?:open (?:it|the form) and )?fill (?:it|the form)\b/i.test(text);
  return {kind:'mail-form',fill,review:fill && /before (?:you )?submit/i.test(text)};
}

const usable = c => !!c?.label && c.id > 0 && !c.browserChrome && !c.offscreen && !c.disabled && c.enabled !== false && !c.secure;
const navigate = c => usable(c) && /^(?:link|hyperlink|list item|listitem|row|data item|tree item|button)$/i.test(c.role);
const formWords = /\b(?:forms?|questionnaire|surveys?|registration)\b/i;
const requestWords = /\b(?:fill|complete|submit|register|respond|please|requested|action required|due|deadline)\b/i;
const unsafe = /\b(?:unsubscribe|payment|password|delete|remove|send|sign out)\b/i;
const appMatches = (a,b) => a?.id === b?.id || (!!a?.app && a.app === b?.app);
const webpage = snap => {
  try { const u = new URL(snap?.window?.url); return u.protocol === 'https:' && !u.username && !u.password ? u : null; } catch { return null; }
};
function inbox(snap) {
  return /\b(?:inbox|webmail|outlook|roundcube|gmail)\b/i.test(snap.window.title || '') ||
    snap.controls.some(c => /^(?:inbox|boîte de réception)(?:\s*\(\d+\))?$/i.test(c.label ?? ''));
}
const campusMail = 'https://nwm.iitk.ac.in/';
const isCampusMail = url => !!url && [new URL(campusMail).origin, 'https://webmail1.iitk.ac.in'].includes(url.origin);
const campusBrowser = snap => /\bbrave\b/i.test(snap?.window?.app || '') && isCampusMail(webpage(snap));
const pageControls = snap => snap.controls.filter(c => !c.browserChrome && !c.offscreen);
const signIn = c => usable(c) && /^button$/i.test(c.role) && /^(?:log\s?in|sign\s?in)$/i.test(c.label.trim());
const loginPage = snap => pageControls(snap).some(c => c.password || c.secure);
const openInbox = snap => campusBrowser(snap) && !loginPage(snap) &&
  (pageControls(snap).some(c => /^(?:inbox(?:\s*\(?\d+\)?)?|compose)$/i.test(c.label?.trim())) ||
   /\binbox\b/i.test(snap.window.title));
const challenge = snap => pageControls(snap).some(c => /verification code|one.time (?:password|code)|authenticator code|security key/i.test(c.label || ''));

async function reachCampusInbox(first, task, {observe, open, selectLogin, click, signal, wait}) {
  if (openInbox(first)) return first;
  if (!campusBrowser(first)) await open(campusMail);
  const until = async predicate => {
    const end = Date.now() + 14000;
    do {
      signal?.throwIfAborted();
      const snap = await observe('front',signal);
      if (campusBrowser(snap) && predicate(snap)) return snap;
      await wait(180, undefined, {signal});
    } while (Date.now() < end);
    return null;
  };
  let page = await until(s => openInbox(s) || loginPage(s) || challenge(s));
  if (!page) return 'Brave did not show the IITK inbox or sign-in page. Open webmail and try again.';
  if (openInbox(page)) return page;
  if (challenge(page) || !task.login) return 'Finish signing in to IITK in Brave, then ask me to fill the form.';
  await selectLogin(page);
  const live = await observe('front',signal);
  if (openInbox(live)) return live;
  const buttons = pageControls(live).filter(signIn);
  if (!campusBrowser(live) || live.window.id !== page.window.id || live.window.url !== page.window.url ||
      challenge(live) || !loginPage(live) || buttons.length !== 1) return 'Finish the IITK sign-in in Brave, then ask me to continue.';
  await click(live, buttons[0]);
  page = await until(s => openInbox(s) || challenge(s));
  return page && openInbox(page) ? page : 'Finish the IITK sign-in or verification in Brave, then ask me to fill the form.';
}
function unique(rows) {
  const counts = new Map();
  for (const c of rows) counts.set(c.label, (counts.get(c.label) || 0) + 1);
  return rows.filter(c => counts.get(c.label) === 1);
}
const messageChoices = snap => snap.controls.filter(c => navigate(c) && !unsafe.test(c.label) && formWords.test(c.label) && requestWords.test(c.label));
const formLinks = snap => snap.controls.filter(c => navigate(c) && /link/i.test(c.role) && !unsafe.test(c.label) &&
  (formWords.test(c.label) || /https:\/\/[^\s]+\/(?:forms?|survey|questionnaire)\b/i.test(c.label)));
const hasFields = snap => snap.controls.some(c => usable(c) && /^(?:text field|textbox|edit|text area)$/i.test(c.role) && !/address and search|search|address bar|password/i.test(c.label));

export async function runMailboxForm(task, {observe,click,choose,confirmFill,fillForm,open,selectLogin,signal,wait=delay}) {
  let before = await observe('front', signal);
  if (task.campus) {
    before = await reachCampusInbox(before,task,{observe,open,selectLogin,click,signal,wait});
    if (typeof before === 'string') return before;
  }
  if (!inbox(before)) return 'Open your inbox and sign in. I can look for a form request in the messages visible there.';
  const origin = webpage(before)?.origin;
  async function chooseControl(rows, question) {
    const distinct = unique(rows);
    if (!distinct.length || distinct.length !== rows.length) return null;
    return rows.length === 1 ? rows[0] : choose(question,rows,signal);
  }
  async function follow(snapshot, control, ready, allowNewWindow = false) {
    const ref = 'window:' + snapshot.window.id;
    // Any user choice was made against this particular window and label.
    const live = await observe(ref,signal);
    if (live.window.title !== snapshot.window.title || live.window.url !== snapshot.window.url) return null;
    const hits = live.controls.filter(c => usable(c) && c.role === control.role && c.label === control.label);
    if (hits.length !== 1) return null;
    await click(live,hits[0]);
    const deadline = Date.now() + 12000;
    for (let i=0; task.campus ? Date.now() < deadline : i<6; i++) {
      signal?.throwIfAborted();
      if (i) await wait(task.campus ? 180 : 180*i, undefined, {signal});
      const next = await observe(allowNewWindow ? 'front' : ref,signal);
      if (appMatches(before.window,next.window) && ready(next)) return next;
    }
    return null;
  }
  const matchingMessages = snapshot => task.subject ? snapshot.controls.filter(c => navigate(c) && !unsafe.test(c.label) &&
    c.label.toLowerCase().includes(task.subject.toLowerCase())) : messageChoices(snapshot);
  let messages = matchingMessages(before);
  // The inbox title can arrive a few frames before Chromium publishes the message list.
  const messageDeadline = Date.now() + 4500;
  while (task.campus && !messages.length && Date.now() < messageDeadline) {
    await wait(180,undefined,{signal});
    const next = await observe('window:' + before.window.id,signal);
    if (!openInbox(next) || next.window.url !== before.window.url) break;
    before=next;
    messages=matchingMessages(next);
  }
  const message = await chooseControl(messages, 'Which message should I open?');
  if (!message) return messages.length ? 'I left the inbox unchanged. Open the message you mean.' : 'I couldn’t find a visible message whose subject asks for a form.';
  // Mail body links must be new. An inbox navigation link or another subject cannot serve as the destination.
  const prior = new Set(before.controls.filter(navigate).map(c => c.label));
  const newLinks = snap => formLinks(snap).filter(c => !prior.has(c.label));
  const opened = await follow(before,message,s => (!origin || webpage(s)?.origin === origin) && newLinks(s).length > 0);
  if (!opened) return 'I opened the message but couldn’t verify a form link in it.';
  if (!task.fill) return `Opened “${message.label}”. The message contains a form link.`;
  const link = await chooseControl(newLinks(opened),'Which form link should I open?');
  if (!link) return 'I left the message open so you can choose the form link.';
  const address = link.href || (/^https?:\/\/\S+$/i.test(link.label) ? link.label : null);
  let expected = null;
  if (address) {
    try { expected = new URL(address,webpage(opened)?.href); } catch { return 'I couldn’t verify the form link.'; }
    if (expected.protocol !== 'https:' || expected.username || expected.password) return 'I couldn’t verify a secure form destination.';
  }
  // The Windows accessibility helper caps labels at 80 characters. A bare URL link in an email
  // can therefore end midway through the Google Forms ID. Check the observed prefix and origin.
  const clipped = !link.href && link.label.length === 80 && /^https:\/\//i.test(link.label);
  const form = await follow(opened, link, s => !!webpage(s) && hasFields(s) &&
    (!expected || (webpage(s).origin === expected.origin && (clipped ? webpage(s).href.startsWith(expected.href) :
      webpage(s).pathname === expected.pathname && webpage(s).search === expected.search))) &&
    (s.window.id !== opened.window.id || s.window.url !== opened.window.url), true);
  if (!form) return 'I couldn’t verify a form at the link. No saved details were entered.';
  const destination = webpage(form);
  if (!(await confirmFill(destination.origin,signal))) return 'I left the form open without entering your details.';
  const pinned = await observe('window:' + form.window.id,signal);
  if (pinned.window.url !== form.window.url || pinned.window.title !== form.window.title) return 'The destination changed. No saved details were entered.';
  return fillForm(pinned,task.review);
}
