import { z } from 'zod';

// A small model may answer an explicit request for a desktop diagram entirely in prose.
// Use only its public answer. Section headings express membership; only literal arrows express links.
export function requestsIllustration(input) {
  const t = String(input ?? '').replace(/[’]/g, "'").trim();
  if (/\b(?:draw|sketch|put|place|make)\s+(?:(?:a|an|the|red|blue|small|big)\s+)*(?:box|rectangle|circle|arrow|frame|ring|outline|line)\s+(?:around|over|under|toward|to|on)\b|\b(?:mermaid|plantuml|graphviz|svg code)\b/i.test(t)) return false;
  if (/\b(?:don't|do not|never|without|no need to|no)\s+(?:\w+\s+){0,2}(?:draw|sketch|illustrat|diagram|visual|chart|graph)|\b(?:text|words|prose)[ -]only\b/i.test(t)) return false;
  if (/\b(?:how (?:do|can|should) I|teach me (?:how )?to)\s+(?:draw|illustrate|sketch)\b|\b(?:draw (?:a )?(?:conclusion|comparison|parallel|card|number|blank)|draw (?:from|on) (?:your|my|the) (?:experience|memory|knowledge))\b/i.test(t)) return false;
  if (/\b(?:save|export|upload|attach|download|file|screenshot|highlight|underline|toolbar|click|button|field|current window|this page|this screen)\b|\.(?:png|svg|jpg|pdf|html)\b/i.test(t)) return false;
  return /(?:^|[,.!?]\s*|\b(?:please|cindy|can you|could you|would you|you to|and|then)\s+)(?:draw|illustrate|visuali[sz]e|sketch|diagram)\b|\b(?:show|give|create|make|use|want|need|with)\b[^.?!]{0,45}\b(?:diagram|illustration|mind ?map|flow ?chart|graph|chart|visual explanation)\b|\bexplain\b[^.?!]{0,120}\bvisually\b/i.test(t);
}

// For a self-contained explanation, a small local model can author the content in one
// turn; Cindy handles layout. Anything needing a lookup, an action, or live coordinates
// still goes to the agent with its full tool set.
export function standaloneIllustration(input) {
  if (!requestsIllustration(input)) return false;
  const subject = input.replace(/\b(?:on|onto) (?:my|the) desktop\b/gi, '');
  return !/https?:\/\/|\b(?:my|our|this|these|those|above|attached|selected|currently|latest|today|yesterday|screen|window|monitor|desktop|browser|website|search|fetch|open|read|find|research|inspect|analy[sz]e|photo|image|map of|from memory|according to)\b/i.test(subject);
}

export const DIAGRAM_DRAFT_PROMPT = `Write the factual content for a desktop illustration in the user's language. The application draws it.
For a process, use one line of short labels separated by →, then one sentence explaining the process.
For other topics, give a short # title, then 2–5 ## section headings, each followed by one factual sentence.
Use only relationships supported by the question or established facts. Ask for clarification if necessary.
Return only the public answer. Never report that you drew something or describe tool calls.`;

const diagramDraft = z.object({
  title: z.string().max(60),
  layout: z.enum(['sequence', 'topics', 'clarification']),
  caption: z.string().max(180),
  sections: z.array(z.object({ label: z.string().min(1).max(50), detail: z.string().min(1).max(100) })).max(6),
});
export const DIAGRAM_FORMAT = {
  type: 'json_schema', json_schema: { name: 'illustration', strict: true, schema: z.toJSONSchema(diagramDraft) },
};
export const DIAGRAM_JSON_PROMPT = `Write a concise desktop illustration in the user's language. Use short labels and factual details.
Use sequence only for ordered steps. Use topics for related concepts. If more information is needed, use clarification, put the question in caption, and leave sections empty. Otherwise write 2–6 sections and a one-sentence caption.`;

export function readDiagramDraft(text) {
  let data;
  try { data = diagramDraft.parse(JSON.parse(text)); } catch { return null; }
  const { title, layout, caption, sections } = data;
  const answer = [title, caption, ...sections.map(s => s.label + ' — ' + s.detail)].filter(Boolean).join('\n');
  if (layout === 'clarification' || sections.length < 2) return { answer: caption || answer, beat: null };
  let marks;
  if (layout === 'sequence') {
    const nodes = sections.map((s, i) => ({ id: String(i + 1), text: s.label }));
    marks = [
      { kind: 'flow', title, nodes, links: nodes.slice(1).map((n, i) => ({ from: nodes[i].id, to: n.id })) },
      { kind: 'card', heading: title, items: sections.map(s => s.detail) },
    ];
  } else {
    marks = [{ kind: 'mindmap', title, branches: sections.map(s => ({ text: s.label, items: [clipped(s.detail, 60)] })) }];
  }
  return { answer, beat: { say: caption || title, marks } };
}

function clipped(s, limit) {
  if (s.length <= limit) return s;
  return s.slice(0, limit - 1).replace(/\s+\S*$/, '').trimEnd() + '…';
}

export function explanationFromReply(answer) {
  const raw = String(answer ?? '').trim();
  if (!raw || /<\/?(?:think(?:ing)?|analysis|reasoning)\b|^\s*[{[]\s*["{]|\b(?:can(?:not|'t)|unable to|could(?:n't| not))\s+(?:actually\s+|directly\s+)?(?:draw|show|illustrate|display|create|access|help)\b/i.test(raw)) return null;
  const clean = (s) => s.replace(/\[([^\]]+)\]\(https?:\/\/[^)]+\)/g, '$1').replace(/[*_]{2}|`/g, '').trim();
  const lines = raw.replace(/```[\s\S]*?(?:```|$)/g, '').split(/\r?\n/).map(clean).filter(Boolean);
  const heading = lines[0]?.match(/^#\s+(.+)/)?.[1];
  if (heading) lines.shift();
  const title = clipped(heading || 'Overview', 60);
  const groups = [];
  const body = [];
  for (const line of lines) {
    const section = line.match(/^#{1,6}\s+(.+)$/)
      ?? line.match(/^(?:[-*•]|\d+[.)])\s+([^:–—]{1,60})(?:\s*[:–—]\s*(.+))?$/);
    if (section) {
      groups.push({ label: section[1].trim(), detail: section[2] ? [section[2]] : [] });
    } else if (groups.length) groups.at(-1).detail.push(line);
    else body.push(line);
  }
  const meaningful = (s) => s.length >= 16 && !/^(?:sure\b|(?:here(?:'s| is)|below is|I've (?:drawn|created)|I (?:will|can|have) (?:draw|create|show))\b)/i.test(s);
  const intro = body.find(meaningful) ?? groups.flatMap((g) => g.detail).find(meaningful) ?? '';
  const say = clipped(intro, 180);
  if (groups.length >= 2) {
    const branches = groups.slice(0, 8).map(({ label, detail }) => ({
      text: clipped(label, 60),
      ...(detail.length ? { items: detail.slice(0, 6).map((s) => clipped(s, 60)) } : {}),
    }));
    return { say, marks: [{ kind: 'mindmap', title, branches }] };
  }
  const chain = lines.map((s) => s.split(/\s*(?:→|->)\s*/)).find((ns) => ns.length >= 2 && ns.length <= 12 && ns.every((n) => n.length >= 1 && n.length <= 60));
  if (chain) {
    const nodes = chain.map((text, i) => ({ id: String(i + 1), text }));
    const caption = lines.find((s) => !/(?:→|->)/.test(s) && meaningful(s));
    return { say: clipped(caption || '', 180), marks: [{ kind: 'flow', title, nodes, links: nodes.slice(1).map((n, i) => ({ from: nodes[i].id, to: n.id })) }] };
  }
  const text = lines.filter(meaningful).map((s) => s.replace(/^#{1,6}\s+/, '')).join('\n');
  if (!text || !/[.!?。]/u.test(text) || /^(?:done|I(?:'ve| have)? (?:drew|drawn|created|opened|displayed|placed|highlighted))\b/i.test(text)) return null;
  return { say, marks: [{ kind: 'card', ...(heading ? { heading: title } : {}), text: clipped(text, 600) }] };
}
