import MarkdownIt from 'markdown-it';
import hl from 'highlight.js/lib/common';
import katex from 'katex';
import DOMPurify from 'dompurify';
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist/build/pdf.mjs';
GlobalWorkerOptions.workerSrc = new URL('./pdf.worker.min.mjs',location.href).href;
const send=(type,args={})=>window.__TAURI__.core.invoke('sidecar_send',{msg:{type,...args}});
const el=(tag,cls='',str='')=>{const n=document.createElement(tag);if(cls)n.className=cls;if(str)n.textContent=str;return n;};
const btn=(label,fn)=>{const b=el('button','',label);b.type='button';b.onclick=fn;return b;};
const previews=new Map(), strip=document.querySelector('#tabs'), main=document.querySelector('#views');
let selected;
const md=new MarkdownIt({html:false,linkify:true,typographer:false,highlight:(str,lang)=>{
  if(str.length>100000 || !lang || !hl.getLanguage(lang))return '';
  return hl.highlight(str,{language:lang,ignoreIllegals:true}).value;
}});
md.renderer.rules.image=(ts,i)=>'<img data-source="'+md.utils.escapeHtml(ts[i].attrGet('src')||'')+'" alt="'+md.utils.escapeHtml(ts[i].content)+'">';
function math(text,displayMode){
  return katex.renderToString(text,{displayMode,output:'htmlAndMathml',throwOnError:false,trust:false,maxExpand:500,maxSize:12});
}
md.inline.ruler.before('escape','equation',(s,silent)=>{
  const pos=s.pos;if(s.src[pos]!=='$'||s.src[pos+1]==='$'||!s.src[pos+1]||/\s/.test(s.src[pos+1]))return false;
  let end=pos+1;while((end=s.src.indexOf('$',end))!==-1 && s.src[end-1]==='\\')end++;
  if(end<=pos+1||s.src.slice(pos,end).includes('\n')||/\s/.test(s.src[end-1])||/\d/.test(s.src[end+1]||''))return false;
  if(!silent)s.push('equation','',0).content=s.src.slice(pos+1,end);
  s.pos=end+1;return true;
});
md.renderer.rules.equation=(ts,i)=>math(ts[i].content,false);
md.block.ruler.before('fence','displaymath',(s,line,max,silent)=>{
  const at=k=>s.src.slice(s.bMarks[k]+s.tShift[k],s.eMarks[k]).trim();
  let first=at(line);if(!first.startsWith('$$'))return false;
  let content=first.slice(2),end=line;
  while(!content.trimEnd().endsWith('$$') && end+1<max)content+='\n'+at(++end);
  if(!content.trimEnd().endsWith('$$'))return false;
  if(!silent)s.push('displaymath','',0).content=content.trimEnd().slice(0,-2);
  s.line=end+1;return true;
});
md.renderer.rules.displaymath=(ts,i)=>math(ts[i].content,true);
function headingId(text){return text.toLowerCase().trim().replace(/[^\p{L}\p{N}\s_-]/gu,'').replace(/\s+/g,'-')||'section';}
function markdown(v,raw){
  const a=el('article','reading');a.innerHTML=DOMPurify.sanitize(md.render(raw),{FORBID_TAGS:['iframe','object','embed','form'],ADD_ATTR:['data-source']});v.body.append(a);
  const seen=new Set(),heads=[...a.querySelectorAll('h1,h2,h3,h4,h5,h6')];
  for(const h of heads){const base=headingId(h.textContent);let id=base,n=0;while(seen.has(id))id=base+'-'+(++n);seen.add(id);h.dataset.anchor=id;}
  if(heads.length){const list=el('select');list.setAttribute('aria-label','Document outline');list.append(new Option('Contents',''));heads.forEach((h,i)=>list.append(new Option('　'.repeat(Math.min(3,Number(h.tagName[1])-1))+h.textContent,String(i))));list.onchange=()=>{if(list.value!=='')heads[Number(list.value)].scrollIntoView({block:'start'});};v.bar.prepend(list);}
  for(const table of a.querySelectorAll('table')){const scroll=el('div','tablebox');table.replaceWith(scroll);scroll.append(table);}
  for(const li of a.querySelectorAll('li')){const t=li.firstChild?.nodeType===3?li.firstChild:li.querySelector(':scope > p')?.firstChild;
    if(t?.nodeType!==3||!/^\[[ xX]\]\s/.test(t.textContent))continue;
    const c=el('input','task');c.type='checkbox';c.disabled=true;c.checked=t.textContent[1]!==' ';t.textContent=t.textContent.slice(3);t.before(c);}
  for(const pre of a.querySelectorAll('pre')){const code=pre.querySelector('code'), lang=code?.className.replace(/^language-/,'')||'Code';const block=el('div','block'),bar=el('div','codebar'),copy=btn('Copy',async()=>{try{await navigator.clipboard.writeText(code?.textContent??pre.textContent);copy.textContent='Copied';}catch{const range=document.createRange();range.selectNodeContents(pre);getSelection().removeAllRanges();getSelection().addRange(range);copy.textContent='Selected';}});bar.append(el('span','',lang),copy);pre.replaceWith(block);block.append(bar,pre);}
  a.addEventListener('click',e=>{const link=e.target.closest('a');if(!link)return;e.preventDefault();const href=link.getAttribute('href');if(href.startsWith('#')){let key;try{key=decodeURIComponent(href.slice(1));}catch{return;}heads.find(h=>h.dataset.anchor===key)?.scrollIntoView();}else if(/^https?:|^mailto:/i.test(href))send('open_link',{url:href});});
  const sources=[...new Set([...a.querySelectorAll('img')].map(i=>i.dataset.source))].filter(src=>src&&!/^([a-z]+:|[\\/])/i.test(src)).slice(0,12);
  for(const src of sources)send('preview_image',{id:v.id,rev:v.rev,src});
}
function bytes(data){const s=atob(data);return Uint8Array.from(s,c=>c.charCodeAt(0));}
function localURL(v,m){const u=URL.createObjectURL(new Blob([bytes(m.data)],{type:m.mime}));v.urls.push(u);return u;}
async function pdf(v,data){
  v.pdfTask=getDocument({data:bytes(data),isEvalSupported:false,useSystemFonts:true,standardFontDataUrl:new URL('./standard_fonts/',location.href).href,cMapUrl:new URL('./cmaps/',location.href).href,cMapPacked:true,wasmUrl:new URL('./wasm/',location.href).href});
  const doc=await v.pdfTask.promise;if(!v.node.isConnected)return;
  const frame=el('div','pdf'),pages=el('span'),zoom=el('select');v.body.append(frame);
  for(const [label,value] of [['Fit width','fit'],['75%','.75'],['100%','1'],['150%','1.5'],['200%','2']])zoom.append(new Option(label,value));zoom.setAttribute('aria-label','PDF zoom');
  let page=1,generation=0,task;
  const prev=btn('Previous',()=>{page--;draw();}),next=btn('Next',()=>{page++;draw();});v.bar.replaceChildren(prev,pages,next,el('div','spacer'),zoom);
  async function draw(){const cur=++generation;task?.cancel();prev.disabled=page<=1;next.disabled=page>=doc.numPages;pages.textContent=page+' / '+doc.numPages;
    try{const p=await doc.getPage(page);if(cur!==generation||!v.node.isConnected)return;const base=p.getViewport({scale:1}),width=Math.max(120,v.body.clientWidth-30);
      const scale=zoom.value==='fit'?width/base.width:Number(zoom.value);const viewport=p.getViewport({scale:Math.min(scale,3200/Math.max(base.width,base.height))});const canvas=el('canvas');const dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.ceil(viewport.width*dpr);canvas.height=Math.ceil(viewport.height*dpr);canvas.style.width=viewport.width+'px';canvas.style.maxWidth='none';canvas.setAttribute('aria-label','PDF page '+page);
      task=p.render({canvasContext:canvas.getContext('2d'),viewport,transform:[dpr,0,0,dpr,0,0]});await task.promise;if(cur===generation&&v.node.isConnected){frame.replaceChildren(canvas);v.body.scrollTop=0;}
    }catch(e){if(cur===generation&&v.node.isConnected&&e.name!=='RenderingCancelledException')frame.textContent='Couldn’t render this page.';}}
  let last=0;v.resize=new ResizeObserver(()=>{if(v.body.clientWidth&&last!==v.body.clientWidth){last=v.body.clientWidth;if(zoom.value==='fit')draw();}});v.resize.observe(v.body);zoom.onchange=draw;await draw();
}
function table(v,raw){const delim=v.ext==='tsv'?'\t':',',tbl=el('table'),box=el('article','reading');let row=[],cell='',quote=false,count=0;
  function emit(){row.push(cell);const tr=el('tr');for(const val of row.slice(0,100))tr.append(el(count?'td':'th','',val));tbl.append(tr);cell='';row=[];count++;}
  for(let i=0;i<raw.length&&count<1000;i++){const c=raw[i];if(c==='"'&&(!cell||quote)){if(quote&&raw[i+1]==='"'){cell+='"';i++;}else quote=!quote;}else if(c===delim&&!quote){row.push(cell);cell='';}else if(c==='\n'&&!quote)emit();else if(c!=='\r'||quote)cell+=c;}
  if((cell||row.length)&&count<1000)emit();box.append(tbl);if(count===1000)box.append(el('p','','First 1,000 rows'));v.body.append(box);}
async function content(v,m){
  if(m.error){v.body.append(el('p','error',m.error));return;}
  if(v.kind==='markdown')markdown(v,m.data);else if(v.kind==='pdf')await pdf(v,m.data);else if(v.kind==='table')table(v,m.data);
  else if(['image','audio','video'].includes(v.kind)){const asset=el('div','asset'),item=el(v.kind==='image'?'img':v.kind);item.alt=v.name;if(v.kind!=='image')item.controls=true;item.src=localURL(v,m);asset.append(item);v.body.append(asset);}
  else{const pre=el('pre'),code=el('code');let raw=m.data;if(v.ext==='json')try{raw=JSON.stringify(JSON.parse(raw),null,2);}catch{}if(v.kind==='code'&&hl.getLanguage(v.ext)&&raw.length<100000)code.innerHTML=hl.highlight(raw,{language:v.ext}).value;else code.textContent=raw;pre.append(code);v.body.append(pre);}
}
function dispose(v){v.resize?.disconnect();v.pdfTask?.destroy()?.catch(()=>{});v.urls.forEach(u=>URL.revokeObjectURL(u));v.node.remove();}
function refresh(m){selected=m.active;document.documentElement.dataset.theme=m.theme;if(/^#[a-f\d]{6}$/i.test(m.accent))document.documentElement.style.setProperty('--accent',m.accent);
  for(const [id,v] of previews)if(!m.tabs.some(t=>t.id===id&&t.rev===v.rev)){dispose(v);previews.delete(id);}
  strip.replaceChildren();main.querySelector('.empty')?.remove();
  for(const t of m.tabs){let v=previews.get(t.id);if(!v){const node=el('section','view'),bar=el('header','toolbar'),body=el('div','body');node.id='view-'+t.id;node.setAttribute('role','tabpanel');node.setAttribute('aria-label',t.name);bar.append(el('div','spacer'),el('span','',t.ext.toUpperCase()));node.append(bar,body);main.append(node);v={...t,node,bar,body,urls:[],loaded:false};previews.set(t.id,v);}
    v.node.hidden=t.id!==selected;if(v.node.hidden) v.body.querySelectorAll('video,audio').forEach(el=>el.pause());
    const wrap=el('div','tab'),b=btn(t.name,()=>send('preview_select',{id:t.id})),close=btn('×',()=>send('preview_close',{id:t.id}));b.title=t.name;b.setAttribute('role','tab');b.setAttribute('aria-controls',v.node.id);b.setAttribute('aria-selected',String(!v.node.hidden));b.tabIndex=v.node.hidden?-1:0;close.className='x';close.setAttribute('aria-label','Close '+t.name);wrap.append(b,close);strip.append(wrap);
    if(!v.node.hidden&&!v.loaded){v.loaded=true;send('preview_content',{id:t.id,rev:t.rev});}
  }
  strip.querySelector('[aria-selected=true]')?.scrollIntoView({block:'nearest',inline:'nearest'});
  if(!m.tabs.length)main.append(el('div','empty','No open files'));
}
strip.onkeydown=e=>{const a=[...strip.querySelectorAll('[role=tab]')],idx=a.indexOf(e.target);if(idx<0)return;const next={ArrowRight:(idx+1)%a.length,ArrowLeft:(idx+a.length-1)%a.length,Home:0,End:a.length-1}[e.key];if(next===undefined)return;e.preventDefault();a[next].focus();a[next].click();};
window.__cindyPreview=m=>{if(m.kind==='state'){refresh(m);return;}const v=previews.get(m.id);if(!v||v.rev!==m.rev)return;
  if(m.kind==='content')content(v,m).catch(()=>{if(v.node.isConnected)v.body.replaceChildren(el('p','error','Couldn’t display this file.'));});
  if(m.kind==='image'){const url=localURL(v,m);v.body.querySelectorAll('img').forEach(i=>{if(i.dataset.source===m.src)i.src=url;});}};
send('preview_ready');
