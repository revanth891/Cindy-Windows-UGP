// Cindy downstream modification, 2026-11-18: deliberately no update transport.
// A rebranded research build must not install an upstream Cindy release.
export function disabledUpdates({ changed = () => {}, notify = () => {}, now = Date.now } = {}) {
  const state = { enabled: false, available: null, told: null, manual: false, installing: false, checking: false, result: null, page: false, done: null };
  const unavailable = () => {
    state.result = { ok: false, at: now(), error: 'Updates are disabled for this Cindy research build.' };
    changed(); notify(state.result.error);
  };
  return { state, check(manual = false) { if (manual) unavailable(); }, install: unavailable, status() {} };
}
