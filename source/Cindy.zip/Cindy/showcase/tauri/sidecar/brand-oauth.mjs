// Applied to the pinned SDK inside the distributable, which owns the loopback success page.
import fs from 'node:fs/promises';
const file=new URL('./dist/sidekick.mjs',import.meta.url);
const js=await fs.readFile(file,'utf8');
const old="You're signed in to GG Coder.";
if(!js.includes(old))throw Error('Check the ChatGPT success-page branding against the bundled SDK.');
await fs.writeFile(file,js.replaceAll(old,"You're signed in to drkzen.").replaceAll("ChatGPT didn't finish registering GG Coder.","ChatGPT didn't finish registering drkzen.").replaceAll("ChatGPT plan use isn't enabled for GG Coder.","ChatGPT plan use isn't enabled for drkzen."));
