use crate::{act,logic::*,uia,win};
use std::{thread,time::Duration};
use windows::Win32::UI::WindowsAndMessaging::{GetAncestor,GA_ROOTOWNER};

fn ready(w:&Win, expected:&str)->bool {
    w.exe.trim_end_matches(".exe").eq_ignore_ascii_case("brave") &&
    win::front_hwnd()==win::hwnd(w.id) && expected.starts_with("https://") &&
    uia::browser_address(w).as_deref()==Some(expected)
}
fn username(n:&uia::Node)->bool{
    let label=format!("{} {}",n.name,n.help).to_lowercase();
    n.web && n.ct==CT_EDIT && !n.password && n.enabled && n.r.is_some() &&
        ["username","user name","user id","email","e-mail","login id"].iter().any(|s|label.contains(s))
}
fn row(tree:&uia::Tree,owned_popup:bool)->Option<&uia::Node>{
    // Brave exposes the password-manager footer as browser chrome. Only rows from
    // its own popup subtree qualify, even if the page paints an identical list.
    for (i,footer) in tree.nodes.iter().enumerate(){
        if footer.web || footer.web_root {continue}
        let s=footer.name.to_lowercase();
        if !(s.contains("manage passwords") || s.contains("password manager") || s.contains("manage passkeys")) {continue}
        let mut ancestor=footer.parent;
        for _ in 0..6 {
            let Some(a)=ancestor else {break};
            let root=&tree.nodes[a];
            let class=unsafe{root.el.CurrentClassName()}.map(|s|s.to_string().to_lowercase()).unwrap_or_default();
            let popup=(owned_popup && a==0 && !tree.nodes.iter().any(|n|n.web_root)) || matches!(root.ct,CT_LIST|CT_MENU) || class.contains("autofillpopup") || class.contains("popupview");
            if popup {
                let candidates=tree.nodes[a+1..i].iter().take_while(|n|n.parent.is_some()).filter(|n| {
                    let mut parent=n.parent;
                    while let Some(k)=parent {if k==a {break} parent=tree.nodes[k].parent;}
                    let label=n.name.to_lowercase();
                    parent==Some(a) && !n.web && !n.web_root && n.enabled && n.r.is_some() &&
                    matches!(n.ct,CT_LISTITEM|CT_MENUITEM) && !label.is_empty() &&
                    !["manage","generate password","suggest password","use another","other device","settings","show password","copy","passkey"].iter().any(|s|label.contains(s))
                });
                if let Some(first)=candidates.into_iter().next(){return Some(first);}
            }
            ancestor=root.parent;
        }
    }
    None
}
pub fn select_first(w:&Win,expected:&str,present:bool)->Result<(),String>{
    if !ready(w,expected){return Err("Open the requested HTTPS sign-in page in the foreground in Brave.".into());}
    let tree=uia::Tree::of_window(w);
    let fields:Vec<_>=tree.nodes.iter().filter(|n|username(n)).collect();
    if fields.len()!=1{return Err("Couldn’t identify one username field on this page.".into());}
    let field=fields[0];
    let r=uia::live_rect(&field.el).ok_or("The username field moved.")?;
    if !ready(w,expected){return Err("The login page changed.".into());}
    if present {
        crate::progress(serde_json::json!({"ev":"step","do":"click","label":"Username","bounds":r.ints(),"i":0}));
    }
    act::click(w,r.mid_x(),r.mid_y())?;
    for _ in 0..10 {
        thread::sleep(Duration::from_millis(105));
        if !ready(w,expected){return Err("The active page changed during sign-in.".into());}
        for hwnd in win::popups_of(w.pid) {
            if hwnd!=win::hwnd(w.id) && unsafe{GetAncestor(hwnd,GA_ROOTOWNER)}!=win::hwnd(w.id){continue}
            let mut popup=w.clone();popup.id=hwnd.0 as isize as i64;
            let menu=uia::Tree::of_window(&popup);
            if let Some(item)=row(&menu,hwnd!=win::hwnd(w.id)) {
                if !ready(w,expected) {return Err("The login page changed.".into());}
                let label=item.name.clone();
                if present {
                    if let Some(rect) = uia::live_rect(&item.el) {
                        crate::progress(serde_json::json!({"ev":"step","do":"click","label":"Saved account","bounds":rect.ints(),"i":1}));
                        thread::sleep(Duration::from_millis(200));
                    }
                    if !ready(w,expected){return Err("The sign-in page changed.".into());}
                }
                let moved = !uia::chosen(&item.el);
                if moved {
                    act::picker_key(w,"down")?;
                    thread::sleep(Duration::from_millis(110));
                }
                let fresh=uia::Tree::of_window(&popup);
                let first=row(&fresh,hwnd!=win::hwnd(w.id)).filter(|n|n.name==label).ok_or("Brave changed its saved-login picker.")?;
                if !ready(w,expected){return Err("The sign-in page changed.".into());}
                let active=fresh.nodes.iter().any(|n|!n.web && n.name==label && uia::chosen(&n.el));
                let other_selected=fresh.nodes.iter().any(|n|!n.web && n.ct==CT_LISTITEM && n.name!=label && uia::chosen(&n.el));
                if active || moved && !other_selected && uia::is_focused(&field.el) { act::picker_key(w,"return")?; }
                else if !uia::default_action(&first.el) && !uia::invoke(&first.el){return Err("Select the first saved account in Brave.".into());}
                for _ in 0..12 {
                    thread::sleep(Duration::from_millis(100));
                    if !ready(w,expected){return Err("Complete the sign-in prompt in Brave.".into());}
                    let user=uia::value(&field.el);
                    if !user.is_empty() && item.name.to_lowercase().contains(&user.to_lowercase()){return Ok(());}
                }
                return Err("Brave has not confirmed the selected account. Complete its sign-in prompt.".into());
            }
        }
    }
    Err("Brave didn’t expose its saved-login picker. Select the saved login in Brave to continue.".into())
}
