use crate::{
    act, capture,
    logic::{is_browser, Rect, Win},
    ocr, uia, win,
};
use serde_json::{json, Value};
use std::{
    collections::hash_map::DefaultHasher,
    hash::{Hash, Hasher},
    path::Path,
    time::Duration,
};
use windows::Win32::UI::Accessibility::{
    IUIAutomationTogglePattern, ToggleState_On, UIA_TogglePatternId,
};

const ORIGIN: &str = "https://zenservices.pages.dev";

fn origin_ok(url: &str) -> bool {
    url == ORIGIN
        || url
            .strip_prefix(ORIGIN)
            .is_some_and(|suffix| suffix.starts_with('/'))
}

fn node<'a>(tree: &'a uia::Tree, id: &str) -> Result<&'a uia::Node, String> {
    let visible = |n: &&uia::Node| n.web && n.r.is_some_and(|r| r.w > 0. && r.h > 0.);
    let exact: Vec<_> = tree
        .nodes
        .iter()
        .filter(visible)
        .filter(|n| n.automation_id == id)
        .collect();
    let fallback = match id {
        "control-enabled" => Some(("Control", "checkbox")),
        "remote-screen" => Some(("Remote desktop image", "")),
        "paste-toggle" => Some(("Paste as typing", "button")),
        "paste-text" => Some(("Paste or type text here...", "")),
        "paste-send" => Some(("Type it", "button")),
        "paste-close" => Some(("Close paste panel", "button")),
        _ => None,
    };
    let candidates = if exact.is_empty() {
        tree.nodes
            .iter()
            .filter(visible)
            .filter(|n| {
                fallback.is_some_and(|(label, role)| {
                    (n.name == label || n.help == label)
                        && (role.is_empty() || n.kind().eq_ignore_ascii_case(role))
                })
            })
            .collect()
    } else {
        exact
    };
    let mut matches = candidates.into_iter();
    let found = matches
        .next()
        .ok_or_else(|| format!("ZenServices control {id} is unavailable."))?;
    if matches.next().is_some() {
        return Err("The portal shows more than one matching control.".into());
    }
    Ok(found)
}

fn text(tree: &uia::Tree, id: &str) -> Result<String, String> {
    let n = node(tree, id)?;
    let mut words = Vec::new();
    let mut stack = vec![n];
    while let Some(next) = stack.pop() {
        if !next.name.trim().is_empty() && !words.contains(&next.name.as_str()) {
            words.push(next.name.as_str());
        }
        stack.extend(next.kids.iter().rev().map(|i| &tree.nodes[*i]));
    }
    Ok(words.join(" "))
}

struct View {
    tree: uia::Tree,
    device: String,
    canvas: Rect,
    control_enabled: bool,
}
fn viewer(w: &Win) -> Result<View, String> {
    if !is_browser(&w.exe) || !uia::browser_address(w).is_some_and(|url| origin_ok(&url)) {
        return Err("Bring the connected ZenServices tab to the front.".into());
    }
    let tree = uia::Tree::of_window(w);
    // Chromium may flatten the toolbar's <strong> and <span> to text runs without DOM ids.
    // Only use the narrow interval between the portal's own Back and Control widgets.
    let back = tree.nodes.iter().position(|n| {
        n.web && n.name == "Disconnect and return to devices" && n.kind() == "button"
    });
    let control_index = tree.nodes.iter().position(|n| {
        n.web
            && (n.automation_id == "control-enabled"
                || n.name == "Control" && n.kind() == "checkbox")
    });
    let mut header = Vec::new();
    if let Some((start, end)) = back.zip(control_index).filter(|(a, b)| a < b) {
        for n in &tree.nodes[start + 1..end] {
            let name = n.name.trim();
            if n.web
                && n.ct == crate::logic::CT_TEXT
                && !name.is_empty()
                && header.last() != Some(&name)
            {
                header.push(name);
            }
        }
    }
    let connected = header
        .iter()
        .position(|s| s.eq_ignore_ascii_case("Connected"));
    let device = text(&tree, "viewer-name")
        .ok()
        .filter(|s| !s.is_empty())
        .or_else(|| {
            connected
                .and_then(|i| i.checked_sub(1))
                .map(|i| header[i].to_string())
        })
        .ok_or("The client device name is unavailable.")?;
    if !text(&tree, "viewer-status")
        .map_or(connected.is_some(), |s| s.eq_ignore_ascii_case("Connected"))
    {
        return Err("Open a connected client in the ZenServices viewer.".into());
    }
    let control = node(&tree, "control-enabled")?;
    let enabled = control.enabled
        && unsafe {
            control
                .el
                .GetCurrentPatternAs::<IUIAutomationTogglePattern>(UIA_TogglePatternId)
                .and_then(|p| p.CurrentToggleState())
        }
        .is_ok_and(|s| s == ToggleState_On);
    let canvas = node(&tree, "remote-screen")?.r.unwrap();
    if canvas.w < 80. || canvas.h < 60. {
        return Err("The client screen is unavailable.".into());
    }
    Ok(View {
        tree,
        device,
        canvas,
        control_enabled: enabled,
    })
}

fn frame(w: &Win, rect: Rect) -> Result<(capture::Shot, String), String> {
    let (shot, area) =
        capture::pixels_of(Some(w)).ok_or("Could not capture the browser window.")?;
    let sx = shot.w as f64 / area.w;
    let sy = shot.h as f64 / area.h;
    let x = ((rect.x - area.x) * sx).round() as isize;
    let y = ((rect.y - area.y) * sy).round() as isize;
    let width = (rect.w * sx).round() as usize;
    let height = (rect.h * sy).round() as usize;
    if x < 0
        || y < 0
        || width == 0
        || height == 0
        || x as usize + width > shot.w
        || y as usize + height > shot.h
    {
        return Err("Show the entire client screen before asking Cindy to answer.".into());
    }
    let mut rgba = Vec::with_capacity(width * height * 4);
    for row in y as usize..y as usize + height {
        let start = (row * shot.w + x as usize) * 4;
        rgba.extend_from_slice(&shot.rgba[start..start + 4 * width]);
    }
    let mut hash = DefaultHasher::new();
    (width, height).hash(&mut hash);
    rgba.hash(&mut hash);
    Ok((
        capture::Shot {
            w: width,
            h: height,
            rgba,
        },
        format!("{:016x}", hash.finish()),
    ))
}

fn same(w: &Win, device: &str) -> Result<View, String> {
    let view = viewer(w)?;
    if !view.control_enabled {
        return Err("ZenServices is in view-only mode.".into());
    }
    // All input below addresses a window handle or UIA element directly. Host research may
    // have focus in another window. Revalidate the actual destination before each action.
    let current = win::resolve(&format!("window:{}", w.id));
    if view.device != device
        || !current.is_some_and(|current| current.pid == w.pid && current.exe == w.exe)
    {
        return Err("The active client or browser changed. Input stopped.".into());
    }
    Ok(view)
}

pub fn run(raw: &str) -> Result<Value, String> {
    let cmd: Value = serde_json::from_str(raw).map_err(|_| "Invalid viewer request.")?;
    let op = cmd["op"].as_str().unwrap_or("");
    let w = win::resolve(
        &cmd["window"]
            .as_i64()
            .map(|id| format!("window:{id}"))
            .unwrap_or_else(|| "front".into()),
    )
    .ok_or("Open the paired ZenServices viewer.")?;
    let view = viewer(&w)?;
    if op == "status" {
        return Ok(
            json!({"ok":true,"window":w.id,"device":view.device,"canControl":view.control_enabled}),
        );
    }
    if op != "read"
        && (cmd["device"].as_str() != Some(&view.device) || cmd["window"].as_i64() != Some(w.id))
    {
        return Err("The client is not bound to the original viewer.".into());
    }
    if cmd["device"].as_str().is_some_and(|d| d != view.device) {
        return Err("The paired device changed.".into());
    }
    if node(&view.tree, "paste-text").is_ok()
        || node(&view.tree, "bridge-prompt").is_ok()
        || node(&view.tree, "ai-prompt").is_ok()
    {
        return Err(
            "Close the portal’s paste or analysis panel to expose the client screen.".into(),
        );
    }
    let (shot, stamp) = frame(&w, view.canvas)?;
    if op == "read" {
        let path = Path::new(cmd["file"].as_str().ok_or("Missing capture destination.")?);
        if path.file_name().and_then(|n| n.to_str()) != Some("screen.png")
            || !path.parent().is_some_and(|dir| {
                dir.parent()
                    .is_some_and(|root| root == std::env::temp_dir())
                    && dir
                        .file_name()
                        .is_some_and(|name| name.to_string_lossy().starts_with("cindy-client-"))
            })
        {
            return Err("Invalid temporary capture destination.".into());
        }
        capture::save(
            &shot,
            path.to_str().ok_or("Invalid capture destination.")?,
            Some(1440),
            90,
        )?;
        let again = viewer(&w)?;
        if again.device != view.device {
            return Err("The client changed during capture.".into());
        }
        return Ok(
            json!({"ok":true,"window":w.id,"device":view.device,"stamp":stamp,"canControl":view.control_enabled}),
        );
    }
    if cmd["stamp"].as_str() != Some(&stamp) {
        return Err("The client screen changed before input. Read the question again.".into());
    }
    let label = cmd["label"].as_str().unwrap_or("").trim();
    if !matches!(op, "option" | "field") {
        return Err("Unknown client action.".into());
    }
    if label.len() > 500 {
        return Err("No unique visible answer target.".into());
    }
    let hit = if label.is_empty() && op == "field" {
        let b = cmd["box"]
            .as_array()
            .filter(|a| a.len() == 4)
            .ok_or("Cannot locate the empty answer field.")?;
        let points: Vec<u64> = b
            .iter()
            .filter_map(|v| v.as_u64().filter(|n| *n <= 1000))
            .collect();
        if points.len() != 4
            || points[2] <= points[0]
            || points[3] <= points[1]
            || points[2] - points[0] < 30
            || points[3] - points[1] < 8
            || points[3] - points[1] > 350
        {
            return Err("The empty answer field is unclear.".into());
        }
        Rect::new(
            view.canvas.x + view.canvas.w * points[0] as f64 / 1000.,
            view.canvas.y + view.canvas.h * points[1] as f64 / 1000.,
            view.canvas.w * (points[2] - points[0]) as f64 / 1000.,
            view.canvas.h * (points[3] - points[1]) as f64 / 1000.,
        )
    } else {
        if label.is_empty() {
            return Err("Missing option label.".into());
        }
        let mut hits = ocr::ocr_find(Some(&w), label, true)?
            .into_iter()
            .filter_map(|h| {
                let b = h["bounds"].as_array()?;
                let r = Rect::new(
                    b.first()?.as_f64()?,
                    b.get(1)?.as_f64()?,
                    b.get(2)?.as_f64()?,
                    b.get(3)?.as_f64()?,
                );
                (r.x >= view.canvas.x
                    && r.y >= view.canvas.y
                    && r.max_x() <= view.canvas.max_x()
                    && r.max_y() <= view.canvas.max_y())
                .then_some(r)
            });
        let hit = hits
            .next()
            .ok_or("The answer target is no longer visible in the client screen.")?;
        if hits.next().is_some() {
            return Err("More than one answer target matches the client screen.".into());
        }
        hit
    };
    let answer = cmd["answer"].as_str().unwrap_or("");
    if op == "field"
        && (answer.trim().is_empty() || answer.len() > 1200 || answer.chars().any(char::is_control))
    {
        return Err("The answer must be one plain-text response.".into());
    }
    let latest = same(&w, &view.device)?;
    if frame(&w, latest.canvas)?.1 != stamp {
        return Err("The question changed before the click.".into());
    }
    act::click(&w, hit.mid_x(), hit.mid_y())?;
    if op == "option" {
        return Ok(json!({"ok":true}));
    }
    // The portal delivers plain text to its paired device. Never send keystrokes to the host foreground.
    let latest = same(&w, &view.device)?;
    if !uia::invoke(&node(&latest.tree, "paste-toggle")?.el) {
        return Err("Could not open Paste as typing.".into());
    }
    let mut field_ready = false;
    for _ in 0..10 {
        let latest = same(&w, &view.device)?;
        if let Ok(field) = node(&latest.tree, "paste-text") {
            if !field.value.is_empty() {
                return Err("The portal already has a paste draft.".into());
            }
            field_ready = uia::set_value(&field.el, answer);
            break;
        }
        std::thread::sleep(Duration::from_millis(80));
    }
    let latest = same(&w, &view.device)?;
    if !field_ready || node(&latest.tree, "paste-text")?.value != answer {
        return Err("Cindy could not verify the portal paste draft.".into());
    }
    let send = node(&latest.tree, "paste-send")?;
    if !send.enabled || !uia::invoke(&send.el) {
        return Err("ZenServices could not start typing the answer.".into());
    }
    for _ in 0..45 {
        std::thread::sleep(Duration::from_millis(250));
        let current = same(&w, &view.device)?;
        let done =
            current.tree.nodes.iter().any(|n| {
                n.web && n.name.starts_with("Done") && n.name.contains("characters typed")
            });
        if done {
            if let Ok(draft) = node(&current.tree, "paste-text") {
                if draft.value == answer {
                    uia::set_value(&draft.el, "");
                }
            }
            if let Ok(close) = node(&current.tree, "paste-close") {
                uia::invoke(&close.el);
            }
            return Ok(json!({"ok":true}));
        }
    }
    Err("Typing started on the client. Check the portal for completion before retrying.".into())
}
