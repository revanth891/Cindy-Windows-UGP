use ort::{session::Session, value::Tensor};

/// AudioSet YAMNet class 57 is finger snapping, 58 is clapping.
/// Run only around transients, off the microphone callback, on 16 kHz mono.
pub struct Detector {
    model: Option<Session>,
    failed: bool,
    last: usize,
}
impl Default for Detector {
    fn default() -> Self { Self { model: None, failed: false, last: 0 } }
}
impl Detector {
    pub fn reset(&mut self) { self.last = 0; }
    pub fn check(&mut self, buf: &[f32]) -> bool {
        if super::AUDIO_ENV.get().is_none() || self.failed || buf.len() < self.last + 2400 { return false; }
        self.last = buf.len();
        let tail = &buf[buf.len().saturating_sub(9500)..];
        let peak = tail.iter().fold(0.0f32, |a,x| a.max(x.abs()));
        let rms = (tail.iter().map(|x|x*x).sum::<f32>() / tail.len() as f32).sqrt();
        if peak < 0.012 || peak < rms*3.1 { return false; }
        let offset=buf.len()-tail.len();
        let impulse=offset+tail.iter().enumerate().max_by(|a,b|a.1.abs().total_cmp(&b.1.abs())).unwrap().0;
        match self.score(buf,impulse,3200).and_then(|hit| if hit { Ok(true) } else { self.score(buf,impulse,7600) }) {
            Ok(hit) => hit,
            Err(e) => { super::log(&format!("snap classifier unavailable: {e}")); self.failed=true; false }
        }
    }
    fn score(&mut self, buf:&[f32], impulse:usize, anchor:usize) -> ort::Result<bool> {
        if self.model.is_none() {
            self.model=Some(Session::builder(super::AUDIO_ENV.get().expect("speech runtime ready"))?.with_intra_threads(1)?.commit_from_memory(include_bytes!("../sound-model/yamnet.onnx"))?);
        }
        let mut window=vec![0.0;15600];
        let start=impulse.saturating_sub(anchor);
        let end=buf.len().min(impulse+15600-anchor);
        let first=anchor-(impulse-start);
        window[first..first+end-start].copy_from_slice(&buf[start..end]);
        let input=Tensor::from_array(([1usize,15600],window))?;
        let outputs=self.model.as_mut().unwrap().run(ort::inputs![input])?;
        let (_,scores)=outputs[0].try_extract_tensor::<f32>()?;
        Ok(scores[57]>=0.085 && scores[57]>scores[58]*2.0 && scores[57]>scores[378]*2.0 && scores[57]>scores[485]*1.3)
    }
}
