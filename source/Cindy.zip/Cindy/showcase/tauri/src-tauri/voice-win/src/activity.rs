use crate::RATE;
use std::ops::Range;

const FRAME: usize = 256; // 16 ms of 16 kHz mono
const ONSET_FRAMES: usize = 4;
const PRE_ROLL: usize = RATE as usize * 4 / 10;
const POST_ROLL: usize = RATE as usize * 4 / 10;

#[derive(Default)]
pub struct SpeechActivity {
    detector: earshot::Detector,
    processed: usize,
    consecutive: usize,
    first: Option<usize>,
    last: usize,
}

impl SpeechActivity {
    /// Each complete frame is classified once. Keep the original waveform, including gaps
    /// between words. Only leading and trailing background are excluded from decoding.
    pub fn observe(&mut self, take: &[f32]) {
        for frame in take[self.processed..].chunks_exact(FRAME) {
            self.processed += FRAME;
            if self.detector.predict_f32(frame) < 0.5 {
                self.consecutive = 0;
                continue;
            }
            self.consecutive += 1;
            if self.consecutive >= ONSET_FRAMES {
                self.first.get_or_insert(self.processed - ONSET_FRAMES * FRAME);
                self.last = self.processed;
            }
        }
    }

    pub fn clip(&self, length: usize) -> Option<Range<usize>> {
        Some(self.first?.saturating_sub(PRE_ROLL)..(self.last + POST_ROLL).min(length))
    }

    pub fn heard(&self) -> bool { self.first.is_some() }

    #[cfg(test)]
    pub fn mark_test_speech(&mut self) {
        self.first = Some(0);
        self.last = FRAME;
    }

    pub fn quiet_for(&self, seconds: f64) -> bool {
        self.heard() && self.processed.saturating_sub(self.last) >= (seconds * RATE as f64) as usize
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn repeated_clicks_do_not_open_a_command() {
        let mut take = vec![0.0; RATE as usize * 3];
        for click in take.chunks_mut(RATE as usize / 2) { click[..15].fill(0.5); }
        let mut activity = SpeechActivity::default();
        for end in (0..take.len()).step_by(197) { activity.observe(&take[..end]); }
        activity.observe(&take);
        assert_eq!(activity.clip(take.len()), None);
    }

    #[test]
    fn clip_keeps_onsets_and_endings_and_uses_audio_time_for_pauses() {
        let mut a = SpeechActivity::default();
        a.first = Some(16_000);
        a.last = 32_000;
        a.processed = 48_000;
        assert_eq!(a.clip(48_000), Some(9_600..38_400));
        assert!(!a.quiet_for(1.5));
        a.processed += 8_000;
        assert!(a.quiet_for(1.5));
        assert_eq!(a.clip(33_000), Some(9_600..33_000));
    }
}
