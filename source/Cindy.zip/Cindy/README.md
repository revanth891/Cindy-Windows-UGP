# Cindy for Windows

**Version 0.4.9 · Recording edition · x64**

Cindy is a floating desktop assistant. You can ask it to open an app, explain what is on screen, or fill a form for review. The Recording edition can include the companion, its cursor, and its reply boxes in a screen recording.

## Install and try Cindy

1. Run `Cindy-0.4.9-Recording-Windows.exe` from the Windows release. If you only have the source archive, follow **Build from source** below to produce an installer.
2. Click **Next** and finish the setup wizard. If Windows shows **Already Installed**, choose **Add/Reinstall components** to install over an existing 0.4.9 installation.
3. Open **Cindy** from Start. Pick an avatar and a theme. For voice input, allow microphone access and download **My voice**. Choose **Skip for now** to begin with the keyboard.
4. Connect a model using one of the routes below. To open settings after first launch, click the Cindy icon beside the Windows clock. It may be under the **^** arrow.
5. Tap **Ctrl + Shift**, type **Open Notepad**, and press **Enter**. With voice configured, hold **Ctrl + Alt** while speaking and release to send. **Ctrl + Shift + S** shows or hides Cindy. You can change these bindings under **Shortcuts**.

## Connect a model

| Connection | Steps |
| --- | --- |
| ChatGPT or Claude account | On the first-run account screen, pick your provider and complete sign-in in the browser. You can also sign in later under **Model → Accounts**. |
| NVIDIA API key | Open **Model → Accounts → NVIDIA → Add key**. Paste your key and click **Save**. Under **Model → Default**, choose an available Nemotron model. |
| Local model | Start Ollama or the LM Studio server with a model loaded. Find the server under **Model → Accounts** and click **Connect**. Use the page arrows if needed. Select the model under **Default**. |
| Other OpenAI-compatible server | Under **Model → Accounts**, open **Another server → Add server**. Enter the server name and address, add a key if required, and click **Save**. Then select the model under **Default**. |

If the model list is empty, return to **Accounts** and check that sign-in or key verification finished. Enter credentials in Cindy's account settings.

## Record the companion

Open **General** and turn on **Recording mode**. In OBS, add **Display Capture** for the monitor where Cindy appears. Test it by invoking Cindy and recording a short reply. The switch is off on a fresh installation.

## Build from source

Use a Windows x64 machine with Git for Windows (Git Bash), Node.js 24 with npm, Rust stable with the MSVC toolchain, and Visual Studio Build Tools with **Desktop development with C++** and a Windows SDK. The first build downloads npm packages, Rust crates, native dependencies, and the bundled Node runtime.

Extract the ZIP. Open **Git Bash** in the directory containing this README and the `showcase` folder. Run these commands in the same shell.

```bash
rustup target add x86_64-pc-windows-msvc --toolchain stable-x86_64-pc-windows-msvc
export RUSTUP_TOOLCHAIN=stable-x86_64-pc-windows-msvc
npm ci --prefix showcase/tauri/sidecar
npm install --prefix .cindy-tools --no-save --package-lock=false @tauri-apps/cli@2.12.5
export CINDY_TAURI_CLI="$PWD/.cindy-tools/node_modules/@tauri-apps/cli/tauri.js"
export TAURI_BUNDLES=nsis
cd showcase/tauri
bash ./build.sh release --target x86_64-pc-windows-msvc
```

The installer is written to `showcase/tauri/src-tauri/target/x86_64-pc-windows-msvc/release/bundle/nsis/Cindy_0.4.9_x64-setup.exe`, relative to the source root.

To run the JavaScript tests, open Git Bash at the source root after installing the npm dependencies.

```bash
npm test --prefix showcase/tauri/sidecar
```

## Source layout

| Directory | Contents |
| --- | --- |
| `showcase/cindy/` | Companion animation, cursor rendering, and desktop cards |
| `showcase/onboarding/`, `showcase/panel/` | First-run guide, model accounts, appearance, shortcuts, and preferences |
| `showcase/previews/` | Floating file-preview interface |
| `showcase/tauri/sidecar/` | Agent runtime, provider connections, memory, action handling, and tests |
| `showcase/tauri/src-tauri/` | Native shell, windows, hotkeys, installer configuration, and Windows voice and input helpers |
